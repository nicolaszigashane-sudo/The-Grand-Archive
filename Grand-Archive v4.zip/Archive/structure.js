/**
 * THE GRAND ARCHIVE - Service Worker
 * Version 1.0.0
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion du cache hors-ligne et des ressources
 * COMPORTEMENT : Cache les assets pour utilisation offline
 */


The Grand Archive/
├── index.html
├── main.js
├── style.css
├── about.json
├── sw.js
├── manifest.json
├── backgrounds/
│   └── (tes images)
└── modules/
    ├── ui-core.js
    ├── navigation.js
    ├── panel-buttons.js
    ├── content-loader.js
    ├── player-interface.js
    ├── sound-system.js
    ├── local-library.js
    ├── about-handler.js
    ├── metadata-bot.js
    ├── gallery-engine.js
    ├── itunes-api.js
    ├── lastfm-api.js
    ├── offline-manager.js
    ├── immersion-engine.js
    ├── player-controls.js
    ├── radio-stream.js
    └── lyrics-sync.js