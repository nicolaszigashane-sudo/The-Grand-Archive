/**
 * THE GRAND ARCHIVE - Main Orchestrator
 * Version 3.0.0
 * 
 * Copyright (C) 2026 [davidb]
 * Licence: GNU General Public License v3.0
 * 
 * Développé sur iPhone XR avec Koder
 * Guidé par Gemini et DeepSeek
 *//
(function() {
    'use strict';

    console.log('🚀 Orchestrateur: démarrage...');

    const eventBus = document.createElement('div');
    eventBus.id = 'event-bus';
    document.body.appendChild(eventBus);
    console.log('✅ eventBus créé');

    const modules = window.modules || {};
    console.log('📦 Modules trouvés:', Object.keys(modules));

    const initOrder = [
        'sound', 'background', 'ui', 'metadata',
        'gallery', 'offline', 'itunes', 'lastfm',
        'local', 'about',
        'radio', 'lyrics', 'immersion',
        'content', 'navigation', 'playerInterface', 'playerControls',
        'panelButtons'
    ];

    async function initModules() {
        console.log('🔄 Début de initModules()');
        for (const name of initOrder) {
            const mod = modules[name];
            if (!mod) {
                console.warn(`⚠️ Module ${name} non trouvé, ignoré.`);
                continue;
            }
            if (typeof mod.init !== 'function') {
                console.warn(`⚠️ Module ${name} n'a pas de méthode init().`);
                continue;
            }
            try {
                console.log(`🔄 Appel de init() pour ${name}...`);
                await mod.init({
                    eventBus: {
                        emit: (event, detail) => {
                            const evt = new CustomEvent(`app:${event}`, { detail });
                            eventBus.dispatchEvent(evt);
                        },
                        on: (event, callback) => {
                            eventBus.addEventListener(`app:${event}`, (e) => callback(e.detail));
                        }
                    }
                });
                console.log(`✅ ${name} initialisé avec succès.`);
            } catch (err) {
                console.error(`❌ Erreur lors de l'initialisation de ${name}:`, err);
            }
        }
        console.log('🎉 Tous les modules initialisés.');
        eventBus.dispatchEvent(new CustomEvent('app:ready', { detail: { timestamp: Date.now() } }));
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            console.log('📄 DOMContentLoaded, lancement de initModules()');
            initModules();
        });
    } else {
        console.log('📄 DOM déjà chargé, lancement immédiat de initModules()');
        initModules();
    }

    window.eventBus = eventBus;

    // =========================================
    // ÉCOUTEURS SPÉCIFIQUES
    // =========================================

    // Écouter les changements de catégorie de background
    document.getElementById('background-category')?.addEventListener('change', function(e) {
        console.log('🔄 Changement de catégorie:', e.target.value);
        // Émettre un événement pour le module background
        eventBus.dispatchEvent(new CustomEvent('app:background:change-category', {
            detail: { category: e.target.value }
        }));
    });

    // BOUTON DE DIAGNOSTIC
    document.getElementById('diagnostic-bg-btn')?.addEventListener('click', function() {
        const resultDiv = document.getElementById('diagnostic-result');
        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '🔍 Diagnostic en cours...<br>';
        
        let log = '';
        
        // 1. Vérifier si background module existe
        if (window.modules && window.modules.background) {
            log += '✅ window.modules.background existe<br>';
            
            // 2. Vérifier la fonction changeCategory
            if (typeof window.modules.background.changeCategory === 'function') {
                log += '✅ Fonction changeCategory existe<br>';
            } else {
                log += '❌ Fonction changeCategory manquante<br>';
            }
            
            // 3. Vérifier l'état des backgrounds
            if (window.modules.background._state) {
                log += '✅ _state existe<br>';
                log += `📁 Catégorie active: ${window.modules.background._state.activeCategory || 'non définie'}<br>`;
                log += `🖼️ Nombre d'images: ${window.modules.background._state.backgrounds?.length || 0}<br>`;
                log += `📂 Chemin: ${window.modules.background._state.backgroundsPath || 'non défini'}<br>`;
                
                // 4. Vérifier les catégories
                if (window.modules.background._state.categories) {
                    log += '✅ Catégories trouvées:<br>';
                    for (let cat in window.modules.background._state.categories) {
                        log += `   - ${cat}: ${window.modules.background._state.categories[cat].length} images<br>`;
                    }
                } else {
                    log += '❌ categories manquant<br>';
                }
            } else {
                log += '❌ _state manquant<br>';
            }
            
            // 5. Test manuel
            log += '<br>🔧 Test manuel: tape dans la console:<br>';
            log += '<code style="background: #333; padding: 2px 5px; border-radius: 3px;">window.modules.background.changeCategory("luffy")</code>';
            
        } else {
            log += '❌ window.modules.background n\'existe pas<br>';
            log += '➡️ Vérifie que background-manager.js est bien chargé dans le HTML<br>';
        }
        
        resultDiv.innerHTML = log;
    });

    // Écouter les changements de background confirmés
    eventBus.addEventListener('app:background:changed', (e) => {
        console.log('🖼️ Background changé:', e.detail);
    });
})();