/**
 * THE GRAND ARCHIVE - Service Worker
 * Version 1.0.0
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion du cache hors-ligne et des ressources
 * COMPORTEMENT : Cache les assets pour utilisation offline
 * 
 * Développé sur iPhone XR avec Koder
 * Guidé par Gemini et DeepSeek
 */

// sw.js - Service Worker pour cache INFINI
const CACHE_NAME = 'grand-archive-v5';  // Incrémente la version !
const VERSION = '5.0.0';

// Liste COMPLÈTE de tous les 17 modules
const FILES_TO_CACHE = [
    '/',
    '/index.html',
    '/style.css',
    '/main.js',
    '/manifest.json',
    '/about.json',                    // ← AJOUTÉ
    '/backgrounds/default-cover.jpg',
    
    // ✅ 17 MODULES (TOUS)
    '/modules/ui-core.js',
    '/modules/navigation.js',
    '/modules/panel-buttons.js',
    '/modules/content-loader.js',
    '/modules/player-interface.js',
    '/modules/sound-system.js',
    '/modules/local-library.js',
    '/modules/about-handler.js',
    '/modules/metadata-bot.js',
    '/modules/gallery-engine.js',
    '/modules/lyrics-sync.js',
    '/modules/radio-stream.js',
    '/modules/itunes-api.js',
    '/modules/lastfm-api.js',
    '/modules/offline-manager.js',
    '/modules/immersion-engine.js',
    '/modules/player-controls.js',
    
    // CDN (optionnel - certains peuvent être mis en cache)
    'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css',
    'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/howler/2.2.4/howler.min.js',
    'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
    'https://cdn.jsdelivr.net/npm/localforage@1.10.0/dist/localforage.min.js',
    'https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js',
    'https://cdn.jsdelivr.net/npm/infinite-scroll@4.0.1/dist/infinite-scroll.pkgd.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/jsmediatags/3.9.5/jsmediatags.min.js',
    'https://unpkg.com/id3js@2.0.0/dist/id3.js'
];

// Installation - mise en cache de TOUT
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('📦 Mise en cache de tous les fichiers...');
                return cache.addAll(FILES_TO_CACHE);
            })
            .then(() => self.skipWaiting())
    );
});

// Activation - nettoyage et prise de contrôle
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keyList => {
            return Promise.all(keyList.map(key => {
                if (key !== CACHE_NAME) {
                    console.log('🗑️ Suppression ancien cache:', key);
                    return caches.delete(key);
                }
            }));
        }).then(() => self.clients.claim())
    );
});

// Interception des requêtes - CACHE FIRST POUR TOUJOURS
self.addEventListener('fetch', event => {
    // Ne pas intercepter les requêtes vers les APIs
    if (event.request.url.includes('api.') || 
        event.request.url.includes('audioscrobbler') ||
        event.request.url.includes('radiofrance') ||
        event.request.url.includes('itunes')) {
        return;
    }
    
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) {
                    // Retourne le cache (même pour les CDN)
                    return response;
                }
                // Sinon va sur le réseau et met en cache
                return fetch(event.request).then(networkResponse => {
                    // Ne pas mettre en cache les réponses d'API
                    if (!networkResponse || networkResponse.status !== 200) {
                        return networkResponse;
                    }
                    return caches.open(CACHE_NAME).then(cache => {
                        cache.put(event.request, networkResponse.clone());
                        return networkResponse;
                    });
                });
            })
    );
});