/**
 * THE GRAND ARCHIVE - Offline Manager Module
 * Version 2.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion du cache et du mode hors-ligne
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const OfflineManager = {
    // Identité du module
    name: 'offline',
    dependencies: [], // Indépendant mais peut émettre des événements
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        version: {
            images: 'v1',
            api: 'v1',
            metadata: 'v1'
        },
        
        isReady: false,
        isOfflineMode: false,
        pendingSync: [],
        
        stats: {
            cachedImages: 0,
            cachedApiCalls: 0,
            cachedTracks: 0,
            lastSync: null
        },
        
        storageInstances: {
            imageCache: null,
            apiCache: null,
            metadataCache: null
        }
    },
    
    // Éléments DOM (cachés)
    _elements: {
        cachedImages: null,
        cachedApi: null,
        cachedTracks: null,
        cacheSize: null,
        storageUsed: null,
        networkStatus: null,
        clearCacheBtn: null
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('📦 OfflineManager: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Configurer le stockage
        this.configureStorage();
        
        // Nettoyer l'ancien cache
        await this.cleanOldCache();
        
        // Charger les statistiques
        await this.loadStats();
        
        // Vérifier l'état réseau
        this.checkOfflineStatus();
        
        // Attacher les écouteurs d'événements DOM
        this.attachEventListeners();
        
        // S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        this._state.isReady = true;
        this._state.initialized = true;
        
        console.log('✅ OfflineManager prêt');
        
        // Émettre un événement pour signaler la disponibilité
        this._state.eventBus.emit('offline:ready', { stats: this.getStats() });
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            cachedImages: document.getElementById('cached-images'),
            cachedApi: document.getElementById('cached-api'),
            cachedTracks: document.getElementById('cached-tracks'),
            cacheSize: document.getElementById('cache-size'),
            storageUsed: document.getElementById('storage-used'),
            networkStatus: document.getElementById('network-status'),
            clearCacheBtn: document.getElementById('clear-cache-btn')
        };
    },
    
    attachEventListeners() {
        // Bouton vider le cache
        if (this._elements.clearCacheBtn) {
            this._elements.clearCacheBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this._state.eventBus.emit('offline:clear-cache-request', {});
            });
        }
    },
    
    subscribeToEvents() {
        // Écouter les demandes de cache d'image
        this._state.eventBus.on('offline:cache-image', async (detail) => {
            const { url, id } = detail;
            if (url && id) {
                const result = await this.cacheImage(url, id);
                this._state.eventBus.emit('offline:image-cached', { id, success: !!result });
            }
        });
        
        // Écouter les demandes de récupération d'image
        this._state.eventBus.on('offline:get-image', async (detail) => {
            const { id, callbackId } = detail;
            const imageData = await this.getCachedImage(id);
            this._state.eventBus.emit('offline:image-retrieved', { id, data: imageData, callbackId });
        });
        
        // Écouter les demandes de cache d'API
        this._state.eventBus.on('offline:cache-api', async (detail) => {
            const { endpoint, data, ttl } = detail;
            await this.cacheApiResponse(endpoint, data, ttl);
        });
        
        // Écouter les demandes de récupération d'API
        this._state.eventBus.on('offline:get-api', async (detail) => {
            const { endpoint, ignoreTTL, callbackId } = detail;
            const data = await this.getCachedApiResponse(endpoint, ignoreTTL);
            this._state.eventBus.emit('offline:api-retrieved', { endpoint, data, callbackId });
        });
        
        // Écouter les demandes de cache de métadonnées
        this._state.eventBus.on('offline:cache-metadata', async (detail) => {
            const { trackId, metadata } = detail;
            await this.cacheTrackMetadata(trackId, metadata);
        });
        
        // Écouter les demandes de récupération de métadonnées
        this._state.eventBus.on('offline:get-metadata', async (detail) => {
            const { trackId, callbackId } = detail;
            const metadata = await this.getCachedTrackMetadata(trackId);
            this._state.eventBus.emit('offline:metadata-retrieved', { trackId, metadata, callbackId });
        });
        
        // Écouter les demandes de préchargement d'images
        this._state.eventBus.on('offline:prefetch-images', async (detail) => {
            const { urls } = detail;
            const count = await this.prefetchImages(urls);
            this._state.eventBus.emit('offline:images-prefetched', { count });
        });
        
        // Écouter les demandes de synchronisation
        this._state.eventBus.on('offline:sync-now', async () => {
            await this.syncNow();
        });
        
        // Écouter les demandes de vidage du cache
        this._state.eventBus.on('offline:clear-cache', async () => {
            await this.clearAllCache();
        });
        
        // Écouter les demandes d'état
        this._state.eventBus.on('offline:get-stats', () => {
            this._state.eventBus.emit('offline:stats', this.getStats());
        });
        
        // Écouter les événements réseau globaux
        window.addEventListener('online', () => this.handleNetworkOnline());
        window.addEventListener('offline', () => this.handleNetworkOffline());
    },
    
    // =========================================
    // CONFIGURATION STOCKAGE
    // =========================================
    configureStorage() {
        if (typeof localforage === 'undefined') {
            console.warn('📦 localforage non trouvé - Utilisation du fallback localStorage');
            this.createLocalForageFallback();
        } else {
            this._state.storageInstances.imageCache = localforage.createInstance({
                name: 'GrandArchive',
                storeName: 'images',
                description: 'Cache des images de couverture'
            });
            
            this._state.storageInstances.apiCache = localforage.createInstance({
                name: 'GrandArchive',
                storeName: 'api',
                description: 'Cache des réponses API'
            });
            
            this._state.storageInstances.metadataCache = localforage.createInstance({
                name: 'GrandArchive',
                storeName: 'metadata',
                description: 'Cache des métadonnées'
            });
            
            console.log('💾 Stockage IndexedDB configuré');
        }
    },
    
    createLocalForageFallback() {
        // Fallback localStorage si localforage manquant
        const createFallbackInstance = (storeName) => ({
            _storage: {},
            _name: storeName,
            
            async getItem(key) {
                const data = localStorage.getItem(`ga_${this._name}_${key}`);
                return data ? JSON.parse(data) : null;
            },
            
            async setItem(key, value) {
                localStorage.setItem(`ga_${this._name}_${key}`, JSON.stringify(value));
                return value;
            },
            
            async removeItem(key) {
                localStorage.removeItem(`ga_${this._name}_${key}`);
            },
            
            async clear() {
                Object.keys(localStorage).forEach(key => {
                    if (key.startsWith(`ga_${this._name}_`)) {
                        localStorage.removeItem(key);
                    }
                });
            },
            
            async keys() {
                const keys = [];
                Object.keys(localStorage).forEach(key => {
                    if (key.startsWith(`ga_${this._name}_`)) {
                        keys.push(key.replace(`ga_${this._name}_`, ''));
                    }
                });
                return keys;
            },
            
            async length() {
                let count = 0;
                Object.keys(localStorage).forEach(key => {
                    if (key.startsWith(`ga_${this._name}_`)) count++;
                });
                return count;
            }
        });
        
        this._state.storageInstances.imageCache = createFallbackInstance('images');
        this._state.storageInstances.apiCache = createFallbackInstance('api');
        this._state.storageInstances.metadataCache = createFallbackInstance('metadata');
        
        console.log('💾 Fallback localStorage créé');
    },
    
    // =========================================
    // NETTOYAGE DU CACHE
    // =========================================
    async cleanOldCache() {
        const ONE_WEEK = 7 * 24 * 60 * 60 * 1000;
        const now = Date.now();
        
        try {
            const apiCache = this._state.storageInstances.apiCache;
            if (apiCache) {
                const keys = await apiCache.keys();
                for (const key of keys) {
                    const data = await apiCache.getItem(key);
                    if (data && data.timestamp && (now - data.timestamp > ONE_WEEK)) {
                        await apiCache.removeItem(key);
                    }
                }
            }
            
            console.log('🧹 Ancien cache nettoyé');
        } catch (error) {
            console.warn('⚠️ Erreur nettoyage cache:', error);
        }
    },
    
    // =========================================
    // STATISTIQUES
    // =========================================
    async loadStats() {
        try {
            const imageCache = this._state.storageInstances.imageCache;
            const apiCache = this._state.storageInstances.apiCache;
            const metadataCache = this._state.storageInstances.metadataCache;
            
            if (imageCache) {
                this._state.stats.cachedImages = await imageCache.length() || 0;
            }
            if (apiCache) {
                this._state.stats.cachedApiCalls = await apiCache.length() || 0;
            }
            if (metadataCache) {
                this._state.stats.cachedTracks = await metadataCache.length() || 0;
            }
            
            this.updateStatsDisplay();
        } catch (error) {
            console.warn('⚠️ Erreur chargement stats:', error);
        }
    },
    
    updateStatsDisplay() {
        const stats = this._state.stats;
        
        if (this._elements.cachedImages) {
            this._elements.cachedImages.textContent = stats.cachedImages;
        }
        
        if (this._elements.cachedApi) {
            this._elements.cachedApi.textContent = stats.cachedApiCalls;
        }
        
        if (this._elements.cachedTracks) {
            this._elements.cachedTracks.textContent = stats.cachedTracks;
        }
        
        if (this._elements.cacheSize) {
            const totalItems = stats.cachedImages + stats.cachedApiCalls + stats.cachedTracks;
            const estimatedSize = totalItems * 50; // KB
            this._elements.cacheSize.textContent = estimatedSize < 1024 ? 
                `${estimatedSize} KB` : 
                `${(estimatedSize / 1024).toFixed(1)} MB`;
        }
        
        if (this._elements.storageUsed) {
            const totalItems = stats.cachedImages + stats.cachedApiCalls + stats.cachedTracks;
            const percent = Math.min(100, (totalItems / 500) * 100);
            this._elements.storageUsed.style.width = percent + '%';
        }
    },
    
    // =========================================
    // GESTION RÉSEAU
    // =========================================
    checkOfflineStatus() {
        this._state.isOfflineMode = !navigator.onLine;
        
        if (this._elements.networkStatus) {
            this._elements.networkStatus.textContent = this._state.isOfflineMode ? 'Hors-ligne' : 'En ligne';
            this._elements.networkStatus.style.color = this._state.isOfflineMode ? '#ff3b30' : '#4caf50';
        }
        
        document.body.classList.toggle('offline', this._state.isOfflineMode);
    },
    
    handleNetworkOnline() {
        console.log('🌐 Réseau disponible - Synchronisation...');
        this._state.isOfflineMode = false;
        document.body.classList.remove('offline');
        
        if (this._elements.networkStatus) {
            this._elements.networkStatus.textContent = 'En ligne';
            this._elements.networkStatus.style.color = '#4caf50';
        }
        
        this.syncNow();
        
        this._state.eventBus.emit('notification:show', {
            message: 'Connexion rétablie - Synchronisation...',
            type: 'success'
        });
    },
    
    handleNetworkOffline() {
        console.log('📴 Mode hors-ligne activé');
        this._state.isOfflineMode = true;
        document.body.classList.add('offline');
        
        if (this._elements.networkStatus) {
            this._elements.networkStatus.textContent = 'Hors-ligne';
            this._elements.networkStatus.style.color = '#ff3b30';
        }
        
        this._state.eventBus.emit('notification:show', {
            message: 'Mode hors-ligne - Utilisation du cache',
            type: 'info'
        });
    },
    
    // =========================================
    // API DE CACHE (interne)
    // =========================================
    async cacheImage(url, id) {
        if (!url || !id) return null;
        
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = async () => {
                    const base64data = reader.result;
                    
                    const imageCache = this._state.storageInstances.imageCache;
                    if (imageCache) {
                        await imageCache.setItem(id, {
                            data: base64data,
                            timestamp: Date.now(),
                            url: url
                        });
                        
                        this._state.stats.cachedImages++;
                        this.updateStatsDisplay();
                        console.log(`🖼️ Image mise en cache: ${id}`);
                    }
                    
                    resolve(base64data);
                };
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        } catch (error) {
            console.warn(`⚠️ Échec cache image ${id}:`, error);
            return null;
        }
    },
    
    async getCachedImage(id) {
        const imageCache = this._state.storageInstances.imageCache;
        if (!imageCache) return null;
        
        try {
            const cached = await imageCache.getItem(id);
            return cached ? cached.data : null;
        } catch (error) {
            console.warn(`⚠️ Erreur récupération image ${id}:`, error);
            return null;
        }
    },
    
    async cacheApiResponse(endpoint, data, ttl = 3600000) {
        if (!endpoint || !data) return;
        
        const key = `api_${btoa(endpoint).substring(0, 50)}`;
        
        try {
            const apiCache = this._state.storageInstances.apiCache;
            if (apiCache) {
                await apiCache.setItem(key, {
                    data: data,
                    timestamp: Date.now(),
                    ttl: ttl,
                    endpoint: endpoint
                });
                
                this._state.stats.cachedApiCalls++;
                this.updateStatsDisplay();
                console.log(`🌐 API mise en cache: ${endpoint.substring(0, 50)}...`);
            }
        } catch (error) {
            console.warn(`⚠️ Échec cache API ${endpoint}:`, error);
        }
    },
    
    async getCachedApiResponse(endpoint, ignoreTTL = false) {
        const apiCache = this._state.storageInstances.apiCache;
        if (!apiCache) return null;
        
        const key = `api_${btoa(endpoint).substring(0, 50)}`;
        
        try {
            const cached = await apiCache.getItem(key);
            
            if (!cached) return null;
            
            if (!ignoreTTL && cached.ttl && (Date.now() - cached.timestamp > cached.ttl)) {
                await apiCache.removeItem(key);
                return null;
            }
            
            return cached.data;
        } catch (error) {
            console.warn(`⚠️ Erreur récupération API ${endpoint}:`, error);
            return null;
        }
    },
    
    async cacheTrackMetadata(trackId, metadata) {
        if (!trackId || !metadata) return;
        
        try {
            const metadataCache = this._state.storageInstances.metadataCache;
            if (metadataCache) {
                await metadataCache.setItem(trackId, {
                    ...metadata,
                    _cachedAt: Date.now()
                });
                
                this._state.stats.cachedTracks++;
                this.updateStatsDisplay();
                console.log(`💿 Métadonnées mises en cache: ${trackId}`);
            }
        } catch (error) {
            console.warn(`⚠️ Échec cache métadonnées ${trackId}:`, error);
        }
    },
    
    async getCachedTrackMetadata(trackId) {
        const metadataCache = this._state.storageInstances.metadataCache;
        if (!metadataCache) return null;
        
        try {
            return await metadataCache.getItem(trackId);
        } catch (error) {
            console.warn(`⚠️ Erreur récupération métadonnées ${trackId}:`, error);
            return null;
        }
    },
    
    addToSyncQueue(data) {
        this._state.pendingSync.push({
            ...data,
            timestamp: Date.now()
        });
        
        if (navigator.onLine) {
            this.syncNow();
        }
    },
    
    async syncNow() {
        if (!navigator.onLine || this._state.pendingSync.length === 0) return;
        
        console.log(`🔄 Synchronisation de ${this._state.pendingSync.length} éléments...`);
        
        const toSync = [...this._state.pendingSync];
        this._state.pendingSync = [];
        
        for (const item of toSync) {
            try {
                // Ici, on pourrait émettre des événements pour chaque type de sync
                this._state.eventBus.emit('offline:sync-item', item);
                console.log('Sync item:', item);
            } catch (error) {
                console.warn('Échec sync, remise en file:', error);
                this._state.pendingSync.push(item);
            }
        }
        
        this._state.stats.lastSync = Date.now();
        console.log('✅ Synchronisation terminée');
        this._state.eventBus.emit('offline:sync-completed', { count: toSync.length });
    },
    
    async clearAllCache() {
        try {
            const { imageCache, apiCache, metadataCache } = this._state.storageInstances;
            
            if (imageCache) await imageCache.clear();
            if (apiCache) await apiCache.clear();
            if (metadataCache) await metadataCache.clear();
            
            this._state.stats = {
                cachedImages: 0,
                cachedApiCalls: 0,
                cachedTracks: 0,
                lastSync: this._state.stats.lastSync
            };
            
            this.updateStatsDisplay();
            console.log('🗑️ Cache vidé');
            
            this._state.eventBus.emit('notification:show', {
                message: 'Cache vidé avec succès',
                type: 'success'
            });
        } catch (error) {
            console.error('❌ Erreur vidage cache:', error);
        }
    },
    
    async prefetchImages(urls) {
        let count = 0;
        for (const [id, url] of Object.entries(urls)) {
            const cached = await this.getCachedImage(id);
            if (!cached) {
                await this.cacheImage(url, id);
                count++;
            }
        }
        console.log(`📸 Préchargement: ${count} nouvelles images`);
        return count;
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES (exposées pour compatibilité)
    // =========================================
    getStats() {
        return { ...this._state.stats };
    },
    
    isOffline() {
        return this._state.isOfflineMode;
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('📦 OfflineManager: Nettoyage...');
        
        window.removeEventListener('online', this.handleNetworkOnline);
        window.removeEventListener('offline', this.handleNetworkOffline);
        
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.offline = OfflineManager;

console.log('📦 OfflineManager: Module enregistré');