/**
 * THE GRAND ARCHIVE - Content Loader Module
 * Version 3.1.0 - Architecture Sandbox avec navigation améliorée
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Charger tous les contenus des vues (Browse, Radio, Library, etc.)
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const ContentLoader = {
    // Identité du module
    name: 'content',
    dependencies: ['ui', 'itunes', 'radio', 'local', 'metadata', 'offline'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        // Pour les callbacks asynchrones
        pendingRequests: new Map(),
        nextRequestId: 0,
        
        // Cache local
        stations: null,
        stationsRequested: false,
    },
    
    // Éléments DOM (cachés)
    _elements: {
        browseGrid: null,
        stationsContainer: null,
        libraryTracks: null,
        libraryHours: null,
        libraryFavorites: null,
        playlistsContainer: null,
        historyContainer: null,
        searchInput: null,
        searchBtn: null,
        searchResults: null,
        stageCenter: null,
    },
    
    // Référence au module UI
    _ui: null,
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('📦 ContentLoader: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Référence au module UI
        this._ui = window.modules?.ui;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        // Demander les stations radio
        this._requestStations();
        
        this._state.initialized = true;
        console.log('✅ ContentLoader prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            browseGrid: document.getElementById('browse-grid'),
            stationsContainer: document.getElementById('radio-stations'),
            libraryTracks: document.getElementById('library-tracks'),
            libraryHours: document.getElementById('library-hours'),
            libraryFavorites: document.getElementById('library-favorites'),
            playlistsContainer: document.getElementById('playlists-container'),
            historyContainer: document.getElementById('history-container'),
            searchInput: document.getElementById('search-input'),
            searchBtn: document.getElementById('search-btn'),
            searchResults: document.getElementById('search-results'),
            stageCenter: document.querySelector('.stage-center'),
        };
    },
    
    subscribeToEvents() {
        // Écouter les demandes de chargement de vues
        this._state.eventBus.on('content:load-view', (detail) => {
            const { view } = detail;
            this.loadView(view);
        });
        
        // Réponses des modules externes
        this._state.eventBus.on('itunes:top-songs-result', (detail) => this._handleItunesResponse(detail));
        this._state.eventBus.on('itunes:search-result', (detail) => this._handleItunesResponse(detail));
        this._state.eventBus.on('local:search-result', (detail) => this._handleLocalResponse(detail));
        this._state.eventBus.on('metadata:search-result', (detail) => this._handleMetadataResponse(detail));
        this._state.eventBus.on('history:search-result', (detail) => this._handleHistoryResponse(detail));
        this._state.eventBus.on('local:stats', (detail) => this._updateLibraryStats(detail));
        
        // Réponse des stations radio
        this._state.eventBus.on('radio:stations', (detail) => {
            console.log('📻 Stations radio reçues:', detail.stations?.length || 0);
            this._state.stations = detail.stations;
            
            // Si la vue radio est déjà ouverte, on met à jour
            if (document.getElementById('radio-view')?.style.display === 'block') {
                this.loadRadioContent();
            }
        });
        
        // Écouter les demandes spécifiques pour la radio
        this._state.eventBus.on('content:load-radio', () => {
            this.loadRadioContent();
        });
    },
    
    _requestStations() {
        if (this._state.stationsRequested) return;
        this._state.stationsRequested = true;
        console.log('📻 Demande des stations radio...');
        this._state.eventBus.emit('radio:get-stations', {});
    },
    
    // =========================================
    // CHARGEMENT D'UNE VUE
    // =========================================
    async loadView(view) {
        console.log(`📦 Chargement de la vue: ${view}`);
        
        // S'assurer que le stage-center est masqué pour toutes les vues sauf listen
        // (c'est géré par navigation.js, mais on le fait aussi ici par sécurité)
        if (this._elements.stageCenter && view !== 'listen') {
            this._elements.stageCenter.style.display = 'none';
        }
        
        switch(view) {
            case 'browse':
                await this.loadBrowseContent();
                break;
            case 'radio':
                await this.loadRadioContent();
                break;
            case 'library':
                await this.loadLibraryContent();
                break;
            case 'playlists':
                await this.loadPlaylistsContent();
                break;
            case 'history':
                await this.loadHistoryContent();
                break;
            case 'search':
                await this.loadSearchContent();
                break;
            default:
                console.warn(`📦 Vue inconnue: ${view}`);
        }
    },
    
    // =========================================
    // BROWSE - iTunes avec fallback local
    // =========================================
    async loadBrowseContent() {
        const browseGrid = this._elements.browseGrid;
        if (!browseGrid) {
            console.error('❌ browse-grid non trouvé');
            return;
        }
        
        // Afficher le loader
        browseGrid.innerHTML = this._getLoaderHTML('Chargement des découvertes...');
        
        try {
            // Essayer d'abord le cache rapide
            const quickResult = await this._requestItunesQuickTop();
            
            let songs = quickResult?.songs || [];
            
            if (!songs.length) {
                // Fallback API normale
                const result = await this._requestItunesTopSongs('fr', 'all', 20);
                songs = result?.songs || [];
            }
            
            // Fallback local
            if (!songs.length) {
                songs = this._getLocalTopSongs();
                console.log('📀 Utilisation des données locales de secours');
            }
            
            await this._renderBrowseGrid(songs);
            
            // Préchargement intelligent
            if (songs.length > 6) {
                this._state.eventBus.emit('itunes:prefetch-covers', { items: songs.slice(6, 12) });
            }
            
        } catch (error) {
            console.error('❌ Erreur chargement browse:', error);
            browseGrid.innerHTML = this._getErrorHTML('Erreur de chargement');
            
            // Fallback d'urgence
            const fallbackSongs = this._getLocalTopSongs();
            await this._renderBrowseGrid(fallbackSongs);
        }
    },
    
    _requestItunesTopSongs(country, genre, limit) {
        return new Promise((resolve) => {
            const callbackId = `browse_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('itunes:get-top-songs', {
                country, genre, limit,
                callbackId
            });
            
            // Timeout
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve({ songs: [] });
                }
            }, 5000);
        });
    },
    
    _requestItunesQuickTop() {
        return new Promise((resolve) => {
            const callbackId = `quick_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('itunes:get-quick-top', { callbackId });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    _handleItunesResponse(detail) {
        const { callbackId, songs, results } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ songs, results });
        }
    },
    
    _getLocalTopSongs() {
        // Utilise le module local s'il existe
        if (window.modules?.local?.getTopSongs) {
            return window.modules.local.getTopSongs();
        }
        // Fallback intégré
        return [
            { id: 1, name: 'Midnight Vibes', artist: 'Luna Ray', cover: 'backgrounds/default-cover.jpg' },
            { id: 2, name: 'Electric Dreams', artist: 'Neon Pulse', cover: 'backgrounds/default-cover.jpg' },
            { id: 3, name: 'Acoustic Sessions', artist: 'The Wanderers', cover: 'backgrounds/default-cover.jpg' },
            { id: 4, name: 'Deep Space', artist: 'Orbit', cover: 'backgrounds/default-cover.jpg' },
            { id: 5, name: 'Urban Flow', artist: 'Metro', cover: 'backgrounds/default-cover.jpg' }
        ];
    },
    
    async _renderBrowseGrid(songs) {
        const browseGrid = this._elements.browseGrid;
        if (!browseGrid) return;
        
        if (!songs || songs.length === 0) {
            browseGrid.innerHTML = this._getErrorHTML('Aucun contenu disponible');
            return;
        }
        
        // Générer le HTML
        browseGrid.innerHTML = songs.map((song, index) => {
            const trackData = {
                id: song.id || `local_${index}`,
                name: song.name || 'Titre inconnu',
                artist: song.artist || 'Artiste inconnu',
                cover: song.cover || 'backgrounds/default-cover.jpg',
                coverSmall: song.coverSmall || song.cover,
                previewUrl: song.previewUrl || null,
                duration: song.duration || 240
            };
            
            return `
                <div class="album-card" 
                     data-track='${JSON.stringify(trackData).replace(/'/g, "&apos;")}'
                     style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 12px; cursor: pointer; transition: all 0.2s;">
                    
                    <div style="width: 100%; aspect-ratio: 1; border-radius: 8px; overflow: hidden; margin-bottom: 8px; background: #1a1a1a;">
                        <img src="${trackData.cover}" 
                             alt="${trackData.name}"
                             style="width: 100%; height: 100%; object-fit: cover;"
                             onerror="this.src='backgrounds/default-cover.jpg'"
                             loading="lazy">
                    </div>
                    
                    <h4 style="margin: 0; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" 
                        title="${trackData.name}">
                        ${trackData.name}
                    </h4>
                    <p style="margin: 4px 0 0; opacity: 0.7; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" 
                       title="${trackData.artist}">
                        ${trackData.artist}
                    </p>
                    
                    ${trackData.previewUrl ? `
                        <span style="display: inline-block; margin-top: 6px; font-size: 9px; background: rgba(0,170,255,0.2); color: #00aaff; padding: 2px 6px; border-radius: 10px;">
                            <i class="bi bi-music-note"></i> 30s
                        </span>
                    ` : ''}
                </div>
            `;
        }).join('');
        
        // Attacher les événements de clic
        browseGrid.querySelectorAll('.album-card').forEach(card => {
            if (!card.hasAttribute('data-listener-ready')) {
                card.setAttribute('data-listener-ready', 'true');
                
                card.addEventListener('click', (e) => {
                    if (e.target.closest('.badge')) return;
                    
                    try {
                        const trackData = JSON.parse(card.dataset.track);
                        if (trackData) {
                            // Utiliser la nouvelle méthode pour jouer depuis browse
                            this.playTrackFromBrowse(trackData);
                        }
                    } catch (err) {
                        console.warn('⚠️ Erreur lecture:', err);
                    }
                });
            }
        });
    },
    
    // *** NOUVELLE MÉTHODE POUR JOUER UN MORCEAU DEPUIS BROWSE ***
    playTrackFromBrowse(trackData) {
        console.log('📦 Jouer depuis browse:', trackData);
        
        // Émettre le son
        this._state.eventBus.emit('sound:play', { sound: 'click' });
        
        // 1. Naviguer vers la vue Listen
        this._state.eventBus.emit('navigation:go-to', { view: 'listen' });
        
        // 2. Petit délai pour que la vue change
        setTimeout(() => {
            // 3. Définir le morceau courant dans la galerie
            this._state.eventBus.emit('gallery:set-current-track', { track: trackData });
            
            // 4. Lancer la lecture
            this._state.eventBus.emit('player:play-track', { track: trackData });
            
            // 5. Notifier
            this._state.eventBus.emit('notification:show', { 
                message: `🎵 ${trackData.name || trackData.title} - ${trackData.artist}` 
            });
        }, 100);
    },
    
    // =========================================
    // RADIO - Version améliorée
    // =========================================
    async loadRadioContent() {
        const container = this._elements.stationsContainer;
        if (!container) {
            console.error('❌ radio-stations non trouvé');
            return;
        }
        
        // Afficher le loader
        container.innerHTML = this._getLoaderHTML('Chargement des stations radio...');
        
        // Si pas de stations, demander et attendre
        if (!this._state.stations || this._state.stations.length === 0) {
            this._requestStations();
            
            // Attendre max 2 secondes
            for (let i = 0; i < 20; i++) {
                await new Promise(r => setTimeout(r, 100));
                if (this._state.stations && this._state.stations.length > 0) break;
            }
        }
        
        const stations = this._state.stations || [];
        
        if (!stations.length) {
            container.innerHTML = `
                <div style="grid-column:1/-1; text-align:center; padding:50px;">
                    <i class="bi bi-wifi-off" style="font-size:40px; opacity:0.5;"></i>
                    <p style="margin:20px 0;">Aucune station disponible</p>
                    <button onclick="window.modules?.radio?.retryLoad?.()" class="theme-btn">
                        <i class="bi bi-arrow-repeat"></i> Réessayer
                    </button>
                </div>
            `;
            return;
        }
        
        // Grouper par pays
        const groups = {
            'FR': { name: '🇫🇷 France', stations: stations.filter(s => s.country === 'FR') },
            'CH': { name: '🇨🇭 Suisse', stations: stations.filter(s => s.country === 'CH') },
            'BE': { name: '🇧🇪 Belgique', stations: stations.filter(s => s.country === 'BE') },
            'UK': { name: '🇬🇧 Royaume-Uni', stations: stations.filter(s => s.country === 'UK') },
            'US': { name: '🇺🇸 États-Unis', stations: stations.filter(s => s.country === 'US') },
            'other': { name: '🌍 International', stations: stations.filter(s => !['FR', 'CH', 'BE', 'UK', 'US'].includes(s.country)) }
        };
        
        let html = '';
        
        for (const [code, group] of Object.entries(groups)) {
            if (group.stations.length === 0) continue;
            
            html += `
                <div style="grid-column:1/-1; margin:20px 0 10px;">
                    <h3 style="color:var(--neon-accent); display:flex; align-items:center; gap:8px;">
                        ${group.name}
                        <span style="font-size:12px; opacity:0.5;">${group.stations.length} stations</span>
                    </h3>
                </div>
            `;
            
            html += group.stations.map(station => {
                const bitrate = station.url?.includes('128') ? '128k' : 
                               station.url?.includes('96') ? '96k' : 
                               station.url?.includes('64') ? '64k' : 'HD';
                
                return `
                    <div class="radio-station" data-id="${station.id}"
                         style="background: rgba(255,255,255,0.05);
                                border-radius: 20px; padding: 20px; cursor: pointer;
                                transition: all 0.3s ease; border: 1px solid rgba(255,255,255,0.1);
                                display: flex; flex-direction: column; align-items: center;
                                text-align: center; gap: 8px;
                                backdrop-filter: blur(10px);">
                        
                        <i class="bi bi-${station.icon || 'radio'}" 
                           style="font-size: 40px; color: ${station.color || '#ff0055'};"></i>
                        
                        <h3 style="margin:0; font-size:16px;">${station.name}</h3>
                        <p style="margin:0; font-size:13px; opacity:0.7;">${station.genre || 'Radio'}</p>
                        
                        <div style="display:flex; gap:5px; margin-top:5px; flex-wrap:wrap; justify-content:center;">
                            <span class="badge" style="background:rgba(255,255,255,0.1); padding:4px 8px; border-radius:12px; font-size:10px;">
                                ${station.country || '🌍'}
                            </span>
                            <span class="badge" style="background:rgba(255,255,255,0.1); padding:4px 8px; border-radius:12px; font-size:10px;">
                                ${station.language === 'fr' ? '🇫🇷' : '🇬🇧'}
                            </span>
                            <span class="badge" style="background:rgba(0,255,0,0.2); color:#4caf50; padding:4px 8px; border-radius:12px; font-size:10px;">
                                ${bitrate}
                            </span>
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        html += `
            <div style="grid-column:1/-1; text-align:center; margin-top:30px; padding:15px; 
                        background:rgba(0,255,0,0.05); border-radius:20px; font-size:12px;">
                <i class="bi bi-sd-card" style="color:#4caf50;"></i>
                Mode économie de données activé - Qualité optimisée
            </div>
        `;
        
        container.innerHTML = html;
        
        // Événements de clic
        container.querySelectorAll('.radio-station').forEach(el => {
            el.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                
                const stationId = el.dataset.id;
                const station = stations.find(s => s.id === stationId);
                
                if (station) {
                    // Animation
                    el.style.transform = 'scale(0.95)';
                    setTimeout(() => el.style.transform = 'scale(1)', 200);
                    
                    // Lancer la lecture
                    this._state.eventBus.emit('radio:play', { stationId });
                    this._state.eventBus.emit('notification:show', { message: `📻 ${station.name}` });
                }
            });
        });
    },
    
    // =========================================
    // LIBRARY
    // =========================================
    async loadLibraryContent() {
        // Demander les stats au module local
        this._state.eventBus.emit('local:get-stats', {});
        
        // Afficher les titres récents si disponibles
        const recentEl = document.getElementById('recently-listened');
        if (recentEl && window.modules?.local?._state?.tracks?.length > 0) {
            const tracks = window.modules.local._state.tracks.slice(0, 10);
            recentEl.innerHTML = tracks.map(track => `
                <div class="album-card local-track" onclick="window.modules?.local?.playLocalTrack('${track.id}')">
                    <img src="${track.cover || 'backgrounds/default-cover.jpg'}" onerror="this.src='backgrounds/default-cover.jpg'">
                    <h4>${track.title}</h4>
                    <p>${track.artist}</p>
                </div>
            `).join('');
        }
    },
    
    _updateLibraryStats(stats) {
        const { tracksEl, hoursEl, favoritesEl } = this._elements;
        if (tracksEl) tracksEl.textContent = stats.tracks || '0';
        if (hoursEl) hoursEl.textContent = stats.hours || '0';
        if (favoritesEl) {
            try {
                const favs = JSON.parse(localStorage.getItem('favorites') || '[]').length;
                favoritesEl.textContent = favs;
            } catch {
                favoritesEl.textContent = '0';
            }
        }
    },
    
    // =========================================
    // PLAYLISTS
    // =========================================
    async loadPlaylistsContent() {
        const container = this._elements.playlistsContainer;
        if (!container) return;
        
        if (window.modules?.metadata?.getPlaylists) {
            const playlists = window.modules.metadata.getPlaylists();
            if (playlists.length > 0) {
                container.innerHTML = playlists.map(playlist => `
                    <div class="playlist-card" onclick="window.modules?.metadata?.openPlaylist('${playlist.id}')">
                        <i class="bi bi-list-ul" style="font-size: 40px; color: var(--neon-accent);"></i>
                        <h4>${playlist.name}</h4>
                        <p>${playlist.tracks.length} titres</p>
                    </div>
                `).join('');
                return;
            }
        }
        
        container.innerHTML = `<div style="grid-column:1/-1; text-align:center; padding:40px;">
            <i class="bi bi-plus-circle" style="font-size:40px; color: var(--neon-accent);"></i>
            <p style="margin-top: 10px;">Créez votre première playlist</p>
            <button onclick="window.modules?.metadata?.createPlaylist?.()" class="theme-btn" style="margin-top: 10px;">
                <i class="bi bi-plus"></i> Nouvelle playlist
            </button>
        </div>`;
    },
    
    // =========================================
    // HISTORIQUE
    // =========================================
    async loadHistoryContent() {
        const container = this._elements.historyContainer;
        if (!container) return;
        
        try {
            const history = JSON.parse(localStorage.getItem('play-history') || '[]');
            if (history.length === 0) {
                container.innerHTML = '<div style="text-align:center; padding:40px;">Aucun historique</div>';
                return;
            }
            
            container.innerHTML = history.map((item, index) => `
                <div class="history-item" onclick="window.modules?.content?.playTrackFromBrowse(${JSON.stringify(item).replace(/'/g, "&apos;")})"
                     style="display: flex; align-items: center; gap: 15px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 10px; margin-bottom: 10px; cursor: pointer;">
                    <img src="${item.cover || 'backgrounds/default-cover.jpg'}" style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover;">
                    <div style="flex:1;">
                        <div style="font-weight: bold;">${item.name || item.title}</div>
                        <div style="font-size: 12px; opacity: 0.7;">${item.artist}</div>
                    </div>
                    <div style="font-size: 10px; opacity: 0.5;">${new Date(item.playedAt).toLocaleTimeString()}</div>
                </div>
            `).join('');
        } catch (e) {
            container.innerHTML = '<div style="text-align:center; padding:40px;">Erreur chargement historique</div>';
        }
    },
    
    // =========================================
    // RECHERCHE
    // =========================================
    async loadSearchContent() {
        const searchInput = this._elements.searchInput;
        const searchBtn = this._elements.searchBtn;
        const resultsEl = this._elements.searchResults;
        
        if (!searchInput || !searchBtn || !resultsEl) return;
        
        // Nettoyer les anciens écouteurs
        const newSearchInput = searchInput.cloneNode(true);
        const newSearchBtn = searchBtn.cloneNode(true);
        searchInput.parentNode.replaceChild(newSearchInput, searchInput);
        searchBtn.parentNode.replaceChild(newSearchBtn, searchBtn);
        
        this._elements.searchInput = newSearchInput;
        this._elements.searchBtn = newSearchBtn;
        
        let searchTimeout;
        let currentSource = 'all';
        
        // Créer les onglets
        this._createSearchTabs(resultsEl);
        
        const performSearch = async (query, source) => {
            if (!query || query.length < 2) {
                resultsEl.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px;">Entrez au moins 2 caractères</div>';
                return;
            }
            
            resultsEl.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px;"><i class="bi bi-arrow-repeat spin"></i><p>Recherche en cours...</p></div>';
            
            const results = [];
            
            // iTunes
            if (source === 'all' || source === 'itunes') {
                const itunesResult = await this._requestItunesSearch(query, 15);
                if (itunesResult?.results) {
                    results.push(...itunesResult.results.map(track => ({
                        ...track,
                        source: 'itunes',
                        sourceName: 'iTunes'
                    })));
                }
            }
            
            // Local
            if (source === 'all' || source === 'local') {
                const localResult = await this._requestLocalSearch(query);
                if (localResult?.tracks) {
                    results.push(...localResult.tracks.map(track => ({
                        ...track,
                        source: 'local',
                        sourceName: 'Bibliothèque'
                    })));
                }
            }
            
            // Metadata
            if (source === 'all' || source === 'metadata') {
                const metadataResult = await this._requestMetadataSearch(query);
                if (metadataResult?.tracks) {
                    results.push(...metadataResult.tracks.map(track => ({
                        ...track,
                        source: 'metadata',
                        sourceName: 'Métadonnées'
                    })));
                }
            }
            
            // Historique
            if (source === 'all' || source === 'history') {
                const historyResult = await this._requestHistorySearch(query);
                if (historyResult?.tracks) {
                    results.push(...historyResult.tracks.map(track => ({
                        ...track,
                        source: 'history',
                        sourceName: 'Historique'
                    })));
                }
            }
            
            // Trier par pertinence
            results.sort((a, b) => {
                if (a.source === 'itunes' && b.source !== 'itunes') return -1;
                if (a.source !== 'itunes' && b.source === 'itunes') return 1;
                return 0;
            });
            
            if (results.length === 0) {
                resultsEl.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px;">Aucun résultat trouvé</div>';
                return;
            }
            
            // Afficher les résultats
            resultsEl.innerHTML = results.map((track, index) => {
                const trackData = {
                    id: track.id || `search_${Date.now()}_${index}`,
                    name: track.name || track.title || 'Titre inconnu',
                    artist: track.artist || 'Artiste inconnu',
                    cover: track.cover || track.coverSmall || 'backgrounds/default-cover.jpg',
                    previewUrl: track.previewUrl || null,
                    source: track.source
                };
                
                let sourceColor = '#888';
                let sourceIcon = 'bi-question-circle';
                
                if (track.source === 'itunes') {
                    sourceColor = '#00aaff';
                    sourceIcon = 'bi-cloud';
                } else if (track.source === 'local' || track.source === 'metadata') {
                    sourceColor = '#4caf50';
                    sourceIcon = 'bi-folder';
                } else if (track.source === 'history') {
                    sourceColor = '#ffaa00';
                    sourceIcon = 'bi-clock-history';
                }
                
                return `
                    <div class="search-result-item" data-track='${JSON.stringify(trackData).replace(/'/g, "&apos;")}'
                         style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 12px; cursor: pointer; transition: all 0.2s; position: relative;">
                        
                        <div style="position: absolute; top: 5px; right: 5px; background: ${sourceColor}; color: white; padding: 2px 8px; border-radius: 12px; font-size: 9px; display: flex; align-items: center; gap: 3px;">
                            <i class="bi ${sourceIcon}"></i> ${track.sourceName || track.source}
                        </div>
                        
                        <div style="display: flex; gap: 12px; align-items: center;">
                            <img src="${trackData.cover}" style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover;"
                                 onerror="this.src='backgrounds/default-cover.jpg'">
                            
                            <div style="flex: 1; min-width: 0;">
                                <div style="font-weight: bold; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    ${trackData.name}
                                    ${trackData.previewUrl ? '<span style="margin-left: 5px; font-size: 9px; background: rgba(0,170,255,0.2); color: #00aaff; padding: 2px 6px; border-radius: 10px;">▶️ 30s</span>' : ''}
                                </div>
                                <div style="font-size: 12px; opacity: 0.7; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    ${trackData.artist}
                                </div>
                            </div>
                            
                            <i class="bi bi-play-circle-fill" style="color: var(--neon-accent); font-size: 24px;"></i>
                        </div>
                    </div>
                `;
            }).join('');
            
            // Événements de clic
            resultsEl.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', () => {
                    try {
                        const trackData = JSON.parse(item.dataset.track);
                        this.playTrackFromBrowse(trackData);
                    } catch (err) {
                        console.warn('⚠️ Erreur lecture:', err);
                    }
                });
            });
        };
        
        // Gestionnaire d'input
        newSearchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const q = e.target.value.trim();
            if (q.length < 2) {
                resultsEl.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px;">Entrez au moins 2 caractères</div>';
                return;
            }
            searchTimeout = setTimeout(() => performSearch(q, currentSource), 500);
        });
        
        // Bouton de recherche
        newSearchBtn.addEventListener('click', () => {
            const q = newSearchInput.value.trim();
            if (q.length >= 2) performSearch(q, currentSource);
        });
    },
    
    _createSearchTabs(container) {
        if (document.getElementById('search-tabs')) return;
        
        const tabsDiv = document.createElement('div');
        tabsDiv.id = 'search-tabs';
        tabsDiv.style.cssText = `
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: center;
            flex-wrap: wrap;
        `;
        
        const tabs = [
            { id: 'all', label: 'Tous', icon: 'bi-search' },
            { id: 'itunes', label: 'iTunes', icon: 'bi-cloud' },
            { id: 'local', label: 'Bibliothèque', icon: 'bi-folder' },
            { id: 'history', label: 'Historique', icon: 'bi-clock-history' }
        ];
        
        let currentSource = 'all';
        
        tabs.forEach(tab => {
            const tabBtn = document.createElement('button');
            tabBtn.className = 'search-tab';
            tabBtn.dataset.source = tab.id;
            tabBtn.style.cssText = `
                background: ${tab.id === 'all' ? 'var(--neon-accent)' : 'rgba(255,255,255,0.1)'};
                color: ${tab.id === 'all' ? 'black' : 'white'};
                border: none;
                padding: 8px 16px;
                border-radius: 30px;
                cursor: pointer;
                font-size: 13px;
                display: flex;
                align-items: center;
                gap: 5px;
                transition: all 0.2s;
            `;
            tabBtn.innerHTML = `<i class="bi ${tab.icon}"></i> ${tab.label}`;
            
            tabBtn.addEventListener('click', () => {
                document.querySelectorAll('.search-tab').forEach(btn => {
                    btn.style.background = 'rgba(255,255,255,0.1)';
                    btn.style.color = 'white';
                });
                tabBtn.style.background = 'var(--neon-accent)';
                tabBtn.style.color = 'black';
                
                currentSource = tab.id;
                const searchInput = this._elements.searchInput;
                if (searchInput.value.trim().length >= 2) {
                    searchInput.dispatchEvent(new Event('input'));
                }
            });
            
            tabsDiv.appendChild(tabBtn);
        });
        
        container.parentNode.insertBefore(tabsDiv, container);
    },
    
    _requestItunesSearch(query, limit) {
        return new Promise((resolve) => {
            const callbackId = `search_itunes_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('itunes:search', {
                term: query,
                limit,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 5000);
        });
    },
    
    _requestLocalSearch(query) {
        return new Promise((resolve) => {
            const callbackId = `search_local_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('local:search', {
                query,
                limit: 15,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    _requestMetadataSearch(query) {
        return new Promise((resolve) => {
            const callbackId = `search_metadata_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('metadata:search', {
                query,
                limit: 10,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    _requestHistorySearch(query) {
        return new Promise((resolve) => {
            const callbackId = `search_history_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('history:search', {
                query,
                limit: 10,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    _handleLocalResponse(detail) {
        const { callbackId, tracks } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ tracks });
        }
    },
    
    _handleMetadataResponse(detail) {
        const { callbackId, tracks } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ tracks });
        }
    },
    
    _handleHistoryResponse(detail) {
        const { callbackId, tracks } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ tracks });
        }
    },
    
    // =========================================
    // UTILITAIRES
    // =========================================
    _getLoaderHTML(message = 'Chargement...') {
        if (this._ui?.getLoaderHTML) {
            return this._ui.getLoaderHTML(message);
        }
        return `<div style="grid-column:1/-1; text-align:center; padding:50px;">
            <i class="bi bi-arrow-repeat spin" style="font-size:40px; color:var(--neon-accent);"></i>
            <p>${message}</p>
        </div>`;
    },
    
    _getErrorHTML(message = 'Erreur de chargement') {
        if (this._ui?.getErrorHTML) {
            return this._ui.getErrorHTML(message);
        }
        return `<div style="grid-column:1/-1; text-align:center; padding:50px; color:var(--text-secondary);">
            <i class="bi bi-exclamation-circle" style="font-size:40px;"></i>
            <p>${message}</p>
        </div>`;
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('📦 ContentLoader: Nettoyage...');
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.content = ContentLoader;

console.log('📦 ContentLoader: Module enregistré');