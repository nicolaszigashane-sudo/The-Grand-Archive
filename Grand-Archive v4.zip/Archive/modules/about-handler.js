/**
 * THE GRAND ARCHIVE - About Handler Module
 * Version 2.3.0 - Architecture Sandbox avec contenu intégré
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gérer l'affichage des informations "À propos" dans son propre panel
 * COMPORTEMENT : Pure sandbox - ne communique que par événements
 */


const AboutHandler = {
    // Identité du module
    name: 'about',
    dependencies: ['ui', 'sound'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        contentLoaded: false,
        lastError: null,
        currentTheme: 'default'
    },
    
    // Données "À propos" intégrées directement
    _aboutData: {
        app: {
            name: "The Grand Archive",
            version: "3.0.0",
            build: "2024-03-06",
            author: "Créateur indépendant",
            license: "MIT",
            repository: "https://github.com/votre-repo"
        },
        
        story: {
            origin: "L'idée de The Grand Archive est née d'une frustration : les lecteurs de musique modernes sont soit trop complexes, soit trop fades. L'objectif était de créer une expérience musicale qui soit à la fois visuellement époustouflante et technologiquement avancée, avec une interface cristalline qui met la musique au premier plan.",
            
            creation: "Le développement a commencé comme un défi personnel : concevoir une interface en 3 blocs de glace avec une transparence pure, sans effet de flou, pour un rendu aussi net que du cristal. Ce qui devait être un prototype est rapidement devenu un projet ambitieux avec l'aide d'un assistant IA qui a accompagné chaque étape du développement, de la conception à l'optimisation.",
            
            challenges: [
                "La gestion des 3 blocs de glace avec des proportions parfaites sur tous les écrans (mobile, tablette, desktop) a nécessité de nombreux ajustements responsive.",
                "L'implémentation du mode immersion avec importation de vidéos dans IndexedDB a été complexe, notamment pour la gestion de la mémoire et la lecture en arrière-plan.",
                "La synchronisation des 8 modules métier sans créer de conflits a demandé une architecture modulaire pensée dès le départ.",
                "Le débuggage du module PlayerControls qui refusait de s'initialiser correctement a pris des heures avant de trouver l'ordre d'exécution idéal.",
                "La création du design cristallin avec reflets liquides et transparence réglable a nécessité des centaines d'ajustements CSS."
            ],
            
            timeframe: "Le projet a été développé sur une période intensive de plusieurs jours, avec des sessions de codage allant jusqu'à 12 heures d'affilée pour peaufiner chaque détail. Au total, environ 80 heures de développement pur, sans compter la phase de conception et les tests sur différents appareils.",
            
            assistance: "Le développement a été grandement accéléré grâce à l'assistance d'une IA qui a aidé à structurer le code, résoudre les bugs complexes et optimiser les performances. Cette collaboration homme-machine a permis de réaliser en quelques jours ce qui aurait pris des semaines en solo."
        },
        
        description: {
            short: "Application musicale cristalline",
            long: "The Grand Archive est une application de musique immersive avec une interface en 3 blocs de glace, un mode immersion vidéo, et une gestion complète de bibliothèque musicale. L'objectif est de créer l'expérience d'écoute ultime, où l'interface disparaît pour ne laisser place qu'à la musique et aux émotions."
        },
        
        features: [
            {
                name: "3 Ice Blocks",
                description: "Interface en trois blocs transparents : navigation, informations, contrôles",
                icon: "bi-layers",
                status: "stable"
            },
            {
                name: "Mode Immersion",
                description: "Vidéos d'ambiance en arrière-plan avec paroles synchronisées",
                icon: "bi-eye-fill",
                status: "stable",
                details: {
                    videos: "Importez vos propres vidéos (max 100 MB)",
                    lyrics: "Paroles synchronisées avec la musique",
                    controls: "Player réapparaît au survol"
                }
            },
            {
                name: "Radio Streaming",
                description: "Écoutez des stations de musique et d'information",
                icon: "bi-wifi",
                status: "stable",
                stations: {
                    music: ["FIP", "Nova", "Jazz", "Rock"],
                    news: ["RFI", "France 24", "BBC", "CNN"]
                }
            },
            {
                name: "Bibliothèque locale",
                description: "Importez et gérez votre musique locale",
                icon: "bi-bookmark",
                status: "beta",
                features: [
                    "Scan de dossiers",
                    "Extraction ID3",
                    "Playlists personnalisées",
                    "Recherche"
                ]
            },
            {
                name: "Intégration APIs",
                description: "Connexion aux services musicaux",
                icon: "bi-cloud",
                status: "stable",
                apis: [
                    "Last.fm (biographies, tags)",
                    "iTunes (covers, extraits 30s)",
                    "Genius (paroles)",
                    "Audd.io (reconnaissance)"
                ]
            },
            {
                name: "Thèmes cristallins",
                description: "6 thèmes de couleurs",
                icon: "bi-brush",
                status: "stable",
                themes: [
                    "VisionOS (rose)",
                    "Deep Space (bleu)",
                    "Midnight (violet)",
                    "Aurora (vert)",
                    "Sunset (orange)",
                    "Forest (vert forêt)"
                ]
            }
        ],
        
        currentCapabilities: {
            working: [
                "Interface 3 blocs de glace responsive",
                "6 thèmes cristallins avec changement dynamique",
                "Transparence réglable en temps réel",
                "Ghost UI (disparition après inactivité)",
                "Mode immersion avec vidéos importées",
                "12 stations radio (FIP, RFI, France 24, etc.)",
                "Recherche iTunes (covers, extraits 30s)",
                "Cache intelligent avec IndexedDB",
                "Service Worker pour fonctionnement hors-ligne",
                "Tous les contrôles player (volume, favoris, répétition, aléatoire, vitesse)",
                "Plein écran",
                "Toasts notifications",
                "Animations GSAP fluides"
            ],
            
            notWorking: [
                "Lecture audio locale (nécessite intégration Howler.js)",
                "Extraction ID3 en temps réel (bibliothèques présentes mais non actives)",
                "Synchronisation Last.fm (clé API à configurer)",
                "Paroles Genius (clé API requise)",
                "Reconnaissance Audd.io (clé API requise)",
                "Scan automatique des dossiers musicaux (nécessite interaction utilisateur)",
                "Égaliseur graphique (interface prête mais filtres audio non connectés)",
                "Mode karaoké (interface prête mais non implémenté)",
                "Visualiseur audio (canvas présent mais inactif)"
            ]
        },
        
        futureVision: {
            shortTerm: [
                "Connecter Howler.js pour la lecture audio réelle",
                "Activer l'extraction ID3 avec jsmediatags",
                "Finaliser l'égaliseur avec Web Audio API",
                "Ajouter le support des playlists dynamiques",
                "Implémenter le mode karaoké avec surlignage des paroles"
            ],
            longTerm: [
                "Support des podcasts et des livres audio",
                "Intégration Spotify Connect et Apple Music",
                "Version mobile native avec React Native",
                "Application desktop avec Tauri (Windows/Mac/Linux)",
                "Synchronisation cloud des préférences",
                "Recommandations musicales par IA",
                "Mode social (partage d'écoute, playlists collaboratives)",
                "Support des formats audio haute résolution (FLAC, ALAC)"
            ],
            dream: "Faire de The Grand Archive le lecteur de musique ultime, où l'interface disparaît complètement pour ne laisser place qu'à une expérience immersive totale, avec des visuels générés en temps réel par l'IA en fonction de la musique jouée."
        },
        
        technologies: {
            cdn: [
                { name: "GSAP", usage: "Animations fluides des boutons, transitions et effets visuels" },
                { name: "Howler.js", usage: "Gestion audio, lecture de streams radio et extraits musicaux" },
                { name: "Swiper", usage: "Galerie 3D des albums avec swipe tactile" },
                { name: "localforage", usage: "Stockage IndexedDB pour les vidéos importées et le cache" },
                { name: "HLS.js", usage: "Streaming HLS pour les stations radio" },
                { name: "Infinite Scroll", usage: "Chargement infini dans la galerie Browse" },
                { name: "jsmediatags", usage: "Extraction des métadonnées ID3 des fichiers audio" },
                { name: "id3js", usage: "Bibliothèque de secours pour l'extraction ID3" }
            ],
            apis: [
                { name: "iTunes API", usage: "Recherche de covers d'albums, extraits 30s, tops tendances" },
                { name: "Last.fm API", usage: "Biographies d'artistes, tags, morceaux similaires" },
                { name: "Radio France API", usage: "Métadonnées des stations FIP en temps réel" },
                { name: "Genius API", usage: "Paroles complètes (avec clé API)" },
                { name: "Audd.io API", usage: "Reconnaissance de morceaux (avec clé API)" }
            ],
            fonts: [
                { name: "Ubuntu", usage: "Police principale pour l'interface" },
                { name: "Dancing Script", usage: "Police cursive pour les titres et paroles" }
            ]
        },
        
        requirements: {
            browser: ["Chrome 80+", "Firefox 75+", "Safari 13+", "Edge 80+"],
            storage: "500 MB recommandé pour les vidéos",
            internet: "Requis pour les APIs (hors-ligne partiel)"
        },
        
        limitations: {
            mobile: "Certaines fonctionnalités peuvent être limitées sur mobile (manque de place pour les 3 blocs)",
            video: "L'import vidéo nécessite un navigateur récent supportant IndexedDB",
            scan: "Le scan de dossiers nécessite l'API File System Access (Chrome uniquement)",
            audio: "La lecture audio locale nécessite des fichiers MP3/FLAC accessibles"
        },
        
        credits: {
            developer: "Un passionné de musique et de design",
            design: "Cristal Design System - Inspiré par l'esthétique VisionOS et la transparence pure",
            icons: "Bootstrap Icons - La plus belle bibliothèque d'icônes open-source",
            assistant: "IA de développement - Pour avoir rendu possible ce projet en un temps record",
            inspiration: "Apple VisionOS, les interfaces de verre et le design liquide",
            libraries: [
                "GSAP (animations de classe mondiale)",
                "Howler.js (lecture audio sans prise de tête)",
                "HLS.js (streaming adaptatif)",
                "localforage (stockage local simplifié)",
                "jsmediatags (extraction ID3)",
                "Swiper (toucher 3D)"
            ]
        },
        
        thankYou: "Un immense merci à tous ceux qui testeront, utiliseront et amélioreront The Grand Archive. Cette application est née d'une passion et d'une obsession pour le beau et le fonctionnel. Chaque pixel, chaque animation, chaque ligne de code a été pensée pour vous offrir la meilleure expérience musicale possible."
    },
    
    // Références aux éléments DOM (cachées)
    _elements: {
        aboutContent: null,
        aboutView: null,
        infoPanel: null,
        closeBtn: null,
        aboutBtn: null
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('📄 AboutHandler: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // 1. Cacher les éléments DOM
        this.cacheElements();
        
        // 2. Configurer les écouteurs d'événements DOM
        this.setupEventListeners();
        
        // 3. S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        // 4. Appliquer le thème actuel au bouton
        const savedTheme = localStorage.getItem('grand-archive-theme') || 'default';
        this._state.currentTheme = savedTheme;
        this._applyThemeToUI(this._getThemeColor(savedTheme));
        
        this._state.initialized = true;
        console.log('✅ AboutHandler prêt');
        
        return this;
    },
    
    // =========================================
    // CACHE DES ÉLÉMENTS DOM
    // =========================================
    cacheElements() {
        this._elements = {
            aboutContent: document.getElementById('about-content'),
            aboutView: document.getElementById('about-view'),
            infoPanel: document.getElementById('info-panel'),
            closeBtn: document.getElementById('close-about'),
            aboutBtn: document.getElementById('show-about-btn')
        };
        
        const missing = Object.entries(this._elements)
            .filter(([key, el]) => !el && key !== 'aboutBtn')
            .map(([key]) => key);
        
        if (missing.length > 0) {
            console.warn('📄 AboutHandler: Éléments manquants', missing);
        }
    },
    
    // =========================================
    // ÉCOUTEURS D'ÉVÉNEMENTS DOM
    // =========================================
    setupEventListeners() {
        // Bouton "Voir les détails" dans les paramètres
        if (this._elements.aboutBtn) {
            console.log('📄 AboutHandler: Écouteur ajouté sur le bouton');
            
            this._elements.aboutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this._state.eventBus.emit('about:open', {
                    source: 'settings-button',
                    timestamp: Date.now()
                });
            });
        }
        
        // Bouton de fermeture du panneau À propos
        if (this._elements.closeBtn) {
            this._elements.closeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this._state.eventBus.emit('about:close', {
                    source: 'close-button',
                    timestamp: Date.now()
                });
            });
        }
    },
    
    // =========================================
    // ABONNEMENT AUX ÉVÉNEMENTS
    // =========================================
    subscribeToEvents() {
        this._state.eventBus.on('about:open', () => {
            console.log('📄 AboutHandler: Événement about:open reçu');
            this.openPanel();
        });
        
        this._state.eventBus.on('about:close', () => {
            console.log('📄 AboutHandler: Événement about:close reçu');
            this.closePanel();
        });
        
        this._state.eventBus.on('theme:changed', (detail) => {
            const color = detail.color || this._getThemeColor(detail.theme);
            this._applyThemeToUI(color);
        });
        
        this._state.eventBus.on('panels:close-all', () => {
            if (this.isVisible()) {
                this.hidePanel();
            }
        });
    },
    
// =========================================
// MÉTHODES PUBLIQUES
// =========================================

openPanel() {
    this.cacheElements();
    
    if (!this._elements.aboutView || !this._elements.infoPanel) {
        console.error('📄 AboutHandler: Éléments manquants');
        return;
    }
    
    console.log('📄 AboutHandler: Ouverture du panneau');
    
    this._state.eventBus.emit('panels:close-others', { except: 'about' });
    
    // *** AJOUTER CETTE LIGNE ***
    // Demander à ui-core d'ouvrir le panneau (pour centraliser la logique)
    this._state.eventBus.emit('ui:open-panel', { panelId: 'about-view' });
    
    this._elements.infoPanel.style.display = 'block';
    this._elements.aboutView.style.display = 'block';
    
    this.loadContent();
    
    if (window.gsap) {
        window.gsap.from(this._elements.aboutView, {
            opacity: 0,
            y: 20,
            duration: 0.3
        });
    }
    
    this._state.eventBus.emit('about:opened', { timestamp: Date.now() });
},
    
    // =========================================
    // MÉTHODES DE GÉNÉRATION HTML
    // =========================================
    
    getLoaderHTML() {
        return `<div style="text-align: center; padding: 40px;">
            <i class="bi bi-arrow-repeat spin" style="font-size: 40px; color: var(--neon-accent);"></i>
            <p style="margin-top: 20px;">Chargement des informations...</p>
        </div>`;
    },
    
    getErrorHTML(error) {
        return `<div style="text-align: center; padding: 40px;">
            <i class="bi bi-exclamation-circle" style="font-size: 50px; color: #ff3b30;"></i>
            <p style="margin-top: 20px; font-size: 18px;">Erreur d'affichage</p>
            <p style="margin-top: 10px; opacity: 0.7; font-size: 12px;">${error.message}</p>
            <button onclick="window.modules?.about?.refresh?.()" class="preset-btn" style="margin-top: 20px; background: var(--neon-accent);">
                <i class="bi bi-arrow-repeat"></i> Réessayer
            </button>
        </div>`;
    },
    
    generateHTML(about) {
        return `
            <!-- ===== EN-TÊTE ===== -->
            <div class="about-card">
                <div style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, var(--neon-accent), #ff88aa); border-radius: 20px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-music-note-beamed" style="font-size: 40px; color: white;"></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 32px; font-family: 'Dancing Script', cursive;">${about.app.name}</h3>
                        <div style="display: flex; gap: 10px; margin-top: 8px; flex-wrap: wrap;">
                            <span class="version-badge">Version ${about.app.version}</span>
                            <span class="build-badge">Build ${about.app.build}</span>
                            <span class="library-tag">${about.app.license}</span>
                        </div>
                    </div>
                </div>
                <p style="margin-top: 20px; line-height: 1.6;">${about.description.long}</p>
            </div>

            <!-- ===== HISTOIRE DU PROJET ===== -->
            <h4 style="margin: 25px 0 15px; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-book" style="color: var(--neon-accent);"></i> Histoire du projet
            </h4>
            <div class="about-card">
                <p><strong>Origine :</strong> ${about.story.origin}</p>
                <p><strong>Création :</strong> ${about.story.creation}</p>
                <p><strong>Temps de développement :</strong> ${about.story.timeframe}</p>
                <p><strong>Assistance :</strong> ${about.story.assistance}</p>
                
                <h5 style="margin: 15px 0 10px; color: var(--neon-accent);">Défis rencontrés :</h5>
                <ul style="margin: 0; padding-left: 20px;">
                    ${about.story.challenges.map(challenge => `<li style="margin-bottom: 5px;">${challenge}</li>`).join('')}
                </ul>
            </div>

            <!-- ===== FONCTIONNALITÉS ===== -->
            <h4 style="margin: 25px 0 15px; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-stars" style="color: var(--neon-accent);"></i> Fonctionnalités
            </h4>
            <div class="feature-grid">
                ${about.features.map(f => `
                    <div class="feature-badge" title="${f.description}">
                        <i class="bi ${f.icon}"></i>
                        <span>${f.name}</span>
                        <small>${f.status}</small>
                        ${f.details ? `
                            <div style="font-size: 10px; margin-top: 8px; opacity: 0.8;">
                                ${Object.values(f.details).map(d => `• ${d}`).join('<br>')}
                            </div>
                        ` : ''}
                        ${f.stations ? `
                            <div style="font-size: 10px; margin-top: 8px;">
                                <span style="color: var(--neon-accent);">🎵 ${f.stations.music.join(' · ')}</span><br>
                                <span style="color: #4da6ff;">📰 ${f.stations.news.join(' · ')}</span>
                            </div>
                        ` : ''}
                        ${f.features ? `
                            <div style="font-size: 10px; margin-top: 8px; opacity: 0.8;">
                                ${f.features.map(feat => `✓ ${feat}`).join('<br>')}
                            </div>
                        ` : ''}
                        ${f.apis ? `
                            <div style="font-size: 10px; margin-top: 8px; opacity: 0.8;">
                                ${f.apis.map(api => `🔌 ${api}`).join('<br>')}
                            </div>
                        ` : ''}
                        ${f.themes ? `
                            <div style="font-size: 10px; margin-top: 8px; display: flex; flex-wrap: wrap; gap: 4px; justify-content: center;">
                                ${f.themes.map(theme => `<span style="background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 10px;">${theme}</span>`).join('')}
                            </div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>

            <!-- ===== CAPACITÉS ACTUELLES ===== -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
                <div class="about-card" style="padding: 15px;">
                    <h5 style="margin: 0 0 10px; color: #4caf50;">
                        <i class="bi bi-check-circle"></i> Ce qui fonctionne
                    </h5>
                    <ul style="margin: 0; padding-left: 20px; font-size: 12px;">
                        ${about.currentCapabilities.working.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
                <div class="about-card" style="padding: 15px;">
                    <h5 style="margin: 0 0 10px; color: #ff9800;">
                        <i class="bi bi-exclamation-triangle"></i> En cours / Limitations
                    </h5>
                    <ul style="margin: 0; padding-left: 20px; font-size: 12px;">
                        ${about.currentCapabilities.notWorking.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <!-- ===== VISION FUTURE ===== -->
            <h4 style="margin: 20px 0 15px; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-rocket-takeoff" style="color: var(--neon-accent);"></i> Vision future
            </h4>
            <div class="about-card">
                <h5 style="margin: 0 0 10px;">Court terme</h5>
                <ul style="margin: 0 0 15px; padding-left: 20px;">
                    ${about.futureVision.shortTerm.map(item => `<li>${item}</li>`).join('')}
                </ul>
                
                <h5 style="margin: 0 0 10px;">Long terme</h5>
                <ul style="margin: 0 0 15px; padding-left: 20px;">
                    ${about.futureVision.longTerm.map(item => `<li>${item}</li>`).join('')}
                </ul>
                
                <p><strong>Rêve ultime :</strong> ${about.futureVision.dream}</p>
            </div>

            <!-- ===== TECHNOLOGIES ===== -->
            <h4 style="margin: 20px 0 15px; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-cpu" style="color: var(--neon-accent);"></i> Technologies
            </h4>
            
            <h5 style="margin: 15px 0 10px;">CDN et bibliothèques</h5>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; margin-bottom: 15px;">
                ${about.technologies.cdn.map(cdn => `
                    <div class="library-tag" style="display: block; text-align: left; padding: 8px;">
                        <strong>${cdn.name}</strong><br>
                        <small style="opacity: 0.7;">${cdn.usage}</small>
                    </div>
                `).join('')}
            </div>
            
            <h5 style="margin: 15px 0 10px;">APIs externes</h5>
            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 15px;">
                ${about.technologies.apis.map(api => `
                    <span class="library-tag">${api.name}</span>
                `).join('')}
            </div>
            
            <h5 style="margin: 15px 0 10px;">Polices</h5>
            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 15px;">
                ${about.technologies.fonts.map(font => `
                    <span class="library-tag" style="font-family: '${font.name}', sans-serif;">${font.name}</span>
                `).join('')}
            </div>

            <!-- ===== PRÉREQUIS ET LIMITATIONS ===== -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
                <div class="about-card" style="padding: 15px;">
                    <h5 style="margin: 0 0 10px; color: var(--neon-accent);">Prérequis</h5>
                    <p><i class="bi bi-browser-chrome"></i> Navigateurs: ${about.requirements.browser.join(', ')}</p>
                    <p><i class="bi bi-database"></i> Stockage: ${about.requirements.storage}</p>
                    <p><i class="bi bi-wifi"></i> Internet: ${about.requirements.internet}</p>
                </div>
                <div class="about-card" style="padding: 15px;">
                    <h5 style="margin: 0 0 10px; color: var(--neon-accent);">Limitations</h5>
                    <p><i class="bi bi-phone"></i> Mobile: ${about.limitations.mobile}</p>
                    <p><i class="bi bi-camera-reels"></i> Vidéo: ${about.limitations.video}</p>
                    <p><i class="bi bi-folder"></i> Scan: ${about.limitations.scan}</p>
                    <p><i class="bi bi-soundwave"></i> Audio: ${about.limitations.audio}</p>
                </div>
            </div>

            <!-- ===== CRÉDITS ===== -->
            <h4 style="margin: 20px 0 15px; display: flex; align-items: center; gap: 8px;">
                <i class="bi bi-cup-hot" style="color: var(--neon-accent);"></i> Crédits
            </h4>
            <div class="about-card">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px;">
                    <div>
                        <h5 style="margin: 0 0 8px; color: var(--neon-accent);">Développement</h5>
                        <p style="margin: 0; font-size: 12px;">${about.credits.developer}</p>
                    </div>
                    <div>
                        <h5 style="margin: 0 0 8px; color: var(--neon-accent);">Design</h5>
                        <p style="margin: 0; font-size: 12px;">${about.credits.design}</p>
                    </div>
                    <div>
                        <h5 style="margin: 0 0 8px; color: var(--neon-accent);">Assistant</h5>
                        <p style="margin: 0; font-size: 12px;">${about.credits.assistant}</p>
                    </div>
                    <div>
                        <h5 style="margin: 0 0 8px; color: var(--neon-accent);">Inspiration</h5>
                        <p style="margin: 0; font-size: 12px;">${about.credits.inspiration}</p>
                    </div>
                </div>
                
                <h5 style="margin: 15px 0 10px; color: var(--neon-accent);">Bibliothèques</h5>
                <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 20px;">
                    ${about.credits.libraries.map(lib => `<span class="library-tag">${lib}</span>`).join('')}
                </div>
                
                <h5 style="margin: 15px 0 10px; color: var(--neon-accent);">Icônes</h5>
                <p style="margin: 0 0 15px; font-size: 12px;">${about.credits.icons}</p>
            </div>

            <!-- ===== REMERCIEMENTS ===== -->
            <div class="about-card" style="background: rgba(var(--neon-accent-rgb), 0.05); border-color: var(--neon-accent);">
                <p style="margin: 0; font-style: italic; text-align: center;">
                    <i class="bi bi-heart-fill" style="color: var(--neon-accent);"></i> 
                    ${about.thankYou}
                </p>
            </div>

            <!-- ===== LICENCE ===== -->
            <div style="margin-top: 20px; font-size: 11px; opacity: 0.5; text-align: center;">
                <i class="bi bi-file-text"></i> © ${new Date().getFullYear()} - Distribué sous licence ${about.app.license}
            </div>
        `;
    },

    // =========================================
    // MÉTHODES DE THÈME
    // =========================================
    
    _getThemeColor(theme) {
        const colors = {
            'default': '#ff0055',
            'deep-space': '#00aaff',
            'midnight': '#aa88ff',
            'aurora': '#6effb0',
            'sunset': '#ff884d',
            'forest': '#66cc66'
        };
        return colors[theme] || colors.default;
    },

    _applyThemeToUI(color) {
        if (this._elements.aboutBtn) {
            this._elements.aboutBtn.style.backgroundColor = color;
            this._elements.aboutBtn.style.border = 'none';
            this._elements.aboutBtn.style.color = '#ffffff';
            this._elements.aboutBtn.style.transition = 'background-color 0.3s ease';
        }
        
        if (this._elements.closeBtn) {
            this._elements.closeBtn.style.color = color;
        }
    },
    
    destroy() {
        console.log('📄 AboutHandler: Nettoyage...');
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.about = AboutHandler;
    console.log('📄 Module about enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement about:', e);
}