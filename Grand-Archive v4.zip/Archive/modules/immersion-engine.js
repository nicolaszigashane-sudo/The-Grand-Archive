/**
 * THE GRAND ARCHIVE - Immersion Engine Module
 * Version 4.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Mode immersion avancé avec vidéos importées, paroles synchronisées
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const ImmersionEngine = {
    // Identité du module
    name: 'immersion',
    dependencies: ['lyrics', 'ui', 'sound'], // ui pour les helpers, sound pour les sons éventuels

    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,

        isActive: false,
        isTransitioning: false,
        
        currentVideo: null,
        currentVideoSource: null,
        videoElement: null,
        idleTimer: null,
        cursorTimer: null,
        
        db: null,
        
        defaultVideos: [
            'ambient-1.mp4',
            'ambient-2.mp4',
            'ambient-3.mp4',
            'ambient-4.mp4',
            'ambient-5.mp4'
        ],
        
        availableDefaultVideos: [],
        importedVideos: [],
        allVideos: [],
        
        stats: {
            totalSessions: 0,
            totalTime: 0,
            sessionStart: null,
            videosPlayed: []
        },

        // Gestion des requêtes asynchrones (pour les éventuels callbacks)
        pendingRequests: new Map(),
        nextRequestId: 0,
    },

    // Configuration (interne)
    _CONFIG: {
        videoFolder: 'backgrounds/',
        transitionDuration: 800,
        idleTimeout: 3000,
        maxVideoSize: 100 * 1024 * 1024,      // 100 MB
        maxTotalSize: 500 * 1024 * 1024,      // 500 MB
        supportedFormats: ['.mp4', '.webm', '.mov', '.ogg']
    },

    // Éléments DOM (cachés)
    _elements: {
        container: null,
        video: null,
        lyrics: null,
        exitBtn: null,
        importBtn: null,
        fileInput: null,
        clearBtn: null,
        videosList: null,
        videosSpace: null,
        indicator: null,
    },

    // Référence au module UI (optionnel)
    _ui: null,

    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('🎬 ImmersionEngine: Initialisation...');
        this._state.config = config;
        this._state.eventBus = config.eventBus;

        this._ui = window.modules?.ui;

        try {
            await this._initDatabase();
            await this._loadImportedVideos();
            await this._scanDefaultVideos();
            this._updateVideoList();
            this._setupEventListeners();
            this._cacheElements();
            this._setupVideoUI();
            this._injectStyles();
            this._createVideoIndicator();

            this._state.initialized = true;
            console.log('✅ ImmersionEngine prêt');
            console.log(`📊 Statistiques: ${this._state.importedVideos.length} importées, ${this._state.availableDefaultVideos.length} par défaut`);

            return this;
        } catch (error) {
            console.error('❌ [Immersion] Échec initialisation:', error);
            return this;
        }
    },

    _cacheElements() {
        this._elements = {
            container: document.getElementById('immersion-container'),
            video: document.getElementById('immersion-video'),
            lyrics: document.getElementById('immersion-lyrics'),
            exitBtn: document.getElementById('immersion-exit'),
            importBtn: document.getElementById('import-video-btn'),
            fileInput: document.getElementById('video-import'),
            clearBtn: document.getElementById('clear-videos-btn'),
            videosList: document.getElementById('videos-list'),
            videosSpace: document.getElementById('videos-space'),
            indicator: document.getElementById('immersion-video-indicator'),
        };
    },

    _setupEventListeners() {
        // Écouter les événements de l'application
        this._state.eventBus.on('immersion:activate', () => this.activate());
        this._state.eventBus.on('immersion:deactivate', (detail) => this.deactivate(detail?.keepMusic));
        this._state.eventBus.on('immersion:toggle', () => this.toggle());

        // Mise à jour des paroles
        this._state.eventBus.on('lyrics:updated', (detail) => {
            if (this._state.isActive && this._elements.lyrics && detail.lyrics) {
                this._elements.lyrics.textContent = detail.lyrics;
            }
        });

        // Réponses des requêtes asynchrones (si on en utilise)
        this._state.eventBus.on('lyrics:current-result', (detail) => {
            const { callbackId, lyrics } = detail;
            const pending = this._state.pendingRequests.get(callbackId);
            if (pending) {
                this._state.pendingRequests.delete(callbackId);
                pending.resolve(lyrics);
            }
        });
    },

    // =========================================
    // BASE DE DONNÉES INDEXEDDB
    // =========================================
    _initDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('GrandArchiveVideos', 1);
            
            request.onerror = () => {
                console.error('❌ [Immersion] Erreur DB:', request.error);
                reject(request.error);
            };
            
            request.onsuccess = (event) => {
                this._state.db = event.target.result;
                console.log('💾 [Immersion] Base de données connectée');
                resolve();
            };
            
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('videos')) {
                    const store = db.createObjectStore('videos', { keyPath: 'id' });
                    store.createIndex('name', 'name', { unique: false });
                    store.createIndex('date', 'date', { unique: false });
                    store.createIndex('size', 'size', { unique: false });
                }
            };
        });
    },

    _loadImportedVideos() {
        return new Promise((resolve) => {
            if (!this._state.db) {
                resolve();
                return;
            }
            
            const transaction = this._state.db.transaction(['videos'], 'readonly');
            const store = transaction.objectStore('videos');
            const request = store.getAll();
            
            request.onsuccess = () => {
                this._state.importedVideos = request.result || [];
                resolve();
            };
            
            request.onerror = () => {
                console.warn('⚠️ [Immersion] Erreur chargement vidéos');
                this._state.importedVideos = [];
                resolve();
            };
        });
    },

    async importVideo(file) {
        // Validations
        if (!file.type.startsWith('video/')) {
            throw new Error('Format non supporté. Veuillez choisir une vidéo.');
        }
        
        if (file.size > this._CONFIG.maxVideoSize) {
            throw new Error(`Vidéo trop volumineuse (max ${this._CONFIG.maxVideoSize / 1024 / 1024} MB)`);
        }
        
        const totalSize = this._state.importedVideos.reduce((sum, v) => sum + v.size, 0);
        if (totalSize + file.size > this._CONFIG.maxTotalSize) {
            throw new Error('Espace de stockage insuffisant (max 500 MB)');
        }
        
        // Lecture et stockage
        const arrayBuffer = await this._readFileAsArrayBuffer(file);
        const uint8Array = new Uint8Array(arrayBuffer);
        
        const video = {
            id: `vid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: file.name,
            size: file.size,
            mimeType: file.type,
            data: Array.from(uint8Array),
            date: new Date().toISOString()
        };
        
        return new Promise((resolve, reject) => {
            const transaction = this._state.db.transaction(['videos'], 'readwrite');
            const store = transaction.objectStore('videos');
            const request = store.add(video);
            
            request.onsuccess = () => {
                this._state.importedVideos.push(video);
                this._updateVideoList();
                this._updateVideoUI();
                
                this._state.eventBus.emit('notification:show', {
                    message: '✅ Vidéo importée avec succès',
                    type: 'success'
                });
                
                resolve(video);
            };
            
            request.onerror = () => {
                reject(new Error('Erreur lors de la sauvegarde'));
            };
        });
    },

    _readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error('Erreur lecture fichier'));
            reader.readAsArrayBuffer(file);
        });
    },

    async deleteVideo(videoId) {
        return new Promise((resolve, reject) => {
            const transaction = this._state.db.transaction(['videos'], 'readwrite');
            const store = transaction.objectStore('videos');
            const request = store.delete(videoId);
            
            request.onsuccess = () => {
                this._state.importedVideos = this._state.importedVideos.filter(v => v.id !== videoId);
                this._updateVideoList();
                this._updateVideoUI();
                
                this._state.eventBus.emit('notification:show', {
                    message: '🗑️ Vidéo supprimée',
                    type: 'info'
                });
                
                resolve();
            };
            
            request.onerror = () => {
                reject(new Error('Erreur lors de la suppression'));
            };
        });
    },

    async clearAllVideos() {
        return new Promise((resolve, reject) => {
            const transaction = this._state.db.transaction(['videos'], 'readwrite');
            const store = transaction.objectStore('videos');
            const request = store.clear();
            
            request.onsuccess = () => {
                this._state.importedVideos = [];
                this._updateVideoList();
                this._updateVideoUI();
                
                this._state.eventBus.emit('notification:show', {
                    message: '🗑️ Toutes les vidéos supprimées',
                    type: 'info'
                });
                
                resolve();
            };
            
            request.onerror = () => {
                reject(new Error('Erreur lors du nettoyage'));
            };
        });
    },

    _scanDefaultVideos() {
        this._state.availableDefaultVideos = [];
        
        // On utilise des promesses pour chaque fetch, mais on ne bloque pas l'init
        return Promise.all(this._state.defaultVideos.map(async (video) => {
            try {
                const response = await fetch(this._CONFIG.videoFolder + video, { method: 'HEAD' });
                if (response.ok) {
                    this._state.availableDefaultVideos.push(video);
                }
            } catch (error) {}
        }));
    },

    _updateVideoList() {
        this._state.allVideos = [];
        
        // Ajouter les vidéos importées
        this._state.importedVideos.forEach(video => {
            this._state.allVideos.push({
                type: 'imported',
                id: video.id,
                name: video.name,
                data: video.data,
                size: video.size,
                mimeType: video.mimeType || 'video/mp4'
            });
        });
        
        // Ajouter les vidéos par défaut
        this._state.availableDefaultVideos.forEach(video => {
            this._state.allVideos.push({
                type: 'default',
                name: video,
                path: this._CONFIG.videoFolder + video
            });
        });
    },

    _getRandomVideo() {
        if (this._state.allVideos.length === 0) return null;
        const randomIndex = Math.floor(Math.random() * this._state.allVideos.length);
        return this._state.allVideos[randomIndex];
    },

    _getVideoUrl(video) {
        if (!video) return null;
        
        if (video.type === 'imported') {
            const imported = this._state.importedVideos.find(v => v.id === video.id);
            if (!imported) return null;
            
            const byteArray = new Uint8Array(imported.data);
            const blob = new Blob([byteArray], { type: imported.mimeType || 'video/mp4' });
            return URL.createObjectURL(blob);
        }
        
        return video.path;
    },

    // =========================================
    // MODE IMMERSION
    // =========================================
    async activate() {
        if (this._state.isActive || this._state.isTransitioning) return;
        
        this._state.isTransitioning = true;
        
        try {
            const container = this._elements.container;
            if (!container) throw new Error('Conteneur immersion introuvable');
            
            // Préparer le conteneur
            container.style.display = 'flex';
            container.style.opacity = '0';
            
            // Animation d'entrée
            if (window.gsap) {
                await window.gsap.to(container, {
                    opacity: 1,
                    duration: this._CONFIG.transitionDuration / 1000,
                    ease: 'power2.inOut'
                });
            } else {
                container.style.opacity = '1';
            }
            
            document.body.classList.add('immersion-mode');
            
            // Démarrer la vidéo
            await this._startVideo();
            
            // Charger les paroles
            await this._loadLyrics();
            
            // Configurer les comportements
            this._setupBehaviors();
            
            this._state.isActive = true;
            this._state.stats.totalSessions++;
            this._state.stats.sessionStart = Date.now();
            
            this._state.eventBus.emit('immersion:activated', {});
            
        } catch (error) {
            console.error('❌ [Immersion] Erreur activation:', error);
        } finally {
            this._state.isTransitioning = false;
        }
    },

    async deactivate(keepMusic = true) {
        if (!this._state.isActive || this._state.isTransitioning) return;
        
        this._state.isTransitioning = true;
        
        try {
            const container = this._elements.container;
            if (!container) return;
            
            if (window.gsap) {
                await window.gsap.to(container, {
                    opacity: 0,
                    duration: this._CONFIG.transitionDuration / 1000,
                    ease: 'power2.inOut'
                });
            }
            
            document.body.classList.remove('immersion-mode');
            container.style.display = 'none';
            container.style.opacity = '';
            
            this._stopVideo();
            
            clearTimeout(this._state.idleTimer);
            clearTimeout(this._state.cursorTimer);
            
            this._state.isActive = false;
            
            if (this._state.stats.sessionStart) {
                this._state.stats.totalTime += Date.now() - this._state.stats.sessionStart;
            }
            
            this._state.eventBus.emit('immersion:deactivated', { keepMusic });
            
        } catch (error) {
            console.error('❌ [Immersion] Erreur désactivation:', error);
        } finally {
            this._state.isTransitioning = false;
        }
    },

    toggle() {
        return this._state.isActive ? this.deactivate(true) : this.activate();
    },

    async _startVideo() {
        const video = this._elements.video;
        if (!video) return;
        
        this._state.videoElement = video;
        
        const selectedVideo = this._getRandomVideo();
        
        if (!selectedVideo) {
            console.warn('⚠️ [Immersion] Aucune vidéo disponible');
            return;
        }
        
        const videoUrl = this._getVideoUrl(selectedVideo);
        if (!videoUrl) return;
        
        // Configuration background pur
        video.src = videoUrl;
        video.loop = true;
        video.muted = true;
        video.playsInline = true;
        video.volume = 0;
        video.controls = false;
        video.disablePictureInPicture = true;
        video.disableRemotePlayback = true;
        
        // Supprimer les contrôles
        video.removeAttribute('controls');
        video.style.pointerEvents = 'none';
        
        // Nettoyage URL précédente
        if (this._state.currentVideo?.type === 'imported') {
            URL.revokeObjectURL(video.src);
        }
        
        this._state.currentVideo = selectedVideo;
        
        // Événements silencieux
        video.onloadedmetadata = () => {
            this._updateVideoIndicator();
        };
        
        video.onerror = () => {
            if (this._state.allVideos.length > 1) {
                setTimeout(() => this._startVideo(), 1000);
            }
        };
        
        try {
            await video.play();
            this._state.stats.videosPlayed.push({
                video: selectedVideo.name || selectedVideo.path,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            // Ignorer les erreurs de lecture auto
        }
    },

    _stopVideo() {
        if (this._state.videoElement) {
            this._state.videoElement.pause();
            
            if (this._state.currentVideo?.type === 'imported') {
                URL.revokeObjectURL(this._state.videoElement.src);
            }
            
            this._state.videoElement.src = '';
            this._state.videoElement.load();
            this._state.videoElement = null;
        }
    },

    async _loadLyrics() {
        const lyricsEl = this._elements.lyrics;
        if (!lyricsEl) return;
        
        // Demander les paroles actuelles au module lyrics via événement
        const lyrics = await this._requestCurrentLyrics();
        
        if (lyrics) {
            if (lyrics.type === 'synced' && lyrics.lines?.length > 0) {
                lyricsEl.textContent = lyrics.lines[0]?.text || '♪';
            } else if (lyrics.text) {
                lyricsEl.textContent = lyrics.text.split('\n')[0] || '♪';
            } else {
                lyricsEl.textContent = '♪';
            }
        } else {
            lyricsEl.textContent = '♪ Mode Immersion ♪';
        }
        
        if (window.gsap) {
            window.gsap.from(lyricsEl, {
                opacity: 0,
                y: 50,
                duration: 1,
                ease: 'power3.out'
            });
        }
    },

    _requestCurrentLyrics() {
        return new Promise((resolve) => {
            const callbackId = `immersion_lyrics_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            
            this._state.eventBus.emit('lyrics:get-current', { callbackId });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },

    _setupBehaviors() {
        const container = this._elements.container;
        const exitBtn = this._elements.exitBtn;
        const bottomBlock = document.querySelector('.ice-block-bottom');
        
        if (!container) return;
        
        // Gestion de l'inactivité
        const resetIdleTimer = () => {
            clearTimeout(this._state.idleTimer);
            
            if (bottomBlock) {
                bottomBlock.style.opacity = '1';
                bottomBlock.style.pointerEvents = 'auto';
            }
            if (exitBtn) {
                exitBtn.style.opacity = '1';
                exitBtn.style.pointerEvents = 'auto';
            }
            
            this._state.idleTimer = setTimeout(() => {
                if (this._state.isActive) {
                    if (bottomBlock) {
                        bottomBlock.style.opacity = '0';
                        bottomBlock.style.pointerEvents = 'none';
                    }
                    if (exitBtn) {
                        exitBtn.style.opacity = '0.5';
                        exitBtn.style.pointerEvents = 'auto';
                    }
                }
            }, this._CONFIG.idleTimeout);
        };
        
        // Gestion du curseur
        const hideCursor = () => {
            container.style.cursor = 'none';
        };
        
        const showCursor = () => {
            container.style.cursor = 'default';
            clearTimeout(this._state.cursorTimer);
            this._state.cursorTimer = setTimeout(hideCursor, 2000);
        };
        
        // Événements
        container.addEventListener('mousemove', showCursor);
        container.addEventListener('mousemove', resetIdleTimer);
        container.addEventListener('touchstart', resetIdleTimer);
        
        hideCursor();
        resetIdleTimer();
        
        // Bouton de sortie
        if (exitBtn) {
            exitBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.deactivate(true);
            });
        }
        
        // Double-clic pour changer de vidéo
        container.addEventListener('dblclick', () => {
            if (this._state.isActive) {
                this._startVideo();
            }
        });
        
        // Raccourcis clavier
        document.addEventListener('keydown', this._handleKeyDown.bind(this));
    },

    _handleKeyDown(e) {
        if (!this._state.isActive) return;
        
        switch (e.key) {
            case 'Escape':
                e.preventDefault();
                this.deactivate(true);
                break;
                
            case 'ArrowRight':
            case 'ArrowLeft':
                e.preventDefault();
                this._startVideo();
                break;
                
            case ' ':
                e.preventDefault();
                // Ignorer, la vidéo est en boucle
                break;
        }
    },

    _setupVideoUI() {
        const importBtn = this._elements.importBtn;
        const fileInput = this._elements.fileInput;
        
        if (importBtn && fileInput) {
            importBtn.addEventListener('click', () => {
                fileInput.click();
            });
            
            fileInput.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                const originalText = importBtn.innerHTML;
                
                try {
                    importBtn.innerHTML = '<i class="bi bi-arrow-repeat spin"></i> Import...';
                    await this.importVideo(file);
                } catch (error) {
                    this._state.eventBus.emit('notification:show', {
                        message: '❌ ' + error.message,
                        type: 'error'
                    });
                } finally {
                    importBtn.innerHTML = originalText;
                    fileInput.value = '';
                }
            });
        }
        
        const clearBtn = this._elements.clearBtn;
        if (clearBtn) {
            clearBtn.addEventListener('click', async () => {
                if (confirm('Supprimer toutes les vidéos importées ?')) {
                    await this.clearAllVideos();
                }
            });
        }
        
        this._updateVideoUI();
    },

    _updateVideoUI() {
        const videosList = this._elements.videosList;
        const videosSpace = this._elements.videosSpace;
        
        if (videosList) {
            if (this._state.importedVideos.length === 0) {
                videosList.innerHTML = `
                    <div class="empty-state">
                        <i class="bi bi-camera-video"></i>
                        <span>Aucune vidéo importée</span>
                    </div>
                `;
            } else {
                videosList.innerHTML = this._state.importedVideos.map(video => `
                    <div class="video-item">
                        <i class="bi bi-film"></i>
                        <div class="video-info">
                            <div class="video-name">${video.name}</div>
                            <div class="video-size">${(video.size / 1024 / 1024).toFixed(1)} MB</div>
                        </div>
                        <button class="delete-video-btn" data-id="${video.id}">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                `).join('');
                
                document.querySelectorAll('.delete-video-btn').forEach(btn => {
                    btn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        await this.deleteVideo(btn.dataset.id);
                    });
                });
            }
        }
        
        if (videosSpace) {
            const totalSize = this._state.importedVideos.reduce((sum, v) => sum + v.size, 0);
            videosSpace.textContent = `${(totalSize / 1024 / 1024).toFixed(1)} MB / ${this._CONFIG.maxTotalSize / 1024 / 1024} MB`;
        }
    },

    _updateVideoIndicator() {
        const indicator = this._elements.indicator;
        if (!indicator) return;
        
        if (this._state.currentVideo) {
            let name = '';
            
            if (this._state.currentVideo.type === 'imported') {
                name = this._state.currentVideo.name
                    .replace(/\.[^/.]+$/, '')
                    .replace(/[-_]/g, ' ')
                    .replace(/\b\w/g, l => l.toUpperCase());
            } else {
                name = (this._state.currentVideo.name || this._state.currentVideo.path)
                    .replace('.mp4', '').replace('.webm', '').replace('.mov', '')
                    .replace(/[-_]/g, ' ')
                    .replace(/\b\w/g, l => l.toUpperCase());
            }
            
            indicator.innerHTML = `🎬 ${name.substring(0, 30)}${name.length > 30 ? '…' : ''}`;
        } else {
            indicator.innerHTML = '🎬 Aucune vidéo';
        }
    },

    _createVideoIndicator() {
        const container = this._elements.container;
        if (!container) return;
        
        if (document.getElementById('immersion-video-indicator')) return;
        
        const indicator = document.createElement('div');
        indicator.id = 'immersion-video-indicator';
        indicator.className = 'immersion-video-indicator';
        indicator.innerHTML = '🎬 Aucune vidéo';
        container.appendChild(indicator);
        this._elements.indicator = indicator;
        
        // Observer les changements de source vidéo
        const video = this._elements.video;
        if (video) {
            const observer = new MutationObserver(() => {
                setTimeout(() => this._updateVideoIndicator(), 100);
            });
            observer.observe(video, { attributes: true, attributeFilter: ['src'] });
        }
        
        this._updateVideoIndicator();
    },

    // =========================================
    // STYLES
    // =========================================
    _injectStyles() {
        if (document.getElementById('immersion-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'immersion-styles';
        style.textContent = `
            /* Animations */
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            @keyframes floatText {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-20px); }
            }
            
            /* Mode immersion */
            .immersion-mode {
                transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            }
            
            /* Conteneur vidéo */
            #immersion-video {
                pointer-events: none;
            }
            
            #immersion-video::-webkit-media-controls {
                display: none !important;
            }
            
            #immersion-video::-webkit-media-controls-enclosure {
                display: none !important;
            }
            
            /* Conteneur principal */
            .immersion-container {
                cursor: none;
            }
            
            .immersion-container.moving {
                cursor: default;
            }
            
            /* Bloc player en mode immersion */
            .immersion-mode .ice-block-bottom {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                transition: opacity 0.3s ease;
                background: linear-gradient(to top, rgba(0,0,0,0.5), transparent);
                padding-top: 50px;
                z-index: 2100;
            }
            
            .immersion-mode .ice-block-bottom:hover {
                opacity: 1 !important;
            }
            
            /* Bouton de sortie */
            #immersion-exit {
                transition: all 0.3s ease;
                background: rgba(255,255,255,0.15);
                border: 1px solid rgba(255,255,255,0.2);
                z-index: 2200;
            }
            
            #immersion-exit:hover {
                background: var(--neon-accent);
                transform: scale(1.1) rotate(90deg);
                box-shadow: 0 0 30px var(--neon-accent);
            }
            
            /* Paroles */
            #immersion-lyrics {
                font-family: 'Dancing Script', cursive;
                color: white;
                text-shadow: 
                    0 0 30px var(--neon-accent),
                    0 0 60px rgba(255,0,85,0.5);
                text-align: center;
                max-width: 90%;
                word-wrap: break-word;
                z-index: 10;
                animation: floatText 3s ease-in-out infinite;
            }
            
            /* Indicateur vidéo */
            .immersion-video-indicator {
                position: absolute;
                bottom: 70px;
                right: 20px;
                background: rgba(0,0,0,0.5);
                color: white;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 12px;
                backdrop-filter: blur(4px);
                border: 1px solid rgba(255,255,255,0.15);
                z-index: 25;
                opacity: 0.7;
                transition: opacity 0.3s ease;
            }
            
            .immersion-video-indicator:hover {
                opacity: 1;
            }
            
            /* Interface d'import */
            .spin {
                animation: spin 1s infinite linear;
                display: inline-block;
            }
            
            .empty-state {
                text-align: center;
                padding: 30px 20px;
                opacity: 0.5;
                border: 2px dashed rgba(255,255,255,0.2);
                border-radius: 12px;
            }
            
            .empty-state i {
                font-size: 32px;
                display: block;
                margin-bottom: 10px;
            }
            
            .video-item {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 8px 12px;
                background: rgba(255,255,255,0.05);
                border-radius: 8px;
                margin-bottom: 6px;
                transition: all 0.2s ease;
            }
            
            .video-item:hover {
                background: rgba(255,255,255,0.1);
            }
            
            .video-item i {
                color: var(--neon-accent);
                font-size: 18px;
            }
            
            .video-info {
                flex: 1;
                overflow: hidden;
            }
            
            .video-name {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: 13px;
            }
            
            .video-size {
                font-size: 10px;
                opacity: 0.5;
                margin-top: 2px;
            }
            
            .delete-video-btn {
                background: none;
                border: none;
                color: #ff3b30;
                cursor: pointer;
                padding: 6px;
                border-radius: 50%;
                transition: all 0.2s ease;
            }
            
            .delete-video-btn:hover {
                background: rgba(255,59,48,0.2);
                transform: scale(1.1);
            }
        `;
        
        document.head.appendChild(style);
    },

    // =========================================
    // API PUBLIQUE (pour compatibilité / événements)
    // =========================================
    get isActive() { return this._state.isActive; },
    get isInitialized() { return this._state.initialized; },
    get stats() { return { ...this._state.stats, importedCount: this._state.importedVideos.length }; },

    nextVideo() {
        if (this._state.isActive) {
            this._startVideo();
        }
    },

    getStats() {
        return {
            ...this._state.stats,
            importedCount: this._state.importedVideos.length,
            defaultCount: this._state.availableDefaultVideos.length,
            totalVideos: this._state.allVideos.length,
            sessionTime: this._state.isActive && this._state.stats.sessionStart ?
                Date.now() - this._state.stats.sessionStart : 0,
            storageUsed: this._state.importedVideos.reduce((sum, v) => sum + v.size, 0),
            storageMax: this._CONFIG.maxTotalSize
        };
    },

    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🎬 ImmersionEngine: Nettoyage...');
        if (this._state.isActive) {
            this.deactivate(true);
        }
        clearTimeout(this._state.idleTimer);
        clearTimeout(this._state.cursorTimer);
        document.removeEventListener('keydown', this._handleKeyDown);
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.immersion = ImmersionEngine;
    console.log('📦 Module immersion enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement immersion:', e);
}