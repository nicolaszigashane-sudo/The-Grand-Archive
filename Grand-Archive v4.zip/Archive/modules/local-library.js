/**
 * THE GRAND ARCHIVE - Local Library Module
 * Version 3.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion de la bibliothèque musicale locale
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const LocalLibrary = {
    // Identité du module
    name: 'local',
    dependencies: ['sound', 'offline', 'ui'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        tracks: [],
        folders: [],
        lastScan: null,
        
        pendingRequests: new Map(),
        nextRequestId: 0,
        
        // Détection de l'environnement
        isTauri: typeof window !== 'undefined' && window.__TAURI__ !== undefined
    },
    
    // Éléments DOM (cachés)
    _elements: {
        tracksEl: null,
        hoursEl: null,
        favoritesEl: null,
        recentEl: null,
    },
    
    // Référence au module UI
    _ui: null,
    
    // API Tauri (chargée dynamiquement)
    _tauri: null,
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('📁 LocalLibrary: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        this._ui = window.modules?.ui;
        
        // Charger l'API Tauri si disponible
        if (this._state.isTauri) {
            this._loadTauriAPI();
        }
        
        // Charger la bibliothèque sauvegardée
        this._loadFromStorage();
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Mettre à jour l'UI initiale
        this.updateLibraryUI();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ LocalLibrary prêt', this._state.isTauri ? '(Mode Tauri)' : '(Mode Web)');
        
        return this;
    },
    
    _loadTauriAPI() {
        // Importer dynamiquement les modules Tauri
        import('@tauri-apps/api/fs').then(module => {
            this._tauri = this._tauri || {};
            this._tauri.fs = module;
        });
        
        import('@tauri-apps/api/dialog').then(module => {
            this._tauri = this._tauri || {};
            this._tauri.dialog = module;
        });
        
        import('@tauri-apps/api/path').then(module => {
            this._tauri = this._tauri || {};
            this._tauri.path = module;
        });
    },
    
    cacheElements() {
        this._elements = {
            tracksEl: document.getElementById('library-tracks'),
            hoursEl: document.getElementById('library-hours'),
            favoritesEl: document.getElementById('library-favorites'),
            recentEl: document.getElementById('recently-listened'),
        };
    },
    
    subscribeToEvents() {
        // Répondre aux demandes de scan
        this._state.eventBus.on('local:scan-request', () => {
            this.scanLocalFiles();
        });
        
        // Répondre aux demandes de recherche
        this._state.eventBus.on('local:search', (detail) => {
            const { query, limit, callbackId } = detail;
            const results = this.searchLocalTracks(query, limit);
            this._state.eventBus.emit('local:search-result', {
                tracks: results,
                callbackId
            });
        });
        
        // Répondre aux demandes de statistiques
        this._state.eventBus.on('local:get-stats', () => {
            const stats = this.getLibraryStats();
            this._state.eventBus.emit('local:stats', stats);
        });
        
        // Jouer un morceau local
        this._state.eventBus.on('local:play', (detail) => {
            const { trackId } = detail;
            this.playLocalTrack(trackId);
        });
        
        // Mise à jour de l'UI après scan
        this._state.eventBus.on('local:ui-update-request', () => {
            this.updateLibraryUI();
        });
    },
    
    // =========================================
    // CHARGEMENT / SAUVEGARDE
    // =========================================
    _loadFromStorage() {
        try {
            const saved = localStorage.getItem('local-library');
            if (saved) {
                const data = JSON.parse(saved);
                this._state.tracks = data.tracks || [];
                this._state.folders = data.folders || [];
                this._state.lastScan = data.lastScan || null;
            }
        } catch (e) {
            console.warn('⚠️ Erreur chargement bibliothèque locale:', e);
        }
    },
    
    _saveToStorage() {
        try {
            const data = {
                tracks: this._state.tracks,
                folders: this._state.folders,
                lastScan: this._state.lastScan
            };
            localStorage.setItem('local-library', JSON.stringify(data));
        } catch (e) {
            console.warn('⚠️ Erreur sauvegarde bibliothèque locale:', e);
        }
    },
    
    // =========================================
    // SCAN DE FICHIERS (version Tauri native)
    // =========================================
    async scanLocalFiles() {
        try {
            if (this._state.isTauri && this._tauri) {
                await this._scanWithTauri();
            } else {
                await this._scanWithWebAPI();
            }
        } catch (error) {
            console.error('❌ Erreur scan:', error);
            this._state.eventBus.emit('notification:show', { message: '❌ Erreur lors du scan' });
        }
    },
    
    // Version Tauri (fichiers réels)
    async _scanWithTauri() {
        this._state.eventBus.emit('notification:show', { message: '📂 Sélectionnez un dossier...' });
        
        // Ouvrir le sélecteur de dossier Tauri
        const { open } = this._tauri.dialog;
        const { readDir, readBinaryFile } = this._tauri.fs;
        const { basename, extname } = this._tauri.path;
        
        const selected = await open({
            directory: true,
            multiple: false,
            title: "Sélectionnez votre dossier de musique"
        });
        
        if (!selected) return;
        
        this._state.eventBus.emit('notification:show', { message: '📂 Scan en cours...' });
        
        // Scanner récursivement
        const audioExtensions = ['.mp3', '.flac', '.m4a', '.aac', '.ogg', '.wav', '.opus'];
        const audioFiles = [];
        
        const scanDir = async (dirPath) => {
            const entries = await readDir(dirPath);
            
            for (const entry of entries) {
                if (entry.children) {
                    // C'est un dossier
                    await scanDir(entry.path);
                } else {
                    // C'est un fichier
                    const ext = await extname(entry.name);
                    if (audioExtensions.includes(ext.toLowerCase())) {
                        audioFiles.push({
                            path: entry.path,
                            name: entry.name
                        });
                    }
                }
            }
        };
        
        await scanDir(selected);
        
        if (audioFiles.length === 0) {
            this._state.eventBus.emit('notification:show', { message: '❌ Aucun fichier audio trouvé' });
            return;
        }
        
        this._state.eventBus.emit('notification:show', { 
            message: `📊 ${audioFiles.length} fichiers trouvés, extraction des métadonnées...` 
        });
        
        // Traiter les fichiers par lots
        const tracks = [];
        const batchSize = 5;
        
        for (let i = 0; i < audioFiles.length; i += batchSize) {
            const batch = audioFiles.slice(i, i + batchSize);
            
            await Promise.all(batch.map(async (file) => {
                try {
                    // Lire le fichier en binaire
                    const data = await readBinaryFile(file.path);
                    
                    // Créer un objet File pour jsmediatags
                    const fileObj = new File([new Uint8Array(data)], file.name);
                    
                    // Extraire les métadonnées
                    const metadata = await this._extractMetadata(fileObj);
                    
                    tracks.push({
                        id: `local_${Date.now()}_${Math.random().toString(36)}`,
                        path: file.path, // Chemin absolu pour Tauri
                        name: file.name,
                        ...metadata
                    });
                } catch (e) {
                    console.warn(`⚠️ Erreur sur ${file.name}:`, e);
                }
            }));
            
            // Mettre à jour la progression
            const progress = Math.round((i + batch.length) / audioFiles.length * 100);
            this._state.eventBus.emit('notification:show', { 
                message: `⏳ Scan: ${progress}%` 
            });
        }
        
        // Sauvegarder
        this._state.tracks = tracks;
        this._state.lastScan = new Date().toISOString();
        this._saveToStorage();
        
        // Émettre l'événement pour la galerie
        this._state.eventBus.emit('local:tracks-imported', { tracks });
        
        // Mettre à jour l'interface
        this.updateLibraryUI();
        this._state.eventBus.emit('notification:show', { 
            message: `✅ ${tracks.length} titres importés !` 
        });
    },
    
    // Version Web (fallback)
    async _scanWithWebAPI() {
        const input = document.createElement('input');
        input.type = 'file';
        input.webkitdirectory = true;
        input.multiple = true;
        input.accept = 'audio/*';
        
        input.onchange = async (e) => {
            const files = Array.from(e.target.files);
            const audioFiles = files.filter(f => 
                f.type.startsWith('audio/') || 
                f.name.match(/\.(mp3|wav|ogg|m4a|flac|aac)$/i)
            );
            
            if (audioFiles.length === 0) {
                this._state.eventBus.emit('notification:show', { message: '❌ Aucun fichier audio trouvé' });
                return;
            }
            
            this._state.eventBus.emit('notification:show', { message: `📊 ${audioFiles.length} fichiers trouvés...` });
            
            const tracks = [];
            let processed = 0;
            
            for (const file of audioFiles) {
                try {
                    const metadata = await this._extractMetadata(file);
                    
                    // Créer une URL pour le fichier (valable uniquement pour la session)
                    const fileUrl = URL.createObjectURL(file);
                    
                    tracks.push({
                        id: 'local_' + Date.now() + '_' + processed,
                        name: file.name,
                        path: fileUrl, // URL temporaire pour la lecture
                        originalName: file.name,
                        ...metadata,
                        fileSize: file.size,
                        lastModified: file.lastModified
                    });
                } catch (e) {
                    console.warn('⚠️ Erreur métadonnées:', file.name, e);
                }
                
                processed++;
                if (processed % 10 === 0) {
                    console.log(`📊 Progression: ${processed}/${audioFiles.length}`);
                }
            }
            
            this._state.tracks = tracks;
            this._state.lastScan = new Date().toISOString();
            this._saveToStorage();
            
            // Émettre l'événement pour la galerie
            this._state.eventBus.emit('local:tracks-imported', { tracks });
            
            this.updateLibraryUI();
            this._state.eventBus.emit('notification:show', { message: `✅ ${tracks.length} titres importés !` });
        };
        
        input.click();
    },
    
    // =========================================
    // EXTRACTION DES MÉTADONNÉES (inchangé)
    // =========================================
    _extractMetadata(file) {
        return new Promise((resolve, reject) => {
            const metadata = {
                title: file.name.replace(/\.[^/.]+$/, ""),
                artist: 'Inconnu',
                album: 'Inconnu',
                year: null,
                genre: null,
                cover: null,
                duration: 0
            };
            
            if (window.jsmediatags) {
                window.jsmediatags.read(file, {
                    onSuccess: (tag) => {
                        try {
                            if (tag.tags.title) metadata.title = tag.tags.title;
                            if (tag.tags.artist) metadata.artist = tag.tags.artist;
                            if (tag.tags.album) metadata.album = tag.tags.album;
                            if (tag.tags.year) metadata.year = tag.tags.year;
                            if (tag.tags.genre) metadata.genre = tag.tags.genre;
                            
                            if (tag.tags.picture) {
                                const { data, format } = tag.tags.picture;
                                const base64 = data.reduce((acc, byte) => 
                                    acc + String.fromCharCode(byte), '');
                                metadata.cover = `data:${format};base64,${btoa(base64)}`;
                            }
                        } catch (e) {}
                        
                        this._getAudioDuration(file).then(duration => {
                            metadata.duration = duration;
                            resolve(metadata);
                        }).catch(() => resolve(metadata));
                    },
                    onError: () => {
                        this._getAudioDuration(file).then(duration => {
                            metadata.duration = duration;
                            resolve(metadata);
                        }).catch(() => resolve(metadata));
                    }
                });
            } else {
                this._getAudioDuration(file).then(duration => {
                    metadata.duration = duration;
                    resolve(metadata);
                }).catch(() => resolve(metadata));
            }
        });
    },
    
    _getAudioDuration(file) {
        return new Promise((resolve, reject) => {
            const url = URL.createObjectURL(file);
            const audio = new Audio(url);
            
            audio.addEventListener('loadedmetadata', () => {
                resolve(audio.duration);
                URL.revokeObjectURL(url);
            });
            
            audio.addEventListener('error', reject);
            audio.load();
            
            setTimeout(() => {
                URL.revokeObjectURL(url);
                reject(new Error('Timeout'));
            }, 5000);
        });
    },
    
    // =========================================
    // MISE À JOUR DE L'INTERFACE
    // =========================================
    updateLibraryUI() {
        const { tracksEl, hoursEl, favoritesEl, recentEl } = this._elements;
        
        if (tracksEl) {
            tracksEl.textContent = this._state.tracks.length;
        }
        
        if (hoursEl) {
            const totalSeconds = this._state.tracks.reduce((acc, t) => acc + (t.duration || 0), 0);
            const hours = Math.floor(totalSeconds / 3600);
            hoursEl.textContent = hours;
        }
        
        if (favoritesEl) {
            try {
                const favorites = JSON.parse(localStorage.getItem('favorites') || '[]').length;
                favoritesEl.textContent = favorites;
            } catch {
                favoritesEl.textContent = '0';
            }
        }
        
        if (recentEl && this._state.tracks.length > 0) {
            const recent = this._state.tracks.slice(0, 10);
            recentEl.innerHTML = recent.map(track => `
                <div class="album-card local-track" onclick="window.modules?.local?.playLocalTrack('${track.id}')">
                    <img src="${track.cover || 'backgrounds/default-cover.jpg'}" 
                         onerror="this.src='backgrounds/default-cover.jpg'">
                    <h4>${track.title}</h4>
                    <p>${track.artist}</p>
                </div>
            `).join('');
        }
    },
    
    // =========================================
    // JOUER UN TITRE LOCAL (version native)
    // =========================================
    playLocalTrack(trackId) {
        const track = this._state.tracks.find(t => t.id === trackId);
        if (!track) {
            this._state.eventBus.emit('notification:show', { message: '❌ Titre non trouvé', type: 'error' });
            return;
        }
        
        console.log('📁 Lecture du morceau local:', track.title);
        
        // Créer un objet track compatible avec le player
        const playerTrack = {
            id: track.id,
            title: track.title,
            name: track.title,
            artist: track.artist,
            cover: track.cover,
            duration: track.duration
        };
        
        // Ajouter la source audio selon l'environnement
        if (this._state.isTauri) {
            // En mode Tauri, on utilise le chemin absolu avec le protocole asset
            playerTrack.url = `asset://${track.path}`;
            console.log('🔊 Source Tauri:', playerTrack.url);
        } else {
            // En mode Web, on utilise l'URL temporaire (créée lors du scan)
            playerTrack.url = track.path;
        }
        
        // Émettre l'événement pour le player
        this._state.eventBus.emit('player:play-track', { track: playerTrack });
    },
    
    // =========================================
    // RECHERCHE DANS LA BIBLIOTHÈQUE LOCALE
    // =========================================
    searchLocalTracks(query, limit = 50) {
        if (!query || query.length < 2) return [];
        
        const q = query.toLowerCase();
        
        return this._state.tracks.filter(track => {
            const title = (track.title || '').toLowerCase();
            const artist = (track.artist || '').toLowerCase();
            const album = (track.album || '').toLowerCase();
            return title.includes(q) || artist.includes(q) || album.includes(q);
        }).slice(0, limit);
    },
    
    // =========================================
    // STATISTIQUES
    // =========================================
    getLibraryStats() {
        const totalTracks = this._state.tracks.length;
        const totalSeconds = this._state.tracks.reduce((acc, t) => acc + (t.duration || 0), 0);
        const totalHours = Math.floor(totalSeconds / 3600);
        const totalMinutes = Math.floor((totalSeconds % 3600) / 60);
        
        return {
            tracks: totalTracks,
            hours: totalHours,
            minutes: totalMinutes,
            totalDuration: totalSeconds,
            lastScan: this._state.lastScan
        };
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('📁 LocalLibrary: Nettoyage...');
        
        // Nettoyer les URLs temporaires en mode Web
        if (!this._state.isTauri) {
            this._state.tracks.forEach(track => {
                if (track.path && track.path.startsWith('blob:')) {
                    URL.revokeObjectURL(track.path);
                }
            });
        }
        
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.local = LocalLibrary;
    console.log('📦 Module local enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement local:', e);
}