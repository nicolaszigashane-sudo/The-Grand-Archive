/**
 * THE GRAND ARCHIVE - Radio Stream Module
 * Version 3.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion des flux radio en streaming
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const RadioStream = {
    // Identité du module
    name: 'radio',
    dependencies: ['sound'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        stationsRequested: false,
        
        // Stations vérifiées - TOUTES FONCTIONNENT
        stations: [
            // ===== FRANCE - Radio France (les plus stables) =====
            {
                id: 'fip',
                name: 'FIP',
                genre: 'Éclectique',
                icon: 'radio',
                color: '#E2007A',
                url: 'https://icecast.radiofrance.fr/fip-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fip-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-jazz',
                name: 'FIP Jazz',
                genre: 'Jazz',
                icon: 'music-note-beamed',
                color: '#0055A4',
                url: 'https://icecast.radiofrance.fr/fipjazz-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipjazz-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-rock',
                name: 'FIP Rock',
                genre: 'Rock',
                icon: 'guitar',
                color: '#D32F2F',
                url: 'https://icecast.radiofrance.fr/fiprock-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fiprock-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-electro',
                name: 'FIP Electro',
                genre: 'Electro',
                icon: 'radio',
                color: '#9C27B0',
                url: 'https://icecast.radiofrance.fr/fipelectro-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipelectro-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-world',
                name: 'FIP World',
                genre: 'Musiques du monde',
                icon: 'globe',
                color: '#FF9800',
                url: 'https://icecast.radiofrance.fr/fipworld-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipworld-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-reggae',
                name: 'FIP Reggae',
                genre: 'Reggae',
                icon: 'music-note',
                color: '#4CAF50',
                url: 'https://icecast.radiofrance.fr/fipreggae-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipreggae-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-metal',
                name: 'FIP Metal',
                genre: 'Metal',
                icon: 'guitar',
                color: '#607D8B',
                url: 'https://icecast.radiofrance.fr/fipmetal-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipmetal-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'fip-nouveautes',
                name: 'FIP Nouveautés',
                genre: 'Nouveautés',
                icon: 'star',
                color: '#FFC107',
                url: 'https://icecast.radiofrance.fr/fipnouveautes-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/fipnouveautes-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'franceinfo',
                name: 'France Info',
                genre: 'Information',
                icon: 'newspaper',
                color: '#43A047',
                url: 'https://icecast.radiofrance.fr/franceinfo-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/franceinfo-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'mouv',
                name: 'Le Mouv\'',
                genre: 'Jeunes',
                icon: 'music-note',
                color: '#FF5722',
                url: 'https://icecast.radiofrance.fr/mouv-midfi.mp3',
                backupUrl: 'https://icecast.radiofrance.fr/mouv-hifi.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            
            // ===== FRANCE - Radios indépendantes =====
            {
                id: 'nova',
                name: 'Nova',
                genre: 'Rock/Electro',
                icon: 'star',
                color: '#FF6B6B',
                url: 'https://novazz.ice.infomaniak.ch/novazz-128.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            {
                id: 'tsf',
                name: 'TSF Jazz',
                genre: 'Jazz',
                icon: 'music-note-beamed',
                color: '#FFD700',
                url: 'https://tsfjazz.ice.infomaniak.ch/tsfjazz-high.mp3',
                country: 'FR',
                language: 'fr',
                working: true
            },
            
            // ===== SUISSE =====
            {
                id: 'rts',
                name: 'RTS La 1ère',
                genre: 'Généraliste',
                icon: 'mic',
                color: '#009FE3',
                url: 'https://lsaplus.swisstxt.ch/audio/la-1ere_96.aac/playlist.m3u8',
                country: 'CH',
                language: 'fr',
                working: true,
                isHLS: true
            },
            
            // ===== BELGIQUE =====
            {
                id: 'rtbf',
                name: 'RTBF La Première',
                genre: 'Généraliste',
                icon: 'mic',
                color: '#F15A29',
                url: 'https://radios.rtbf.be/laprem1ere-64.aac',
                country: 'BE',
                language: 'fr',
                working: true
            },
            {
                id: 'classic21',
                name: 'Classic 21',
                genre: 'Rock/Classiques',
                icon: 'guitar',
                color: '#E64C3C',
                url: 'https://radios.rtbf.be/classic21-64.aac',
                country: 'BE',
                language: 'fr',
                working: true
            },
            
            // ===== INTERNATIONAL =====
            {
                id: 'bbc',
                name: 'BBC World Service',
                genre: 'News',
                icon: 'broadcast',
                color: '#BB1919',
                url: 'http://stream.live.vc.bbcmedia.co.uk/bbc_world_service',
                country: 'UK',
                language: 'en',
                working: true
            },
            {
                id: 'npr',
                name: 'NPR',
                genre: 'News',
                icon: 'wifi',
                color: '#0078D7',
                url: 'https://npr-ice.streamguys1.com/live.mp3',
                country: 'US',
                language: 'en',
                working: true
            },
            {
                id: 'kexp',
                name: 'KEXP',
                genre: 'Indie/Rock',
                icon: 'music-note',
                color: '#00A651',
                url: 'https://kexp-mp3-128.streamguys1.com/kexp128.mp3',
                country: 'US',
                language: 'en',
                working: true
            }
        ],
        
        // État de lecture
        currentStation: null,
        isPlaying: false,
        howl: null,
        reconnectTimer: null,
        dataSaverMode: true,
        
        // Stats data
        bytesReceived: 0,
        startTime: null,
        dataInterval: null,
        
        // Compteur de tentatives
        retryCount: 0,
        maxRetries: 2,
        
        // Playlist (pour next/prev)
        playlist: [],
        currentIndex: -1
    },
    
    // Éléments DOM (cachés)
    _elements: {
        radioContainer: null,
        stationElements: []
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('📻 RadioStream: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Initialiser la playlist
        this._state.playlist = [...this._state.stations];
        
        // Émettre les stations pour les autres modules
        this._state.eventBus.emit('radio:stations', { stations: this._state.stations });
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Rendre les stations dans l'UI
        this.renderRadioStations();
        
        // Restaurer la dernière station
        this.restoreLastStation();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ RadioStream prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements.radioContainer = document.getElementById('radio-stations');
    },
    
    subscribeToEvents() {
        // Événements de contrôle venant de l'orchestrateur
        this._state.eventBus.on('radio:play', (detail) => {
            if (detail.stationId) {
                this.playById(detail.stationId);
            } else {
                this.play();
            }
        });
        
        this._state.eventBus.on('radio:pause', () => this.pause());
        this._state.eventBus.on('radio:stop', () => this.stop());
        this._state.eventBus.on('radio:toggle', () => this.togglePlay());
        this._state.eventBus.on('radio:next', () => this.next());
        this._state.eventBus.on('radio:previous', () => this.prev());
        
        // Volume
        this._state.eventBus.on('volume:changed', (detail) => {
            this.applyVolume(detail.volume);
        });
        
        // Demande d'état
        this._state.eventBus.on('radio:get-state', () => {
            this._state.eventBus.emit('radio:state', this.getState());
        });
        
        // Réagir au chargement du contenu radio
        this._state.eventBus.on('content:load-radio', () => {
            this.renderRadioStations();
        });
        
        // Répondre aux demandes de stations
        this._state.eventBus.on('radio:get-stations', () => {
            this._state.eventBus.emit('radio:stations', { stations: this._state.stations });
        });
    },
    
    // =========================================
    // RENDU DES STATIONS (avec vérification du conteneur)
    // =========================================
    renderRadioStations() {
        // S'assurer que le conteneur existe
        const container = document.getElementById('radio-stations');
        if (!container) {
            console.log('📻 RadioStream: Conteneur non trouvé, nouvelle tentative dans 200ms');
            setTimeout(() => this.renderRadioStations(), 200);
            return;
        }
        
        this._elements.radioContainer = container;
        this._performRender();
    },
    
    _performRender() {
        const container = this._elements.radioContainer;
        if (!container) return;
        
        // Vider le conteneur
        container.innerHTML = '';
        
        // Trier les stations par pays
        const stations = [...this._state.stations].sort((a, b) => {
            if (a.country === 'FR' && b.country !== 'FR') return -1;
            if (a.country !== 'FR' && b.country === 'FR') return 1;
            return a.name.localeCompare(b.name);
        });
        
        // Grouper par pays
        const byCountry = stations.reduce((acc, station) => {
            acc[station.country] = acc[station.country] || [];
            acc[station.country].push(station);
            return acc;
        }, {});
        
        // Ordre des pays
        const countryOrder = { FR: 1, CH: 2, BE: 3, UK: 4, US: 5 };
        const sortedCountries = Object.keys(byCountry).sort((a, b) => 
            (countryOrder[a] || 99) - (countryOrder[b] || 99)
        );
        
        sortedCountries.forEach(countryCode => {
            const countryStations = byCountry[countryCode];
            
            // Nom du pays
            const countryNames = { 
                FR: 'France', 
                CH: 'Suisse', 
                BE: 'Belgique', 
                UK: 'Royaume-Uni', 
                US: 'États-Unis' 
            };
            
            const countryDiv = document.createElement('div');
            countryDiv.className = 'country-group';
            countryDiv.innerHTML = `<h3 style="margin:20px 0 10px; color:var(--neon-accent);">${countryNames[countryCode] || countryCode}</h3>`;
            container.appendChild(countryDiv);
            
            // Grille de stations
            const grid = document.createElement('div');
            grid.style.display = 'grid';
            grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(200px, 1fr))';
            grid.style.gap = '15px';
            
            countryStations.forEach(station => {
                const card = this.createStationCard(station);
                grid.appendChild(card);
            });
            
            container.appendChild(grid);
        });
    },
    
    createStationCard(station) {
        const card = document.createElement('div');
        card.className = 'radio-station';
        card.dataset.id = station.id;
        card.style.cssText = `
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        `;
        
        card.innerHTML = `
            <i class="bi bi-${station.icon}" style="font-size: 40px; color: ${station.color};"></i>
            <h4 style="margin: 10px 0 5px;">${station.name}</h4>
            <p style="margin: 0; font-size: 12px; opacity: 0.7;">${station.genre}</p>
            <p style="margin: 5px 0 0; font-size: 10px; opacity: 0.5;">${station.language === 'fr' ? '🇫🇷' : '🇬🇧'}</p>
        `;
        
        card.addEventListener('click', () => {
            this._state.eventBus.emit('sound:play', { sound: 'click' });
            this._state.eventBus.emit('radio:play', { stationId: station.id });
        });
        
        return card;
    },
    
    updateStationUI(station) {
        document.querySelectorAll('.radio-station').forEach(el => {
            if (el.dataset.id === station.id) {
                el.style.border = `2px solid ${station.color}`;
                el.style.transform = 'scale(1.02)';
                el.style.boxShadow = `0 0 15px ${station.color}`;
            } else {
                el.style.border = 'none';
                el.style.transform = 'scale(1)';
                el.style.boxShadow = 'none';
            }
        });
    },
    
    // =========================================
    // GESTION DE LA LECTURE
    // =========================================
    play() {
        if (!this._state.howl) return;
        this._state.howl.play();
        this._state.isPlaying = true;
        this._state.startTime = Date.now();
        this.emitState();
        this._state.eventBus.emit('notification:show', { message: '▶️ Radio reprise' });
    },
    
    pause() {
        if (!this._state.howl || !this._state.isPlaying) return;
        this._state.howl.pause();
        this._state.isPlaying = false;
        this.emitState();
        this._state.eventBus.emit('notification:show', { message: '⏸️ Radio en pause' });
    },
    
    togglePlay() {
        this._state.isPlaying ? this.pause() : this.play();
    },
    
    stop() {
        if (this._state.reconnectTimer) {
            clearTimeout(this._state.reconnectTimer);
            this._state.reconnectTimer = null;
        }
        
        if (this._state.dataInterval) {
            clearInterval(this._state.dataInterval);
            this._state.dataInterval = null;
        }
        
        if (this._state.howl) {
            this._state.howl.stop();
            this._state.howl.unload();
            this._state.howl = null;
        }
        
        const wasPlaying = this._state.isPlaying;
        this._state.isPlaying = false;
        this._state.currentStation = null;
        this._state.retryCount = 0;
        
        this.emitState();
        
        if (wasPlaying) {
            this._state.eventBus.emit('notification:show', { message: '⏹️ Radio arrêtée' });
        }
    },
    
    async playById(stationId) {
        const station = this._state.stations.find(s => s.id === stationId);
        if (!station) return;
        
        this._state.currentIndex = this._state.playlist.findIndex(s => s.id === stationId);
        await this.playStation(station);
    },
    
    async playStation(station) {
        if (!station) return;
        
        try {
            this.stop();
            this._state.retryCount = 0;
            
            console.log(`📻 Lecture: ${station.name}`);
            
            this._state.currentStation = station;
            this._state.isPlaying = true;
            this._state.startTime = Date.now();
            this._state.bytesReceived = 0;
            
            this.updateStationUI(station);
            
            if (typeof Howl === 'undefined') {
                console.error('Howler.js non chargé');
                this._state.eventBus.emit('notification:show', { message: '❌ Howler.js manquant' });
                return;
            }
            
            // Récupérer le volume depuis le localStorage ou utiliser 0.8
            const savedVolume = localStorage.getItem('volume');
            const volumeValue = savedVolume ? parseInt(savedVolume) / 100 : 0.8;
            
            const howl = new Howl({
                src: [station.url],
                html5: true,
                format: ['mp3', 'aac', 'm3u8'],
                volume: volumeValue,
                onplay: () => {
                    console.log('▶️ Stream démarré');
                    this._state.eventBus.emit('notification:show', { message: `📻 ${station.name}` });
                    this._state.retryCount = 0;
                    this.emitState();
                    this.startDataTracking(howl);
                },
                onend: () => {
                    if (this._state.currentStation === station && this._state.isPlaying) {
                        console.log('🔄 Reconnexion...');
                        this._state.reconnectTimer = setTimeout(() => {
                            this.playStation(station);
                        }, 2000);
                    }
                },
                onloaderror: (id, error) => {
                    console.error('❌ Erreur chargement:', error);
                    
                    this._state.retryCount++;
                    if (this._state.retryCount <= this._state.maxRetries && station.backupUrl) {
                        const tempStation = {...station, url: station.backupUrl};
                        setTimeout(() => this.playStation(tempStation), 1000);
                        return;
                    }
                    
                    this._state.eventBus.emit('notification:show', { message: `❌ ${station.name} indisponible` });
                    this.stop();
                }
            });
            
            howl.play();
            this._state.howl = howl;
            
            localStorage.setItem('last-radio', JSON.stringify({
                id: station.id,
                timestamp: Date.now()
            }));
            
        } catch (error) {
            console.error('❌ Erreur:', error);
            this._state.eventBus.emit('notification:show', { message: '❌ Erreur de lecture' });
            this.stop();
        }
    },
    
    next() {
        if (!this._state.playlist?.length) return;
        
        let nextIndex = this._state.currentIndex + 1;
        if (nextIndex >= this._state.playlist.length) nextIndex = 0;
        
        const nextStation = this._state.playlist[nextIndex];
        if (nextStation) {
            this.playStation(nextStation);
            this._state.currentIndex = nextIndex;
        }
    },
    
    prev() {
        if (!this._state.playlist?.length) return;
        
        let prevIndex = this._state.currentIndex - 1;
        if (prevIndex < 0) prevIndex = this._state.playlist.length - 1;
        
        const prevStation = this._state.playlist[prevIndex];
        if (prevStation) {
            this.playStation(prevStation);
            this._state.currentIndex = prevIndex;
        }
    },
    
    // =========================================
    // VOLUME
    // =========================================
    applyVolume(volumePercent) {
        const volumeValue = volumePercent / 100;
        if (this._state.howl) {
            this._state.howl.volume(volumeValue);
        }
    },
    
    // =========================================
    // SUIVI DATA
    // =========================================
    startDataTracking(howl) {
        if (!howl) return;
        
        this._state.dataInterval = setInterval(() => {
            if (!this._state.isPlaying || !this._state.currentStation) {
                clearInterval(this._state.dataInterval);
                return;
            }
            
            const duration = (Date.now() - this._state.startTime) / 1000;
            let bitrate = 64;
            
            if (this._state.currentStation.url.includes('128')) bitrate = 128;
            else if (this._state.currentStation.url.includes('96')) bitrate = 96;
            
            this._state.bytesReceived = (bitrate * 1024 / 8) * duration;
        }, 1000);
    },
    
    // =========================================
    // RESTAURATION
    // =========================================
    restoreLastStation() {
        try {
            const last = localStorage.getItem('last-radio');
            if (last) {
                const data = JSON.parse(last);
                const station = this._state.stations.find(s => s.id === data.id);
                if (station) {
                    this._state.currentStation = station;
                    this._state.currentIndex = this._state.playlist.findIndex(s => s.id === station.id);
                    this.updateStationUI(station);
                }
            }
        } catch (e) {}
    },
    
    // =========================================
    // ÉTAT
    // =========================================
    emitState() {
        this._state.eventBus.emit('radio:state', this.getState());
    },
    
    getState() {
        return {
            currentStation: this._state.currentStation,
            isPlaying: this._state.isPlaying,
            currentIndex: this._state.currentIndex,
            bytesReceived: this._state.bytesReceived
        };
    },
    
    // =========================================
    // MÉTHODE POUR LE BOUTON RÉESSAYER
    // =========================================
    retryLoad() {
        console.log('📻 RadioStream: Nouvelle tentative de chargement');
        
        // Réinitialiser l'état
        this._state.stationsRequested = false;
        
        // Ré-émettre les stations
        this._state.eventBus.emit('radio:stations', { stations: this._state.stations });
        
        // Si la vue radio est visible, on recharge
        if (document.getElementById('radio-view')?.style.display === 'block') {
            setTimeout(() => {
                this.renderRadioStations();
            }, 100);
        }
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('📻 RadioStream: Nettoyage...');
        
        if (this._state.reconnectTimer) clearTimeout(this._state.reconnectTimer);
        if (this._state.dataInterval) clearInterval(this._state.dataInterval);
        if (this._state.howl) this._state.howl.unload();
        
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.radio = RadioStream;

console.log('📻 RadioStream: Module enregistré');