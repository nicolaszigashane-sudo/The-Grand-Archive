/**
 * THE GRAND ARCHIVE - Last.fm API Module
 * Version 3.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Biographies artistes, tags, morceaux similaires, informations détaillées
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const LastFMAPI = {
    // Identité du module
    name: 'lastfm',
    dependencies: ['offline', 'ui'], // offline pour le cache, ui pour notifications éventuelles

    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,

        // 🔑 Clé API (peut être fournie par config)
        apiKey: '', // celle du code, mais on peut la surcharger

        // Endpoints
        baseURL: 'https://ws.audioscrobbler.com/2.0/',
        format: 'json',

        // Cache TTL
        cacheTTL: {
            artistInfo: 7 * 24 * 60 * 60 * 1000,
            similar: 7 * 24 * 60 * 60 * 1000,
            topTracks: 24 * 60 * 60 * 1000,
            topAlbums: 24 * 60 * 60 * 1000,
            tags: 30 * 24 * 60 * 60 * 1000
        },

        // État
        isReady: false,
        lastRequest: 0,

        // Statistiques
        stats: {
            totalRequests: 0,
            cachedResponses: 0,
            apiCalls: 0,
            errors: 0
        },

        // Gestion des requêtes asynchrones
        pendingRequests: new Map(),
        nextRequestId: 0,
    },

    // Éléments DOM (aucun spécifique)
    _elements: {},

    // Référence au module UI (optionnel)
    _ui: null,

    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('📻 LastFMAPI: Initialisation...');
        this._state.config = config;
        this._state.eventBus = config.eventBus;

        if (config.apiKey) {
            this._state.apiKey = config.apiKey;
        }

        this._ui = window.modules?.ui;

        // Sauvegarder la clé dans localStorage pour référence (optionnel)
        try {
            localStorage.setItem('lastfm-api-key', this._state.apiKey);
        } catch (e) {}

        // Vérifier que la clé API est configurée
        if (!this._state.apiKey || this._state.apiKey === '') {
            console.error('❌ Clé API Last.fm manquante');
            this._showApiKeyPrompt();
            // On considère que le module peut être prêt quand même ? Non, on ne peut pas fonctionner sans clé.
            // On va tout de même marquer comme ready false, mais on peut essayer plus tard.
            return false;
        }

        try {
            // Tester la connexion avec un appel réel
            const testResult = await this._testConnection();

            if (testResult) {
                this._state.isReady = true;
                console.log('✅ LastFMAPI prêt (clé valide)');

                // S'abonner aux événements
                this._subscribeToEvents();

                return this;
            } else {
                console.error('❌ Clé API Last.fm invalide');
                return false;
            }
        } catch (error) {
            console.error('❌ Erreur initialisation Last.fm:', error);
            return false;
        }
    },

    _subscribeToEvents() {
        // Demande d'infos artiste
        this._state.eventBus.on('lastfm:get-artist-info', async (detail) => {
            const { artistName, options, callbackId } = detail;
            const result = await this.getArtistInfo(artistName, options);
            this._state.eventBus.emit('lastfm:artist-info-result', { ...result, callbackId });
        });

        // Demande de top morceaux
        this._state.eventBus.on('lastfm:get-artist-toptracks', async (detail) => {
            const { artistName, limit, page, callbackId } = detail;
            const result = await this.getArtistTopTracks(artistName, limit, page);
            this._state.eventBus.emit('lastfm:artist-toptracks-result', { ...result, callbackId });
        });

        // Demande de top albums
        this._state.eventBus.on('lastfm:get-artist-topalbums', async (detail) => {
            const { artistName, limit, page, callbackId } = detail;
            const result = await this.getArtistTopAlbums(artistName, limit, page);
            this._state.eventBus.emit('lastfm:artist-topalbums-result', { ...result, callbackId });
        });

        // Demande de morceaux similaires
        this._state.eventBus.on('lastfm:get-similar-tracks', async (detail) => {
            const { trackName, artistName, limit, callbackId } = detail;
            const result = await this.getSimilarTracks(trackName, artistName, limit);
            this._state.eventBus.emit('lastfm:similar-tracks-result', { tracks: result, callbackId });
        });

        // Demande de recherche par tag
        this._state.eventBus.on('lastfm:get-tracks-by-tag', async (detail) => {
            const { tagName, limit, page, callbackId } = detail;
            const result = await this.getTracksByTag(tagName, limit, page);
            this._state.eventBus.emit('lastfm:tracks-by-tag-result', { ...result, callbackId });
        });

        // Réponses du cache offline
        this._state.eventBus.on('offline:api-retrieved', (detail) => this._handleOfflineResponse(detail));
        this._state.eventBus.on('offline:api-cached', (detail) => {});
    },

    // =========================================
    // TEST DE CONNEXION RÉEL
    // =========================================
    async _testConnection() {
        try {
            const data = await this._makeRequest({
                method: 'artist.getInfo',
                artist: 'Daft Punk',
                autocorrect: 1
            }, false);
            return data && data.artist ? true : false;
        } catch (error) {
            return false;
        }
    },

    // =========================================
    // GESTION DU CACHE VIA ÉVÉNEMENTS
    // =========================================
    _getCached(url) {
        return new Promise((resolve) => {
            const callbackId = `lastfm_cache_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve, reject: resolve }); // on resolve même avec null
            this._state.eventBus.emit('offline:get-api', {
                endpoint: url,
                ignoreTTL: true,
                callbackId
            });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },

    _cacheResponse(url, data, ttl) {
        this._state.eventBus.emit('offline:cache-api', {
            endpoint: url,
            data: data,
            ttl: ttl
        });
    },

    _handleOfflineResponse(detail) {
        const { callbackId, data } = detail;
        const pending = this._state.pendingRequests.get(callbackId);
        if (pending) {
            this._state.pendingRequests.delete(callbackId);
            pending.resolve(data);
        }
    },

    // =========================================
    // REQUÊTE API AVEC GESTION D'ERREURS
    // =========================================
    async _makeRequest(params, useCache = true) {
        const {
            method,
            artist,
            track,
            album,
            mbid,
            limit = 50,
            page = 1,
            autocorrect = 1,
            ...customParams
        } = params;

        // Construire l'URL
        const urlParams = new URLSearchParams({
            method,
            artist: artist || '',
            track: track || '',
            album: album || '',
            mbid: mbid || '',
            limit,
            page,
            autocorrect,
            api_key: this._state.apiKey,
            format: this._state.format
        });

        Object.entries(customParams).forEach(([key, value]) => {
            if (value !== undefined && value !== null) {
                urlParams.append(key, value);
            }
        });

        const url = `${this._state.baseURL}?${urlParams.toString()}`;

        // Vérifier le cache
        const skipCache = method.includes('getTop') || method.includes('getSimilar');

        if (useCache && !skipCache) {
            const cached = await this._getCached(url);
            if (cached) {
                this._state.stats.cachedResponses++;
                return cached;
            }
        }

        // Rate limiting
        const now = Date.now();
        const timeSinceLastRequest = now - this._state.lastRequest;

        if (timeSinceLastRequest < 200) {
            await new Promise(resolve => setTimeout(resolve, 200 - timeSinceLastRequest));
        }

        // Tentative avec plusieurs essais
        let lastError = null;

        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                this._state.stats.totalRequests++;
                this._state.lastRequest = Date.now();

                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 8000);

                const response = await fetch(url, {
                    signal: controller.signal,
                    mode: 'cors',
                    headers: {
                        'Accept': 'application/json',
                        'User-Agent': 'The Grand Archive/1.0.0'
                    }
                });

                clearTimeout(timeoutId);

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();

                // Vérifier les erreurs Last.fm
                if (data.error) {
                    this._state.stats.errors++;

                    if (data.error === 8) {
                        throw new Error('Clé API invalide');
                    } else if (data.error === 11) {
                        if (attempt < 3) {
                            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                            continue;
                        }
                    }

                    throw new Error(`Last.fm: ${data.message}`);
                }

                // Succès - mettre en cache
                this._state.stats.apiCalls++;

                if (useCache && !skipCache && data) {
                    let ttl = this._state.cacheTTL.artistInfo;
                    if (method.includes('similar')) ttl = this._state.cacheTTL.similar;
                    if (method.includes('getTop')) ttl = this._state.cacheTTL.topTracks;
                    if (method.includes('tag')) ttl = this._state.cacheTTL.tags;

                    this._cacheResponse(url, data, ttl);
                }

                return data;

            } catch (error) {
                lastError = error;
                this._state.stats.errors++;

                if (attempt < 3) {
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                }
            }
        }

        // Fallback cache (dernier recours)
        const cached = await this._getCached(url);
        if (cached) return cached;

        throw lastError || new Error('Échec de la requête');
    },

    // =========================================
    // PROMPT POUR CLÉ API (optionnel, via notification)
    // =========================================
    _showApiKeyPrompt() {
        this._state.eventBus.emit('notification:show', {
            message: 'Clé API Last.fm manquante - Configurez-la dans les paramètres',
            type: 'warning'
        });
    },

    // =========================================
    // MÉTHODES PUBLIQUES (appelables par l'orchestrateur ou via événements)
    // =========================================

    async getArtistInfo(artistName, options = {}) {
        const { autocorrect = 1, lang = 'fr' } = options;

        if (!artistName) return null;

        try {
            const data = await this._makeRequest({
                method: 'artist.getInfo',
                artist: artistName,
                autocorrect,
                lang
            });

            if (!data.artist) return null;

            const artist = data.artist;

            return {
                name: artist.name,
                mbid: artist.mbid,
                url: artist.url,
                listeners: parseInt(artist.stats?.listeners) || 0,
                playcount: parseInt(artist.stats?.playcount) || 0,
                summary: this._cleanHtml(artist.bio?.summary) || '',
                content: this._cleanHtml(artist.bio?.content) || '',
                published: artist.bio?.published,
                tags: (artist.tags?.tag || []).map(tag => ({
                    name: tag.name,
                    url: tag.url
                })),
                similar: (artist.similar?.artist || []).map(a => ({
                    name: a.name,
                    url: a.url,
                    image: a.image?.find(img => img.size === 'extralarge')?.['#text'] || null
                }))
            };
        } catch (error) {
            console.error('❌ Erreur artiste:', error);
            return null;
        }
    },

    async getArtistTopTracks(artistName, limit = 20, page = 1) {
        if (!artistName) return { tracks: [], total: 0 };

        try {
            const data = await this._makeRequest({
                method: 'artist.getTopTracks',
                artist: artistName,
                limit,
                page
            }, false); // pas de cache car top tracks change

            if (!data.toptracks?.track) {
                return { tracks: [], total: 0 };
            }

            const tracks = data.toptracks.track.map(track => ({
                name: track.name,
                url: track.url,
                duration: parseInt(track.duration) || 0,
                listeners: parseInt(track.listeners) || 0,
                playcount: parseInt(track.playcount) || 0,
                rank: parseInt(track['@attr']?.rank) || 0,
                image: track.image?.find(img => img.size === 'extralarge')?.['#text'] || null,
                artist: track.artist?.name
            }));

            return {
                tracks,
                total: parseInt(data.toptracks['@attr']?.total) || tracks.length
            };
        } catch (error) {
            console.error('❌ Erreur top morceaux:', error);
            return { tracks: [], total: 0 };
        }
    },

    async getArtistTopAlbums(artistName, limit = 20, page = 1) {
        if (!artistName) return { albums: [], total: 0 };

        try {
            const data = await this._makeRequest({
                method: 'artist.getTopAlbums',
                artist: artistName,
                limit,
                page
            }, false);

            if (!data.topalbums?.album) {
                return { albums: [], total: 0 };
            }

            const albums = data.topalbums.album.map(album => ({
                name: album.name,
                url: album.url,
                playcount: parseInt(album.playcount) || 0,
                rank: parseInt(album['@attr']?.rank) || 0,
                image: album.image?.find(img => img.size === 'extralarge')?.['#text'] || null,
                artist: album.artist?.name,
                mbid: album.mbid
            }));

            return {
                albums,
                total: parseInt(data.topalbums['@attr']?.total) || albums.length
            };
        } catch (error) {
            console.error('❌ Erreur top albums:', error);
            return { albums: [], total: 0 };
        }
    },

    async getSimilarTracks(trackName, artistName, limit = 20) {
        if (!trackName || !artistName) return [];

        try {
            const data = await this._makeRequest({
                method: 'track.getSimilar',
                track: trackName,
                artist: artistName,
                limit
            }, false);

            if (!data.similartracks?.track) return [];

            return data.similartracks.track.map(track => ({
                name: track.name,
                artist: track.artist?.name,
                url: track.url,
                image: track.image?.find(img => img.size === 'extralarge')?.['#text'] || null,
                match: parseFloat(track.match) || 0
            }));
        } catch (error) {
            console.error('❌ Erreur similaires:', error);
            return [];
        }
    },

    async getTracksByTag(tagName, limit = 20, page = 1) {
        if (!tagName) return { tracks: [], total: 0 };

        try {
            const data = await this._makeRequest({
                method: 'tag.getTopTracks',
                tag: tagName,
                limit,
                page
            }, false);

            if (!data.tracks?.track) {
                return { tracks: [], total: 0 };
            }

            const tracks = data.tracks.track.map(track => ({
                name: track.name,
                artist: track.artist?.name,
                url: track.url,
                duration: parseInt(track.duration) || 0,
                listeners: parseInt(track.listeners) || 0,
                image: track.image?.find(img => img.size === 'extralarge')?.['#text'] || null
            }));

            return {
                tracks,
                total: parseInt(data.tracks['@attr']?.total) || tracks.length
            };
        } catch (error) {
            console.error('❌ Erreur recherche tag:', error);
            return { tracks: [], total: 0 };
        }
    },

    // =========================================
    // UTILITAIRES
    // =========================================
    _cleanHtml(text) {
        if (!text) return '';
        return text.replace(/<[^>]*>/g, '').trim();
    },

    // Méthode pour changer la clé API (si besoin)
    setApiKey(key) {
        this._state.apiKey = key;
        localStorage.setItem('lastfm-api-key', key);
        // On pourrait réinitialiser le module
    },

    isReady() {
        return this._state.isReady;
    },

    getStats() {
        return { ...this._state.stats };
    },

    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('📻 LastFMAPI: Nettoyage...');
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.lastfm = LastFMAPI;
    console.log('📻 LastFMAPI: Module enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement lastfm:', e);
}