/**
 * THE GRAND ARCHIVE - Metadata Bot Module
 * Version 2.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Extraction et gestion des métadonnées audio
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const MetadataBot = {
    // Identité du module
    name: 'metadata',
    dependencies: ['offline', 'ui'], // offline pour le cache, ui pour helpers éventuels

    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,

        // Base de données locale
        db: {
            tracks: new Map(),
            albums: new Map(),
            artists: new Map(),
            playlists: new Map()
        },

        // Index de recherche
        searchIndex: {
            tracks: [],
            albums: [],
            artists: []
        },

        // État
        isIndexing: false,
        lastSync: null,
        totalTracks: 0,
        scanningProgress: 0,

        // Statistiques
        stats: {
            scannedFiles: 0,
            indexedTracks: 0,
            failedTracks: 0,
            lastScan: null,
            totalSize: 0,
            totalDuration: 0
        },

        // Configuration
        config: {
            musicFolders: [],
            autoScan: true,
            scanInterval: 3600000,
            supportedFormats: ['.mp3', '.flac', '.m4a', '.aac', '.ogg', '.wav', '.opus'],
            extractEmbeddedCover: true,
            useID3v2: true
        },

        // Disponibilité des bibliothèques ID3
        hasJsMediaTags: false,
        hasID3js: false,

        // Gestion des requêtes asynchrones
        pendingRequests: new Map(),
        nextRequestId: 0,
    },

    // Éléments DOM (cachés)
    _elements: {
        libraryTracks: null,
        libraryHours: null,
        libraryFavorites: null,
        createPlaylistBtn: null,
    },

    // Référence au module UI
    _ui: null,

    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('🤖 MetadataBot: Initialisation...');
        this._state.config = config;
        this._state.eventBus = config.eventBus;

        this._ui = window.modules?.ui;

        // Cacher les éléments DOM
        this._cacheElements();

        // Vérifier les bibliothèques ID3
        this._checkID3Libraries();

        // Charger les données sauvegardées
        await this._loadSavedData();

        // Restaurer les playlists
        await this._loadPlaylists();

        // Charger les dossiers configurés
        this._loadMusicFolders();

        // S'abonner aux événements
        this._subscribeToEvents();

        // Mettre à jour l'UI
        this._updateLibraryStats();

        // Démarrer le scan automatique si configuré
        if (this._state.config.autoScan) {
            this._scheduleAutoScan();
        }

        // Attacher les écouteurs DOM pour les boutons existants
        this._attachDomEventListeners();

        this._state.initialized = true;
        console.log('✅ MetadataBot prêt');
        return this;
    },

    _cacheElements() {
        this._elements = {
            libraryTracks: document.getElementById('library-tracks'),
            libraryHours: document.getElementById('library-hours'),
            libraryFavorites: document.getElementById('library-favorites'),
            createPlaylistBtn: document.getElementById('create-playlist-btn'),
        };
    },

    _attachDomEventListeners() {
        if (this._elements.createPlaylistBtn) {
            this._elements.createPlaylistBtn.addEventListener('click', () => {
                const name = prompt('Nom de la playlist:');
                if (name) {
                    this.createPlaylist(name);
                    // Rafraîchir l'affichage (on peut émettre un événement)
                    this._state.eventBus.emit('metadata:playlists-changed', {});
                }
            });
        }
    },

    _subscribeToEvents() {
        // Recherche de pistes
        this._state.eventBus.on('metadata:search', (detail) => {
            const { query, limit, callbackId } = detail;
            const results = this._searchTracks(query, limit);
            this._state.eventBus.emit('metadata:search-result', { tracks: results, callbackId });
        });

        // Récupérer une piste par ID
        this._state.eventBus.on('metadata:get-track', (detail) => {
            const { trackId, callbackId } = detail;
            const track = this._state.db.tracks.get(trackId);
            this._state.eventBus.emit('metadata:track-by-id-result', { track, callbackId });
        });

        // Récupérer toutes les pistes
        this._state.eventBus.on('metadata:get-all-tracks', (detail) => {
            const { callbackId } = detail;
            const tracks = Array.from(this._state.db.tracks.values());
            this._state.eventBus.emit('metadata:all-tracks-result', { tracks, callbackId });
        });

        // Récupérer un album
        this._state.eventBus.on('metadata:get-album', (detail) => {
            const { albumId, callbackId } = detail;
            const album = this._state.db.albums.get(albumId);
            this._state.eventBus.emit('metadata:album-result', { album, callbackId });
        });

        // Récupérer un artiste
        this._state.eventBus.on('metadata:get-artist', (detail) => {
            const { artistName, callbackId } = detail;
            const artist = this._state.db.artists.get(artistName);
            this._state.eventBus.emit('metadata:artist-result', { artist, callbackId });
        });

        // Statistiques
        this._state.eventBus.on('metadata:get-stats', () => {
            const stats = this._getStats();
            this._state.eventBus.emit('metadata:stats', stats);
        });

        // Scan de la bibliothèque
        this._state.eventBus.on('metadata:scan-request', async () => {
            await this.scanLocalFiles();
        });
    },

    // =========================================
    // VÉRIFICATION DES BIBLIOTHÈQUES ID3
    // =========================================
    _checkID3Libraries() {
        if (typeof jsmediatags !== 'undefined') {
            console.log('✅ jsmediatags disponible');
            this._state.hasJsMediaTags = true;
        } else {
            console.warn('⚠️ jsmediatags non trouvé');
        }

        if (typeof ID3 !== 'undefined') {
            console.log('✅ ID3js disponible');
            this._state.hasID3js = true;
        } else {
            console.warn('⚠️ ID3js non trouvé');
        }

        if (!this._state.hasJsMediaTags && !this._state.hasID3js) {
            console.error('❌ Aucune bibliothèque ID3 trouvée');
            this._showID3LibraryPrompt();
        }
    },

    // =========================================
    // CHARGEMENT DES DOSSIERS CONFIGURÉS
    // =========================================
    _loadMusicFolders() {
        const saved = localStorage.getItem('grand-archive-music-folders');
        if (saved) {
            try {
                this._state.config.musicFolders = JSON.parse(saved);
                console.log(`📁 ${this._state.config.musicFolders.length} dossiers configurés`);
            } catch (e) {
                console.warn('⚠️ Erreur chargement dossiers');
            }
        }
    },

    // =========================================
    // SCAN DES FICHIERS AVEC VRAIE EXTRACTION ID3
    // =========================================
    async scanLocalFiles() {
        if (this._state.isIndexing) return;

        this._state.isIndexing = true;
        this._state.scanningProgress = 0;

        console.log('🔍 Scan des fichiers musicaux...');
        this._state.eventBus.emit('metadata:scan-start', {});

        try {
            if (!window.showDirectoryPicker) {
                console.warn('⚠️ API File System Access non supportée');
                this._showFolderSelectionFallback();
                return;
            }

            const dirHandle = await window.showDirectoryPicker({
                id: 'music-library',
                mode: 'read',
                startIn: 'documents'
            });

            // Ajouter le dossier à la configuration
            this._addMusicFolder(dirHandle.name);

            await this._scanDirectory(dirHandle);

            // Sauvegarder après scan
            await this._saveDatabase();

            console.log(`✅ Scan terminé: ${this._state.stats.indexedTracks} pistes indexées`);
            this._state.eventBus.emit('metadata:scan-complete', {
                stats: this._state.stats
            });

        } catch (error) {
            if (error.name !== 'AbortError') {
                console.error('❌ Erreur scan:', error);
                this._state.eventBus.emit('metadata:scan-error', { error: error.message });
            }
        } finally {
            this._state.isIndexing = false;
            this._state.stats.lastScan = new Date().toISOString();
        }
    },

    // =========================================
    // SCAN RÉCURSIF DE DOSSIER
    // =========================================
    async _scanDirectory(dirHandle, path = '') {
        const entries = [];

        for await (const entry of dirHandle.values()) {
            entries.push(entry);
        }

        let processed = 0;
        const total = entries.length;

        for (const entry of entries) {
            processed++;
            this._state.scanningProgress = (processed / total) * 100;
            this._state.eventBus.emit('metadata:scan-progress', {
                progress: this._state.scanningProgress,
                current: entry.name
            });

            if (entry.kind === 'file') {
                if (this._isAudioFile(entry.name)) {
                    await this._processAudioFile(entry, path);
                }
            } else if (entry.kind === 'directory') {
                await this._scanDirectory(entry, path + entry.name + '/');
            }
        }
    },

    // =========================================
    // TRAITEMENT D'UN FICHIER AUDIO AVEC EXTRACTION ID3
    // =========================================
    async _processAudioFile(fileHandle, path) {
        try {
            const file = await fileHandle.getFile();

            // Lire le fichier pour extraction ID3
            const metadata = await this._extractID3Metadata(file);

            if (metadata) {
                await this._addTrackToDatabase({
                    id: this._generateTrackId(fileHandle.name, path),
                    filename: fileHandle.name,
                    path: path + fileHandle.name,
                    size: file.size,
                    lastModified: file.lastModified,
                    ...metadata
                });
            }

            this._state.stats.scannedFiles++;

        } catch (error) {
            console.warn(`⚠️ Erreur traitement ${fileHandle.name}:`, error);
            this._state.stats.failedTracks++;
        }
    },

    // =========================================
    // EXTRACTION ID3 AVEC jsmediatags
    // =========================================
    async _extractID3Metadata(file) {
        return new Promise((resolve, reject) => {
            if (this._state.hasJsMediaTags) {
                jsmediatags.read(file, {
                    onSuccess: (tag) => {
                        const metadata = this._parseJsMediaTags(tag);
                        resolve(metadata);
                    },
                    onError: (error) => {
                        if (this._state.hasID3js) {
                            this._extractWithID3js(file).then(resolve).catch(reject);
                        } else {
                            resolve(this._extractFromFilename(file.name));
                        }
                    }
                });
            } else if (this._state.hasID3js) {
                this._extractWithID3js(file).then(resolve).catch(reject);
            } else {
                resolve(this._extractFromFilename(file.name));
            }
        });
    },

    // =========================================
    // EXTRACTION AVEC ID3js
    // =========================================
    async _extractWithID3js(file) {
        return new Promise((resolve, reject) => {
            ID3.loadTags(file, () => {
                const tags = ID3.getAllTags(file);
                const metadata = this._parseID3jsTags(tags);
                resolve(metadata);
            }, {
                dataReader: ID3.FileAPIReader(file),
                tags: ["title", "artist", "album", "year", "track", "genre", "duration", "picture"]
            });
        });
    },

    // =========================================
    // PARSING JSMEDIATAGS
    // =========================================
    _parseJsMediaTags(tag) {
        const tags = tag.tags;

        // Extraire la cover
        let cover = null;
        if (tags.picture) {
            const picture = tags.picture;
            const base64 = this._arrayBufferToBase64(picture.data);
            cover = `data:${picture.format};base64,${base64}`;
        }

        return {
            title: tags.title || tags.TIT2 || '',
            artist: tags.artist || tags.TPE1 || '',
            album: tags.album || tags.TALB || '',
            year: tags.year || tags.TDRC || null,
            trackNumber: tags.track || tags.TRCK || null,
            genre: tags.genre || tags.TCON || '',
            duration: tags.duration || 0,
            bitrate: tags.bitrate || null,
            sampleRate: tags.sampleRate || null,
            cover: cover,
            comment: tags.comment || null,
            composer: tags.composer || null
        };
    },

    // =========================================
    // PARSING ID3JS
    // =========================================
    _parseID3jsTags(tags) {
        let cover = null;
        if (tags.picture) {
            const picture = tags.picture;
            const base64 = this._arrayBufferToBase64(picture.data);
            cover = `data:${picture.type};base64,${base64}`;
        }

        return {
            title: tags.title || '',
            artist: tags.artist || '',
            album: tags.album || '',
            year: tags.year || null,
            trackNumber: tags.track || null,
            genre: tags.genre || '',
            duration: tags.duration || 0,
            cover: cover
        };
    },

    // =========================================
    // FALLBACK: EXTRACTION DU NOM DE FICHIER
    // =========================================
    _extractFromFilename(filename) {
        const name = filename.substring(0, filename.lastIndexOf('.'));

        let artist = 'Artiste inconnu';
        let title = name;

        // Format "Artiste - Titre"
        if (name.includes(' - ')) {
            const parts = name.split(' - ');
            artist = parts[0].trim();
            title = parts[1].trim();
        }

        return {
            title,
            artist,
            album: 'Album inconnu',
            year: null,
            genre: null,
            trackNumber: null,
            duration: 0,
            cover: null
        };
    },

    // =========================================
    // AJOUT À LA BASE DE DONNÉES
    // =========================================
    async _addTrackToDatabase(track) {
        if (this._state.db.tracks.has(track.id)) return;

        this._state.db.tracks.set(track.id, track);
        this._state.totalTracks++;
        this._state.stats.indexedTracks++;
        this._state.stats.totalSize += track.size;
        this._state.stats.totalDuration += track.duration;

        // Mettre à jour l'album
        const albumKey = `${track.album}|${track.artist}`;
        if (!this._state.db.albums.has(albumKey)) {
            this._state.db.albums.set(albumKey, {
                id: albumKey,
                title: track.album,
                artist: track.artist,
                tracks: [],
                year: track.year,
                cover: track.cover,
                trackCount: 0
            });
        }

        const album = this._state.db.albums.get(albumKey);
        album.tracks.push(track.id);
        album.trackCount = album.tracks.length;

        // Mettre à jour l'artiste
        if (!this._state.db.artists.has(track.artist)) {
            this._state.db.artists.set(track.artist, {
                name: track.artist,
                albums: [],
                tracks: [],
                cover: track.cover
            });
        }

        const artist = this._state.db.artists.get(track.artist);
        if (!artist.tracks.includes(track.id)) {
            artist.tracks.push(track.id);
        }
        if (!artist.albums.includes(albumKey)) {
            artist.albums.push(albumKey);
        }

        this._updateSearchIndex(track);

        if (this._state.stats.indexedTracks % 10 === 0) {
            this._updateLibraryStats();
        }

        // Émettre un événement pour prévenir les autres modules (ex: lyrics)
        this._state.eventBus.emit('metadata:track-added', { trackId: track.id });
    },

    // =========================================
    // INDEX DE RECHERCHE
    // =========================================
    _updateSearchIndex(track) {
        this._state.searchIndex.tracks.push({
            id: track.id,
            title: track.title.toLowerCase(),
            artist: track.artist.toLowerCase(),
            album: track.album.toLowerCase()
        });

        this._state.searchIndex.tracks.sort((a, b) => a.title.localeCompare(b.title));
    },

    _searchTracks(query, limit = 100) {
        if (!query || query.length < 2) return [];

        const q = query.toLowerCase();
        const results = [];

        for (const idx of this._state.searchIndex.tracks) {
            if (idx.title.includes(q) || idx.artist.includes(q) || idx.album.includes(q)) {
                const fullTrack = this._state.db.tracks.get(idx.id);
                if (fullTrack) {
                    results.push(fullTrack);
                }
                if (results.length >= limit) break;
            }
        }

        return results;
    },

    // =========================================
    // GESTION DES DOSSIERS
    // =========================================
    _addMusicFolder(folderName) {
        if (!this._state.config.musicFolders.includes(folderName)) {
            this._state.config.musicFolders.push(folderName);
            localStorage.setItem('grand-archive-music-folders',
                JSON.stringify(this._state.config.musicFolders));
        }
    },

    removeMusicFolder(folderName) {
        const index = this._state.config.musicFolders.indexOf(folderName);
        if (index > -1) {
            this._state.config.musicFolders.splice(index, 1);
            localStorage.setItem('grand-archive-music-folders',
                JSON.stringify(this._state.config.musicFolders));
        }
    },

    // =========================================
    // GESTION DES PLAYLISTS
    // =========================================
    createPlaylist(name, description = '') {
        const id = `playlist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        const playlist = {
            id,
            name,
            description,
            tracks: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            cover: null
        };

        this._state.db.playlists.set(id, playlist);
        this._savePlaylists();
        this._state.eventBus.emit('metadata:playlist-created', { playlistId: id });
        return playlist;
    },

    addToPlaylist(playlistId, trackId) {
        const playlist = this._state.db.playlists.get(playlistId);
        const track = this._state.db.tracks.get(trackId);

        if (playlist && track && !playlist.tracks.includes(trackId)) {
            playlist.tracks.push(trackId);
            playlist.updatedAt = new Date().toISOString();
            this._savePlaylists();
            this._state.eventBus.emit('metadata:playlist-updated', { playlistId });
            return true;
        }
        return false;
    },

    removeFromPlaylist(playlistId, trackId) {
        const playlist = this._state.db.playlists.get(playlistId);
        if (playlist) {
            const index = playlist.tracks.indexOf(trackId);
            if (index > -1) {
                playlist.tracks.splice(index, 1);
                playlist.updatedAt = new Date().toISOString();
                this._savePlaylists();
                this._state.eventBus.emit('metadata:playlist-updated', { playlistId });
                return true;
            }
        }
        return false;
    },

    deletePlaylist(playlistId) {
        const deleted = this._state.db.playlists.delete(playlistId);
        if (deleted) {
            this._savePlaylists();
            this._state.eventBus.emit('metadata:playlist-deleted', { playlistId });
        }
        return deleted;
    },

    getPlaylistTracks(playlistId) {
        const playlist = this._state.db.playlists.get(playlistId);
        if (!playlist) return [];
        return playlist.tracks.map(id => this._state.db.tracks.get(id)).filter(t => t);
    },

    getPlaylists() {
        return Array.from(this._state.db.playlists.values());
    },

    // =========================================
    // STATISTIQUES
    // =========================================
    _updateLibraryStats() {
        if (this._elements.libraryTracks) {
            this._elements.libraryTracks.textContent = this._state.totalTracks;
        }

        if (this._elements.libraryHours) {
            const totalMinutes = Math.floor(this._state.stats.totalDuration / 60);
            const hours = Math.floor(totalMinutes / 60);
            this._elements.libraryHours.textContent = hours;
        }

        if (this._elements.libraryFavorites) {
            // Les favoris sont gérés ailleurs ; on peut afficher 0 ou les récupérer via localStorage
            try {
                const favs = JSON.parse(localStorage.getItem('favorites') || '[]').length;
                this._elements.libraryFavorites.textContent = favs;
            } catch {
                this._elements.libraryFavorites.textContent = '0';
            }
        }
    },

    _getStats() {
        return {
            ...this._state.stats,
            totalTracks: this._state.totalTracks,
            totalAlbums: this._state.db.albums.size,
            totalArtists: this._state.db.artists.size,
            totalPlaylists: this._state.db.playlists.size,
            scanningProgress: this._state.scanningProgress,
            isIndexing: this._state.isIndexing
        };
    },

    // =========================================
    // SAUVEGARDE
    // =========================================
    async _saveDatabase() {
        try {
            const data = {
                tracks: Array.from(this._state.db.tracks.entries()),
                albums: Array.from(this._state.db.albums.entries()),
                artists: Array.from(this._state.db.artists.entries()),
                stats: this._state.stats,
                totalTracks: this._state.totalTracks
            };

            localStorage.setItem('grand-archive-metadata', JSON.stringify(data));

            // Sauvegarder aussi via le module offline
            this._state.eventBus.emit('offline:cache-metadata', {
                trackId: 'all_tracks',
                metadata: Array.from(this._state.db.tracks.values())
            });

            this._state.lastSync = new Date().toISOString();
        } catch (error) {
            console.warn('⚠️ Erreur sauvegarde:', error);
        }
    },

    async _loadSavedData() {
        try {
            const saved = localStorage.getItem('grand-archive-metadata');
            if (saved) {
                const data = JSON.parse(saved);

                this._state.db.tracks = new Map(data.tracks || []);
                this._state.db.albums = new Map(data.albums || []);
                this._state.db.artists = new Map(data.artists || []);
                this._state.stats = data.stats || this._state.stats;
                this._state.totalTracks = data.totalTracks || 0;

                // Reconstruire l'index
                this._state.db.tracks.forEach(track => {
                    this._updateSearchIndex(track);
                });
            }

            console.log(`📚 Chargé: ${this._state.db.tracks.size} pistes`);
        } catch (error) {
            console.warn('⚠️ Erreur chargement données:', error);
        }
    },

    async _loadPlaylists() {
        try {
            const saved = localStorage.getItem('grand-archive-playlists');
            if (saved) {
                const playlists = JSON.parse(saved);
                this._state.db.playlists = new Map(Object.entries(playlists));
            }
        } catch (e) {
            console.warn('⚠️ Erreur chargement playlists:', e);
        }
    },

    _savePlaylists() {
        try {
            const playlistsObj = Object.fromEntries(this._state.db.playlists);
            localStorage.setItem('grand-archive-playlists', JSON.stringify(playlistsObj));
        } catch (e) {
            console.warn('⚠️ Erreur sauvegarde playlists:', e);
        }
    },

    // =========================================
    // PROMPT POUR BIBLIOTHÈQUES ID3
    // =========================================
    _showID3LibraryPrompt() {
        const notificationContainer = document.getElementById('notification-container');
        if (!notificationContainer) return;

        const notification = document.createElement('div');
        notification.className = 'notification notification-warning';
        notification.style.cssText = `
            background: rgba(255, 149, 0, 0.2);
            border-left: 4px solid #ff9500;
            padding: 15px 20px;
            max-width: 400px;
            cursor: pointer;
        `;

        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="bi bi-exclamation-triangle-fill" style="color: #ff9500; font-size: 20px;"></i>
                <div>
                    <strong style="color: white;">Bibliothèques ID3 manquantes</strong>
                    <p style="margin: 5px 0 0; font-size: 12px; opacity: 0.8;">
                        Ajoutez dans index.html:<br>
                        &lt;script src="https://cdnjs.cloudflare.com/ajax/libs/jsmediatags/3.9.5/jsmediatags.min.js"&gt;&lt;/script&gt;
                    </p>
                </div>
            </div>
        `;

        notificationContainer.appendChild(notification);
    },

    // =========================================
    // AUTRES UTILITAIRES
    // =========================================
    _isAudioFile(filename) {
        const ext = filename.substring(filename.lastIndexOf('.')).toLowerCase();
        return this._state.config.supportedFormats.includes(ext);
    },

    _generateTrackId(filename, path) {
        const str = path + filename;
        return `track_${btoa(str).substring(0, 30).replace(/[^a-zA-Z0-9]/g, '')}`;
    },

    _arrayBufferToBase64(buffer) {
        let binary = '';
        const bytes = new Uint8Array(buffer);
        for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    },

    _scheduleAutoScan() {
        // Pour l'instant, on ne fait pas de scan automatique périodique pour éviter de surcharger.
        // Mais on pourrait émettre un événement ou utiliser setTimeout.
        console.log('⏰ Scan automatique désactivé (à implémenter si besoin)');
    },

    _showFolderSelectionFallback() {
        this._state.eventBus.emit('notification:show', {
            message: 'Utilisez le bouton "Importer un dossier" dans l\'onglet Bibliothèque',
            type: 'info'
        });
    },


    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🤖 MetadataBot: Nettoyage...');
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.metadata = MetadataBot;
    console.log('📦 Module metadata enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement metadata:', e);
}