/**
 * THE GRAND ARCHIVE - Sound System Module
 * Version 2.1.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion des sons d'interface
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const SoundSystem = {
    // Identité du module
    name: 'sound',
    dependencies: [], // Indépendant
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        audioContext: null,
        enabled: true,
        currentSound: 'tac', // 'tac' ou 'tic'
        volume: 0.5,
        lastPlayTime: 0,
        minInterval: 50, // ms entre chaque son
        unlockListenerAttached: false,
        currentTheme: 'default' // thème actuel
    },
    
    // Éléments DOM (cachés)
    _elements: {
        soundSelect: null,
        soundVolume: null,
        soundVolumeValue: null,
        testBtn: null
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🔊 SoundSystem: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Initialiser le contexte audio
        this.initAudioContext();
        
        // Charger les préférences
        this.loadPreferences();
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Configurer les écouteurs d'événements DOM
        this.setupDOMEventListeners();
        
        // S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        // Configurer le déverrouillage audio au premier clic
        this.setupAudioUnlock();
        
        // Appliquer le thème actuel aux éléments UI
        const savedTheme = localStorage.getItem('grand-archive-theme') || 'default';
        this._state.currentTheme = savedTheme;
        this._applyThemeToUI(this._getThemeColor(savedTheme));
        
        this._state.initialized = true;
        console.log('✅ SoundSystem prêt');
        
        return this;
    },
    
    initAudioContext() {
        try {
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            this._state.audioContext = new AudioContext();
            console.log('🔊 Contexte audio créé');
        } catch (e) {
            console.warn('⚠️ Audio non supporté');
            this._state.enabled = false;
        }
    },
    
    loadPreferences() {
        try {
            const savedSound = localStorage.getItem('sound-preference');
            if (savedSound) this._state.currentSound = savedSound;
            
            const savedVolume = localStorage.getItem('sound-volume');
            if (savedVolume) this._state.volume = parseFloat(savedVolume) / 100;
        } catch (e) {
            console.warn('⚠️ Erreur chargement préférences sons', e);
        }
    },
    
    cacheElements() {
        this._elements = {
            soundSelect: document.getElementById('sound-select'),
            soundVolume: document.getElementById('sound-volume'),
            soundVolumeValue: document.getElementById('sound-volume-value'),
            testBtn: document.getElementById('test-sound-btn'),
            clearCacheBtn: document.getElementById('clear-cache-btn')
        };
    },
    
    setupDOMEventListeners() {
        // Sélecteur de son
        if (this._elements.soundSelect) {
            this._elements.soundSelect.value = this._state.currentSound;
            this._elements.soundSelect.addEventListener('change', (e) => {
                this.setSound(e.target.value);
                this.play(); // Jouer le son pour tester
            });
        }
        
        // Curseur de volume
        if (this._elements.soundVolume) {
            this._elements.soundVolume.value = this._state.volume * 100;
            this._elements.soundVolume.addEventListener('input', (e) => {
                const val = e.target.value;
                this.setVolume(val);
                if (this._elements.soundVolumeValue) {
                    this._elements.soundVolumeValue.textContent = val + '%';
                }
            });
        }
        
        // Bouton de test
        if (this._elements.testBtn) {
            this._elements.testBtn.addEventListener('click', () => this.play());
        }
        
        // Bouton vider le cache (exemple de son supplémentaire)
        if (this._elements.clearCacheBtn) {
            this._elements.clearCacheBtn.addEventListener('click', () => {
                this.play();
                // Ici, on pourrait émettre un événement pour vider le cache
                this._state.eventBus.emit('cache:clear', {});
            });
        }
    },
    
    subscribeToEvents() {
        // Écouter les demandes de lecture de son
        this._state.eventBus.on('sound:play', (detail) => {
            const soundName = detail.sound || 'click'; // On ignore le nom pour l'instant
            this.play();
        });
        
        // Écouter les changements de préférences (si un autre module les modifie)
        this._state.eventBus.on('sound:set-type', (detail) => {
            if (detail.type) this.setSound(detail.type);
        });
        
        this._state.eventBus.on('sound:set-volume', (detail) => {
            if (detail.volume !== undefined) this.setVolume(detail.volume);
        });
        
        // Écouter la demande de test
        this._state.eventBus.on('sound:test', () => {
            this.play();
        });

        // *** NOUVEAU : Écouter les changements de thème ***
        this._state.eventBus.on('theme:changed', (detail) => {
            const color = detail.color || this._getThemeColor(detail.theme);
            this._applyThemeToUI(color);
        });
    },
    
    setupAudioUnlock() {
        if (!this._state.audioContext || this._state.unlockListenerAttached) return;
        
        // Déverrouiller l'audio au premier clic (requis par les navigateurs)
        const unlock = () => {
            if (this._state.audioContext && this._state.audioContext.state === 'suspended') {
                this._state.audioContext.resume().then(() => {
                    console.log('🔊 Contexte audio déverrouillé');
                });
            }
            document.removeEventListener('click', unlock);
            document.removeEventListener('touchstart', unlock);
            this._state.unlockListenerAttached = false;
        };
        
        document.addEventListener('click', unlock);
        document.addEventListener('touchstart', unlock);
        this._state.unlockListenerAttached = true;
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES (appelées via événements)
    // =========================================
    
    /**
     * Joue le son actuel
     */
    play() {
        if (!this._state.enabled || !this._state.audioContext) return;
        
        const now = Date.now();
        if (now - this._state.lastPlayTime < this._state.minInterval) return;
        
        try {
            if (this._state.audioContext.state === 'suspended') {
                this._state.audioContext.resume();
            }
            
            if (this._state.currentSound === 'tac') {
                this.playTac();
            } else {
                this.playTic();
            }
            
            this._state.lastPlayTime = now;
        } catch (e) {
            console.warn('🔊 Erreur lecture son', e);
        }
    },
    
    playTac() {
        const ctx = this._state.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = 500;
        
        gainNode.gain.setValueAtTime(this._state.volume, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.04);
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.start();
        oscillator.stop(ctx.currentTime + 0.04);
    },
    
    playTic() {
        const ctx = this._state.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = 800;
        
        gainNode.gain.setValueAtTime(this._state.volume, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.02);
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.start();
        oscillator.stop(ctx.currentTime + 0.02);
    },
    
    /**
     * Change le type de son
     */
    setSound(type) {
        if (type === 'tac' || type === 'tic') {
            this._state.currentSound = type;
            localStorage.setItem('sound-preference', type);
            
            // Émettre un événement pour informer les autres modules
            this._state.eventBus.emit('sound:type-changed', { type });
        }
    },
    
    /**
     * Change le volume
     */
    setVolume(value) {
        const volume = Math.min(100, Math.max(0, value));
        this._state.volume = volume / 100;
        localStorage.setItem('sound-volume', volume);
        
        // Mettre à jour l'affichage si l'élément existe
        if (this._elements.soundVolume) {
            this._elements.soundVolume.value = volume;
        }
        if (this._elements.soundVolumeValue) {
            this._elements.soundVolumeValue.textContent = volume + '%';
        }
        
        // Émettre un événement
        this._state.eventBus.emit('sound:volume-changed', { volume });
    },
    
    /**
     * Teste le son
     */
    test() {
        this.play();
    },
    
    /**
     * Active/désactive les sons
     */
    setEnabled(enabled) {
        this._state.enabled = enabled;
    },
    
    // =========================================
    // UTILITAIRES
    // =========================================
    
    /**
     * Retourne l'état du module
     */
    getState() {
        return {
            enabled: this._state.enabled,
            currentSound: this._state.currentSound,
            volume: this._state.volume * 100,
            audioContextState: this._state.audioContext?.state
        };
    },

    // *** NOUVELLE MÉTHODE POUR APPLIQUER LE THÈME AUX ÉLÉMENTS UI ***
    /**
     * Applique la couleur du thème aux éléments de contrôle
     * @param {string} color - Couleur en hexadécimal (ex: '#ff0055')
     */
    _applyThemeToUI(color) {
        // 1. Curseur de volume (input range)
        if (this._elements.soundVolume) {
            // accent-color est supporté par les navigateurs modernes
            this._elements.soundVolume.style.accentColor = color;
        }
        
        // 2. Sélecteur de type de son (select)
        if (this._elements.soundSelect) {
            this._elements.soundSelect.style.borderColor = color;
            // Optionnel : changer la couleur de fond de la flèche (plus complexe)
        }
        
        // 3. Bouton de test
        if (this._elements.testBtn) {
            this._elements.testBtn.style.backgroundColor = color;
            this._elements.testBtn.style.color = '#ffffff';
            this._elements.testBtn.style.border = 'none';
            this._elements.testBtn.style.transition = 'background-color 0.3s ease';
        }
        
        // 4. Icône du groupe Sons (optionnel)
        const soundIcon = document.querySelector('.settings-group h3 i.bi-soundwave');
        if (soundIcon) {
            soundIcon.style.color = color;
        }
    },

    /**
     * Retourne la couleur associée à un thème
     * @param {string} theme - Nom du thème (default, deep-space, etc.)
     * @returns {string} Code couleur hexadécimal
     */
    _getThemeColor(theme) {
        const colors = {
            'default': '#ff0055',
            'deep-space': '#00aaff',
            'midnight': '#aa88ff',
            'aurora': '#6effb0',
            'sunset': '#ff884d',
            'forest': '#66cc66'
        };
        return colors[theme] || colors.default;
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🔊 SoundSystem: Nettoyage...');
        
        if (this._state.audioContext) {
            this._state.audioContext.close();
        }
        
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.sound = SoundSystem;

console.log('🔊 SoundSystem: Module enregistré');