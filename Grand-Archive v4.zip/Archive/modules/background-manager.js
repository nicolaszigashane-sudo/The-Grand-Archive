/**
 * THE GRAND ARCHIVE - Background Manager Module
 * Version 1.0.0
 * 
 * Copyright (C) 2026 [davidb]
 * Licence: GNU General Public License v3.0
 * 
 * Gère le diaporama d'arrière-plan avec catégories
 */

const BackgroundManager = {
    name: 'background',
    dependencies: [],
    
    _state: {
        initialized: false,
        eventBus: null,
        slideshowInterval: null,
        currentSlideIsFirst: true,
        isTransitioning: false,
        lastBackgroundIndex: -1,
        activeCategory: 'default',
        backgrounds: [],
        backgroundsPath: 'backgrounds/',
        categories: {}
    },
    
    _elements: {
        slide1: null,
        slide2: null
    },
    
    init(config) {
        console.log('🖼️ BackgroundManager: Initialisation...');
        
        this._state.eventBus = config.eventBus;
        
        // Récupérer les éléments
        this._elements.slide1 = document.getElementById('slide-1');
        this._elements.slide2 = document.getElementById('slide-2');
        
        if (!this._elements.slide1) {
            console.error('❌ BackgroundManager: slide-1 introuvable');
            return this;
        }
        
        // Initialiser les styles avec transitions CSS
        this._elements.slide1.style.opacity = '1';
        this._elements.slide1.style.zIndex = '2';
        this._elements.slide1.style.transition = 'opacity 1.5s ease-in-out';
        
        if (this._elements.slide2) {
            this._elements.slide2.style.opacity = '0';
            this._elements.slide2.style.zIndex = '1';
            this._elements.slide2.style.transition = 'opacity 1.5s ease-in-out';
        }
        
        // Configuration des catégories
        this._state.categories = {
            default: ['bg-1.jpg', 'bg-2.gif', 'bg-3.gif', 'bg-4.gif', 'bg-5.gif', 'bg-6.gif'],
            luffy: [],
            architecture: [],
            bonhommeNeige: [],
            robot: [],
            classe: [],
            makotoShinkai: [],
            harryPotter: [],
            naruto: [],
            paysage: [],
            imported: [] // Pour les images importées
        };
        
        // Générer les images pour chaque catégorie (1.jpg à 10.jpg)
        for (let cat in this._state.categories) {
            if (cat !== 'default' && cat !== 'imported') {
                const images = [];
                for (let i = 1; i <= 10; i++) {
                    images.push(i + '.jpg');
                }
                this._state.categories[cat] = images;
            }
        }
        
        // Démarrer avec la catégorie par défaut
        this._state.backgrounds = this._state.categories.default;
        this._state.backgroundsPath = 'backgrounds/';
        
        // Charger la première image
        this.loadRandomImage(this._elements.slide1, () => this.startSlideshow());
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ BackgroundManager prêt');
        
        return this;
    },
    
    subscribeToEvents() {
        // Changer de catégorie
        this._state.eventBus.on('background:change-category', (detail) => {
            this.changeCategory(detail.category);
        });
        
        // Importer des images
        this._state.eventBus.on('background:import', (detail) => {
            this.importImages(detail.files);
        });
        
        // Vider les imports
        this._state.eventBus.on('background:clear-imported', () => {
            this.clearImported();
        });
        
        // Obtenir l'état actuel
        this._state.eventBus.on('background:get-status', () => {
            this._state.eventBus.emit('background:status', {
                activeCategory: this._state.activeCategory,
                backgroundsPath: this._state.backgroundsPath,
                imageCount: this._state.backgrounds.length,
                categories: Object.keys(this._state.categories)
            });
        });
    },
    
    changeCategory(category) {
        if (!this._state.categories[category]) {
            console.warn('❌ Catégorie inconnue:', category);
            return;
        }
        
        this._state.activeCategory = category;
        
        // Cas spécial pour les images importées
        if (category === 'imported') {
            this._state.backgrounds = this._state.categories[category];
            this._state.backgroundsPath = ''; // Pas de chemin, on utilise l'url directe
        } else {
            this._state.backgrounds = this._state.categories[category];
            if (category === 'default') {
                this._state.backgroundsPath = 'backgrounds/';
            } else {
                this._state.backgroundsPath = 'backgrounds/' + category + '/';
            }
        }
        
        this._state.lastBackgroundIndex = -1;
        
        // Relancer le diaporama
        if (this._elements.slide1) {
            this.loadRandomImage(this._elements.slide1);
        }
        
        // Émettre l'événement de confirmation
        this._state.eventBus.emit('background:changed', {
            category: category,
            path: this._state.backgroundsPath || 'imported',
            count: this._state.backgrounds.length
        });
        
        console.log('📁 Background changé:', category, '→', this._state.backgroundsPath || 'imported');
    },
    
    loadRandomImage(slideElement, callback) {
        if (!this._state.backgrounds || this._state.backgrounds.length === 0) {
            console.warn('🖼️ Aucun background disponible');
            return;
        }
        
        // Éviter le doublon si possible
        let randomIndex;
        do {
            randomIndex = Math.floor(Math.random() * this._state.backgrounds.length);
        } while (randomIndex === this._state.lastBackgroundIndex && this._state.backgrounds.length > 1);
        
        this._state.lastBackgroundIndex = randomIndex;
        
        const bg = this._state.backgrounds[randomIndex];
        
        // Gérer les deux types : string (nom de fichier) ou objet (importé)
        let imgPath;
        if (typeof bg === 'string') {
            imgPath = this._state.backgroundsPath + bg;
        } else {
            imgPath = bg.url; // Image importée
        }
        
        const img = new Image();
        img.onload = () => {
            slideElement.style.backgroundImage = `url('${imgPath}')`;
            if (callback) callback();
        };
        img.onerror = () => {
            console.warn(`❌ Image non trouvée: ${imgPath}`);
            // Réessayer avec une autre image
            this.loadRandomImage(slideElement, callback);
        };
        img.src = imgPath;
    },
    
    startSlideshow() {
        if (!this._elements.slide1 || !this._elements.slide2) return;
        
        if (this._state.slideshowInterval) {
            clearInterval(this._state.slideshowInterval);
        }
        
        this._state.slideshowInterval = setInterval(() => {
            if (this._state.isTransitioning) return;
            this._state.isTransitioning = true;
            
            const activeSlide = this._state.currentSlideIsFirst ? this._elements.slide1 : this._elements.slide2;
            const nextSlide = this._state.currentSlideIsFirst ? this._elements.slide2 : this._elements.slide1;
            
            // Éviter le doublon
            let randomIndex;
            do {
                randomIndex = Math.floor(Math.random() * this._state.backgrounds.length);
            } while (randomIndex === this._state.lastBackgroundIndex && this._state.backgrounds.length > 1);
            
            this._state.lastBackgroundIndex = randomIndex;
            
            const bg = this._state.backgrounds[randomIndex];
            
            // Gérer les deux types : string (nom de fichier) ou objet (importé)
            let imgPath;
            if (typeof bg === 'string') {
                imgPath = this._state.backgroundsPath + bg;
            } else {
                imgPath = bg.url; // Image importée
            }
            
            // Précharger l'image avant la transition
            const img = new Image();
            img.onload = () => {
                // Appliquer la nouvelle image à la slide suivante (invisible)
                nextSlide.style.backgroundImage = `url('${imgPath}')`;
                
                // Force reflow pour assurer que la transition démarre
                void nextSlide.offsetWidth;
                
                // Transition croisée fluide
                nextSlide.style.opacity = '1';
                nextSlide.style.zIndex = '2';
                activeSlide.style.opacity = '0';
                activeSlide.style.zIndex = '1';
                
                setTimeout(() => {
                    this._state.currentSlideIsFirst = !this._state.currentSlideIsFirst;
                    this._state.isTransitioning = false;
                }, 1500); // 1.5s correspond à la durée de transition CSS
            };
            img.onerror = () => {
                this._state.isTransitioning = false;
            };
            img.src = imgPath;
        }, 8000); // Timer unique de 8 secondes pour toutes les catégories
    },
    
    // Fonction d'import d'images
    importImages(files) {
        if (!files || files.length === 0) return;
        
        // Créer la catégorie "imported" si elle n'existe pas
        if (!this._state.categories.imported) {
            this._state.categories.imported = [];
        }
        
        let importedCount = 0;
        
        // Ajouter chaque image
        for (let file of files) {
            if (!file.type.startsWith('image/')) continue;
            
            // Créer une URL temporaire
            const url = URL.createObjectURL(file);
            
            this._state.categories.imported.push({
                url: url,
                name: file.name,
                type: file.type,
                size: file.size,
                imported: true,
                date: new Date().toLocaleString()
            });
            
            importedCount++;
        }
        
        if (importedCount > 0) {
            // Basculer automatiquement sur la catégorie importée
            this.changeCategory('imported');
            
            // Émettre un événement
            this._state.eventBus.emit('background:imported', {
                count: importedCount,
                category: 'imported'
            });
            
            console.log(`📥 ${importedCount} image(s) importée(s)`);
        }
    },
    
    // Fonction pour nettoyer les imports
    clearImported() {
        if (this._state.categories.imported && this._state.categories.imported.length > 0) {
            // Nettoyer les URLs temporaires pour libérer la mémoire
            this._state.categories.imported.forEach(img => {
                if (img.url && img.url.startsWith('blob:')) {
                    URL.revokeObjectURL(img.url);
                }
            });
            
            this._state.categories.imported = [];
            
            // Revenir à la catégorie par défaut si on était sur imported
            if (this._state.activeCategory === 'imported') {
                this.changeCategory('default');
            }
            
            // Émettre un événement
            this._state.eventBus.emit('background:cleared', {
                message: 'Images importées vidées'
            });
            
            console.log('🗑️ Images importées vidées');
        }
    },
    
    destroy() {
        // Nettoyer les URLs des images importées
        if (this._state.categories.imported) {
            this._state.categories.imported.forEach(img => {
                if (img.url && img.url.startsWith('blob:')) {
                    URL.revokeObjectURL(img.url);
                }
            });
        }
        
        if (this._state.slideshowInterval) {
            clearInterval(this._state.slideshowInterval);
            this._state.slideshowInterval = null;
        }
        
        this._state.initialized = false;
        console.log('🖼️ BackgroundManager détruit');
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.background = BackgroundManager;
console.log('🖼️ BackgroundManager: Module enregistré');