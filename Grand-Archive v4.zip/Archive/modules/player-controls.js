/**
 * THE GRAND ARCHIVE - Player Controls Module
 * Version 4.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Contrôles avancés du player
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const PlayerControls = {
    // Identité du module
    name: 'playerControls',
    dependencies: ['sound', 'radio', 'local', 'ui'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        // État du player
        isPlaying: false,
        currentVolume: 70,
        previousVolume: 70,
        isMuted: false,
        repeatMode: 'off',
        shuffleMode: false,
        speed: 1.0,
        karaokeMode: false,
        favorites: new Set(),
        progressInterval: null,
        isDraggingProgress: false,
        isDraggingVolume: false,
        currentTrackDuration: 240,
        currentTrackPosition: 0,
        
        // État des sources
        activeSource: null, // 'radio', 'local', null
        
        // Références audio
        audioInstance: null,
        currentAudioUrl: null,
        
        // Piste en cours
        currentTrack: null,
        
        // Détection de l'environnement
        isTauri: typeof window !== 'undefined' && window.__TAURI__ !== undefined
    },
    
    // Éléments DOM (cachés)
    _elements: {},
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🎮 PlayerControls: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Charger les favoris depuis localStorage
        this.loadFavorites();
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Configurer les écouteurs d'événements DOM
        this.setupDOMEventListeners();
        
        // S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        // Restaurer l'état sauvegardé
        this.restoreState();
        
        this._state.initialized = true;
        console.log('✅ PlayerControls prêt', this._state.isTauri ? '(Mode Tauri)' : '(Mode Web)');
        
        return this;
    },
    
    // =========================================
    // CACHE DES ÉLÉMENTS DOM
    // =========================================
    cacheElements() {
        this._elements = {
            playBtn: document.getElementById('play-btn'),
            prevBtn: document.getElementById('prev-btn'),
            nextBtn: document.getElementById('next-btn'),
            stopBtn: document.getElementById('stop-btn'),
            trackLine: document.getElementById('track-line'),
            trackFill: document.getElementById('track-progress'),
            trackHandle: document.getElementById('track-handle'),
            currentTime: document.getElementById('current-time'),
            totalTime: document.getElementById('total-time'),
            volumeIcon: document.getElementById('volume-icon'),
            volumeSlider: document.getElementById('volume-slider'),
            volumeFill: document.getElementById('volume-fill'),
            volumeHandle: document.getElementById('volume-handle'),
            volumePercent: document.getElementById('volume-percent'),
            favoriteBtn: document.getElementById('favorite-btn'),
            repeatBtn: document.getElementById('repeat-btn'),
            shuffleBtn: document.getElementById('shuffle-btn'),
            speedBtn: document.getElementById('speed-btn'),
            karaokeBtn: document.getElementById('karaoke-btn'),
            fullscreenBtn: document.getElementById('fullscreen-btn'),
            contextToast: document.getElementById('context-toast'),
            toastMessage: document.getElementById('toast-message'),
            miniTitle: document.getElementById('mini-title'),
            miniArtist: document.getElementById('mini-artist'),
            miniImg: document.getElementById('mini-player-img'),
            currentTitle: document.getElementById('current-title'),
            currentArtist: document.getElementById('current-artist'),
        };
        
        // Vérification silencieuse
        const missing = Object.entries(this._elements)
            .filter(([key, el]) => !el)
            .map(([key]) => key);
        
        if (missing.length > 0) {
            console.warn('🎮 PlayerControls: Éléments manquants', missing);
        }
    },
    
    // =========================================
    // ÉCOUTEURS D'ÉVÉNEMENTS DOM
    // =========================================
    setupDOMEventListeners() {
        // Boutons principaux
        this.attachPlayEvents();
        this.attachNavigationEvents();
        this.attachActionEvents();
        this.attachFullscreenEvents();
        
        // Contrôles de progression
        this.setupProgressBar();
        this.setupVolumeControl();
    },
    
    attachPlayEvents() {
        const { playBtn, stopBtn } = this._elements;
        
        if (playBtn) {
            playBtn.addEventListener('click', () => {
                // Demander le son à l'orchestrateur
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                
                // Émettre l'événement de toggle play
                this._state.eventBus.emit('player:toggle', {
                    source: 'button',
                    timestamp: Date.now()
                });
            });
        }
        
        if (stopBtn) {
            stopBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this._state.eventBus.emit('player:stop', {
                    source: 'button',
                    timestamp: Date.now()
                });
            });
        }
    },
    
    attachNavigationEvents() {
        const { prevBtn, nextBtn } = this._elements;
        
        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.animateButton(prevBtn);
                
                this._state.eventBus.emit('player:previous', {
                    source: 'button',
                    timestamp: Date.now()
                });
                
                this.showToast('⏮️ Précédent');
            });
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.animateButton(nextBtn);
                
                this._state.eventBus.emit('player:next', {
                    source: 'button',
                    timestamp: Date.now()
                });
                
                this.showToast('⏭️ Suivant');
            });
        }
    },
    
    attachActionEvents() {
        const { favoriteBtn, repeatBtn, shuffleBtn, speedBtn, karaokeBtn } = this._elements;
        
        if (favoriteBtn) {
            favoriteBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.toggleFavorite();
            });
        }
        
        if (repeatBtn) {
            repeatBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.cycleRepeat();
            });
        }
        
        if (shuffleBtn) {
            shuffleBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.toggleShuffle();
            });
        }
        
        if (speedBtn) {
            speedBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.cycleSpeed();
            });
        }
        
        if (karaokeBtn) {
            karaokeBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.toggleKaraoke();
            });
        }
    },
    
    attachFullscreenEvents() {
        const { fullscreenBtn } = this._elements;
        if (!fullscreenBtn) return;
        
        fullscreenBtn.addEventListener('click', () => {
            this._state.eventBus.emit('sound:play', { sound: 'click' });
            this.toggleFullscreen();
        });
        
        document.addEventListener('fullscreenchange', () => {
            if (document.fullscreenElement) {
                fullscreenBtn.classList.add('active');
            } else {
                fullscreenBtn.classList.remove('active');
            }
        });
    },
    
    // =========================================
    // ABONNEMENT AUX ÉVÉNEMENTS DE L'APPLICATION
    // =========================================
    subscribeToEvents() {
        // Événements de lecture
        this._state.eventBus.on('player:toggle', () => this.togglePlay());
        this._state.eventBus.on('player:stop', () => this.stop());
        this._state.eventBus.on('player:play', () => this.play());
        this._state.eventBus.on('player:pause', () => this.pause());
        this._state.eventBus.on('player:next', () => this.next());
        this._state.eventBus.on('player:previous', () => this.previous());
        
        // Événement pour jouer un morceau directement
        this._state.eventBus.on('player:play-track', (detail) => {
            this.playTrack(detail.track);
        });
        
        // Événements de volume
        this._state.eventBus.on('volume:set', (detail) => {
            this.setVolume(detail.volume);
        });
        
        this._state.eventBus.on('volume:mute', () => this.toggleMute());
        
        // Événements des sources
        this._state.eventBus.on('radio:playing', (detail) => {
            this.setActiveSource('radio', detail);
        });
        
        this._state.eventBus.on('radio:stopped', () => {
            if (this._state.activeSource === 'radio') {
                this.clearActiveSource();
            }
        });
        
        this._state.eventBus.on('local:playing', (detail) => {
            this.setActiveSource('local', detail);
            this.playLocalTrack(detail.url, detail.duration);
        });
        
        this._state.eventBus.on('local:stopped', () => {
            if (this._state.activeSource === 'local') {
                this.stopLocal();
                this.clearActiveSource();
            }
        });
        
        // Événements de progression
        this._state.eventBus.on('track:progress', (detail) => {
            this.updateProgress(detail.percentage, detail.position);
        });
        
        // Événements de métadonnées
        this._state.eventBus.on('track:metadata', (detail) => {
            this.updateTrackInfo(detail);
        });
        
        // Événements de favoris
        this._state.eventBus.on('favorite:updated', (detail) => {
            this.updateFavoriteButton(detail.isFavorite);
        });
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES
    // =========================================
    
    /**
     * Joue/ met en pause selon la source active
     */
    togglePlay() {
        if (this._state.activeSource === 'radio') {
            this._state.eventBus.emit('radio:toggle', {});
        } else if (this._state.activeSource === 'local' && this._state.audioInstance) {
            this.toggleLocalPlay();
        } else {
            this.showToast('🎵 Sélectionnez un morceau d\'abord');
        }
    },
    
    /**
     * Arrête la lecture
     */
    stop() {
        if (this._state.activeSource === 'radio') {
            this._state.eventBus.emit('radio:stop', {});
        } else if (this._state.activeSource === 'local') {
            this.stopLocal();
        }
    },
    
    /**
     * Passe au morceau suivant
     */
    next() {
        if (this._state.activeSource === 'radio') {
            this._state.eventBus.emit('radio:next', {});
        }
        // Pour le local, ce sera géré par le module local
    },
    
    /**
     * Passe au morceau précédent
     */
    previous() {
        if (this._state.activeSource === 'radio') {
            this._state.eventBus.emit('radio:previous', {});
        }
    },
    
    /**
     * Méthode centralisée pour jouer un morceau (support Tauri inclus)
     */
    playTrack(track) {
        if (!track) return;
        
        console.log('🎮 PlayerControls: Lecture du morceau', track);
        
        // Sauvegarder le morceau courant
        this._state.currentTrack = track;
        
        // Mettre à jour les titres partout
        const title = track.name || track.title || 'Titre inconnu';
        const artist = track.artist || 'Artiste inconnu';
        
        if (this._elements.miniTitle) this._elements.miniTitle.textContent = title;
        if (this._elements.miniArtist) this._elements.miniArtist.textContent = artist;
        if (this._elements.currentTitle) this._elements.currentTitle.textContent = title;
        if (this._elements.currentArtist) this._elements.currentArtist.textContent = artist;
        
        // Mettre à jour la cover
        if (this._elements.miniImg) {
            this._elements.miniImg.src = track.cover || track.coverSmall || 'backgrounds/default-cover.jpg';
        }
        
        // Déterminer la source audio
        let audioUrl = null;
        let duration = track.duration || 240;
        
        if (track.previewUrl) {
            // Source iTunes (streaming)
            audioUrl = track.previewUrl;
            duration = track.duration ? track.duration / 1000 : 30;
            console.log('📱 Source: iTunes preview');
        } else if (track.url) {
            // Source URL directe (streaming)
            audioUrl = track.url;
            console.log('🌐 Source: URL directe');
        } else if (track.path) {
            // Source locale (fichier)
            if (this._state.isTauri) {
                // En mode Tauri, on utilise le protocole asset://
                // Note: Le chemin doit être absolu et accessible
                audioUrl = `asset://${track.path}`;
                console.log('💾 Source: Fichier local (Tauri)', audioUrl);
            } else if (track.path.startsWith('blob:')) {
                // En mode Web, on utilise l'URL blob créée lors du scan
                audioUrl = track.path;
                console.log('💾 Source: Fichier local (Web)');
            } else {
                console.error('❌ Format de chemin local non supporté');
                this.showToast('❌ Fichier local non accessible');
                return;
            }
        } else {
            console.error('❌ Aucune source audio disponible');
            this.showToast('❌ Pas de source audio');
            return;
        }
        
        // Lancer la lecture
        this.playRealAudio(audioUrl, duration);
        
        // Sauvegarder dans l'historique
        this._saveToHistory(track);
        
        // Mettre à jour le bouton favori
        this.updateFavoriteButton(this._state.favorites.has(title));
        
        // Émettre un événement pour informer les autres modules
        this._state.eventBus.emit('track:changed', { track });
    },
    
    /**
     * Sauvegarde dans l'historique
     */
    _saveToHistory(track) {
        try {
            const history = JSON.parse(localStorage.getItem('play-history') || '[]');
            history.unshift({
                id: track.id,
                name: track.name || track.title,
                artist: track.artist,
                cover: track.cover || track.coverSmall,
                playedAt: new Date().toISOString()
            });
            if (history.length > 50) history.pop();
            localStorage.setItem('play-history', JSON.stringify(history));
        } catch (e) {
            console.warn('⚠️ Erreur sauvegarde historique', e);
        }
    },
    
    /**
     * Définit le volume
     */
    setVolume(volume) {
        this._state.currentVolume = Math.min(100, Math.max(0, volume));
        this._state.previousVolume = this._state.currentVolume;
        
        this.updateVolumeDisplay();
        localStorage.setItem('volume', this._state.currentVolume);
        
        // Propager le volume aux sources
        this._state.eventBus.emit('volume:changed', {
            volume: this._state.currentVolume,
            source: 'playerControls'
        });
        
        if (this._state.audioInstance) {
            this._state.audioInstance.volume(this._state.currentVolume / 100);
        }
    },
    
    /**
     * Active/désactive le mode karaoké
     */
    toggleKaraoke() {
        this._state.karaokeMode = !this._state.karaokeMode;
        this.animateButton(this._elements.karaokeBtn);
        
        if (this._state.karaokeMode) {
            this._elements.karaokeBtn.classList.add('active');
            this.showToast('🎤 Mode karaoké activé');
        } else {
            this._elements.karaokeBtn.classList.remove('active');
            this.showToast('🎤 Mode karaoké désactivé');
        }
        
        this._state.eventBus.emit('karaoke:toggled', {
            active: this._state.karaokeMode
        });
    },
    
    // =========================================
    // GESTION DE LA SOURCE ACTIVE
    // =========================================
    
    setActiveSource(source, data) {
        this._state.activeSource = source;
        this._state.isPlaying = true;
        
        this.updatePlayButton();
        
        if (this._elements.stopBtn) {
            this._elements.stopBtn.style.display = 'inline-block';
        }
        
        // Mettre à jour les infos du morceau si fournies
        if (data) {
            this.updateTrackInfo(data);
        }
    },
    
    clearActiveSource() {
        this._state.activeSource = null;
        this._state.isPlaying = false;
        
        this.updatePlayButton();
        this.resetProgress();
        
        if (this._elements.stopBtn) {
            this._elements.stopBtn.style.display = 'none';
        }
    },
    
    // =========================================
    // LECTURE AUDIO AVEC HOWLER
    // =========================================
    
    playRealAudio(url, duration = 240) {
        if (!window.Howl) {
            console.error('❌ Howler.js non chargé');
            this.showToast('❌ Erreur: Howler.js non chargé');
            return;
        }
        
        // Arrêter la radio si elle joue
        if (this._state.activeSource === 'radio') {
            this._state.eventBus.emit('radio:stop', {});
        }
        
        // Arrêter l'instance précédente
        if (this._state.audioInstance) {
            this._state.audioInstance.stop();
            this._state.audioInstance = null;
        }
        
        this._state.currentAudioUrl = url;
        this._state.currentTrackDuration = duration;
        this._state.activeSource = 'local';
        
        console.log('🎵 Chargement audio:', url);
        
        // Configuration Howler avec support des fichiers locaux
        const howlOptions = {
            src: [url],
            html5: true, // Important pour les gros fichiers locaux
            volume: this._state.currentVolume / 100,
            rate: this._state.speed,
            onplay: () => {
                console.log('▶️ Lecture démarrée');
                this._state.isPlaying = true;
                this.updatePlayButton();
                this.startProgressTracking();
                
                this._state.eventBus.emit('local:playback-started', {
                    url: this._state.currentAudioUrl
                });
            },
            onpause: () => {
                console.log('⏸️ Lecture en pause');
                this._state.isPlaying = false;
                this.updatePlayButton();
                this.stopProgressTracking();
            },
            onstop: () => {
                console.log('⏹️ Lecture arrêtée');
                this._state.isPlaying = false;
                this.updatePlayButton();
                this.resetProgress();
                this.stopProgressTracking();
                
                this._state.eventBus.emit('local:playback-stopped', {});
            },
            onend: () => {
                console.log('⏹️ Fin du morceau');
                this._state.isPlaying = false;
                this.updatePlayButton();
                this.resetProgress();
                
                this._state.eventBus.emit('local:track-ended', {
                    repeatMode: this._state.repeatMode
                });
                
                if (this._state.repeatMode === 'one') {
                    this.playRealAudio(url, duration);
                } else if (this._state.repeatMode === 'all' && this._elements.nextBtn) {
                    // Simuler clic suivant pour la playlist
                    this.next();
                } else {
                    this._state.activeSource = null;
                    if (this._elements.stopBtn) {
                        this._elements.stopBtn.style.display = 'none';
                    }
                }
            },
            onloaderror: (id, error) => {
                console.error('❌ Erreur chargement audio:', error);
                this.showToast('❌ Impossible de jouer ce morceau');
                this._state.isPlaying = false;
                this.updatePlayButton();
            }
        };
        
        // En mode Tauri, on peut ajouter des options spécifiques si nécessaire
        if (this._state.isTauri && url.startsWith('asset://')) {
            // Les fichiers locaux via asset:// fonctionnent avec Howler standard
            console.log('🔧 Mode Tauri détecté pour la lecture locale');
        }
        
        this._state.audioInstance = new Howl(howlOptions);
        this._state.audioInstance.play();
        
        if (this._elements.totalTime) {
            this._elements.totalTime.textContent = this.formatTime(duration);
        }
        
        return this._state.audioInstance;
    },
    
    toggleLocalPlay() {
        if (!this._state.audioInstance) return;
        
        if (this._state.isPlaying) {
            this._state.audioInstance.pause();
        } else {
            this._state.audioInstance.play();
        }
    },
    
    stopLocal() {
        if (this._state.audioInstance) {
            this._state.audioInstance.stop();
        }
        this.resetProgress();
    },
    
    // =========================================
    // GESTION DE LA PROGRESSION
    // =========================================
    
    startProgressTracking() {
        if (this._state.progressInterval) {
            clearInterval(this._state.progressInterval);
        }
        
        this._state.progressInterval = setInterval(() => {
            if (this._state.audioInstance && this._state.isPlaying) {
                const seek = this._state.audioInstance.seek();
                const duration = this._state.audioInstance.duration();
                
                if (duration > 0) {
                    const percentage = (seek / duration) * 100;
                    this.updateProgress(percentage, seek);
                    
                    this._state.eventBus.emit('track:progress-update', {
                        position: seek,
                        duration: duration,
                        percentage: percentage
                    });
                }
            }
        }, 100);
    },
    
    stopProgressTracking() {
        if (this._state.progressInterval) {
            clearInterval(this._state.progressInterval);
            this._state.progressInterval = null;
        }
    },
    
    setupProgressBar() {
        const { trackLine } = this._elements;
        if (!trackLine) return;
        
        trackLine.addEventListener('click', (e) => this.handleProgressClick(e));
        
        trackLine.addEventListener('mousedown', (e) => {
            this._state.isDraggingProgress = true;
            this.handleProgressDrag(e);
        });
        
        trackLine.addEventListener('touchstart', (e) => {
            this._state.isDraggingProgress = true;
            this.handleProgressDrag(e);
            e.preventDefault();
        });
        
        window.addEventListener('mousemove', (e) => {
            if (this._state.isDraggingProgress) this.handleProgressDrag(e);
        });
        
        window.addEventListener('touchmove', (e) => {
            if (this._state.isDraggingProgress && e.touches[0]) {
                this.handleProgressDrag(e);
                e.preventDefault();
            }
        });
        
        window.addEventListener('mouseup', () => this._state.isDraggingProgress = false);
        window.addEventListener('touchend', () => this._state.isDraggingProgress = false);
    },
    
    handleProgressClick(e) {
        this._state.eventBus.emit('sound:play', { sound: 'click' });
        
        const rect = this._elements.trackLine.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percentage = Math.min(100, Math.max(0, (x / rect.width) * 100));
        
        if (this._state.audioInstance) {
            const duration = this._state.audioInstance.duration();
            const seekTo = (percentage / 100) * duration;
            this._state.audioInstance.seek(seekTo);
            this.updateProgress(percentage, seekTo);
            
            this._state.eventBus.emit('track:seeked', {
                position: seekTo,
                percentage: percentage
            });
        }
        
        this.showToast(`⏩ ${Math.round(percentage)}%`);
    },
    
    handleProgressDrag(e) {
        const rect = this._elements.trackLine.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const x = clientX - rect.left;
        const percentage = Math.min(100, Math.max(0, (x / rect.width) * 100));
        
        this.updateProgress(percentage);
        
        if (!this._state.isDraggingProgress && this._state.audioInstance) {
            const duration = this._state.audioInstance.duration();
            const seekTo = (percentage / 100) * duration;
            this._state.audioInstance.seek(seekTo);
        }
    },
    
    updateProgress(percentage, currentSeconds = null) {
        const { trackFill, trackHandle, currentTime } = this._elements;
        
        if (trackFill) trackFill.style.width = percentage + '%';
        if (trackHandle) trackHandle.style.left = percentage + '%';
        
        if (currentTime) {
            if (currentSeconds !== null) {
                currentTime.textContent = this.formatTime(currentSeconds);
            } else {
                const totalSeconds = this._state.audioInstance ? 
                    this._state.audioInstance.duration() : this._state.currentTrackDuration;
                const seconds = Math.floor((percentage / 100) * totalSeconds);
                currentTime.textContent = this.formatTime(seconds);
            }
        }
    },
    
    resetProgress() {
        this.updateProgress(0, 0);
    },
    
    // =========================================
    // GESTION DU VOLUME
    // =========================================
    
    setupVolumeControl() {
        const { volumeSlider } = this._elements;
        if (!volumeSlider) return;
        
        volumeSlider.addEventListener('click', (e) => this.handleVolumeClick(e));
        
        volumeSlider.addEventListener('mousedown', (e) => {
            this._state.isDraggingVolume = true;
            this.handleVolumeDrag(e);
        });
        
        volumeSlider.addEventListener('touchstart', (e) => {
            this._state.isDraggingVolume = true;
            this.handleVolumeDrag(e);
            e.preventDefault();
        });
        
        window.addEventListener('mousemove', (e) => {
            if (this._state.isDraggingVolume) this.handleVolumeDrag(e);
        });
        
        window.addEventListener('touchmove', (e) => {
            if (this._state.isDraggingVolume && e.touches[0]) {
                this.handleVolumeDrag(e);
                e.preventDefault();
            }
        });
        
        window.addEventListener('mouseup', () => this._state.isDraggingVolume = false);
        window.addEventListener('touchend', () => this._state.isDraggingVolume = false);
    },
    
    handleVolumeClick(e) {
        this._state.eventBus.emit('sound:play', { sound: 'click' });
        
        const rect = this._elements.volumeSlider.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const percentage = Math.min(100, Math.max(0, (x / rect.width) * 100));
        
        this.setVolume(percentage);
        this.showToast(`Volume: ${Math.round(percentage)}%`);
    },
    
    handleVolumeDrag(e) {
        e.preventDefault();
        
        const rect = this._elements.volumeSlider.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
        const percentage = (x / rect.width) * 100;
        
        this._state.currentVolume = percentage;
        this.updateVolumeDisplay();
        
        this._state.eventBus.emit('volume:changed', {
            volume: percentage,
            source: 'drag'
        });
    },
    
    toggleMute() {
        this._state.eventBus.emit('sound:play', { sound: 'click' });
        
        if (this._state.currentVolume === 0) {
            this.setVolume(this._state.previousVolume || 70);
            this.showToast('🔊 Son activé');
        } else {
            this._state.previousVolume = this._state.currentVolume;
            this.setVolume(0);
            this.showToast('🔇 Son coupé');
        }
    },
    
    updateVolumeDisplay() {
        const { volumeFill, volumeHandle, volumePercent, volumeIcon } = this._elements;
        const volume = this._state.currentVolume;
        
        if (volumeFill) volumeFill.style.width = volume + '%';
        if (volumeHandle) volumeHandle.style.left = volume + '%';
        if (volumePercent) volumePercent.textContent = Math.round(volume) + '%';
        
        if (volumeIcon) {
            volumeIcon.classList.remove('bi-volume-up', 'bi-volume-down', 'bi-volume-mute');
            if (volume === 0) {
                volumeIcon.classList.add('bi-volume-mute');
            } else if (volume < 50) {
                volumeIcon.classList.add('bi-volume-down');
            } else {
                volumeIcon.classList.add('bi-volume-up');
            }
        }
    },
    
    // =========================================
    // GESTION DES FAVORIS
    // =========================================
    
    loadFavorites() {
        try {
            const saved = localStorage.getItem('favorites');
            this._state.favorites = new Set(saved ? JSON.parse(saved) : []);
        } catch (e) {
            console.warn('🎮 Erreur chargement favoris', e);
            this._state.favorites = new Set();
        }
    },
    
    toggleFavorite() {
        this.animateButton(this._elements.favoriteBtn);
        
        const currentTrack = this._elements.miniTitle?.textContent || '';
        
        if (this._state.favorites.has(currentTrack)) {
            this._state.favorites.delete(currentTrack);
            this.updateFavoriteButton(false);
            this.showToast('❤️ Retiré des favoris');
            
            this._state.eventBus.emit('favorite:removed', {
                track: currentTrack
            });
        } else {
            this._state.favorites.add(currentTrack);
            this.updateFavoriteButton(true);
            this.showToast('❤️ Ajouté aux favoris');
            
            this._state.eventBus.emit('favorite:added', {
                track: currentTrack,
                artist: this._elements.miniArtist?.textContent
            });
        }
        
        localStorage.setItem('favorites', JSON.stringify(Array.from(this._state.favorites)));
        
        this._state.eventBus.emit('favorites:updated', {
            count: this._state.favorites.size,
            favorites: Array.from(this._state.favorites)
        });
    },
    
    updateFavoriteButton(isFavorite) {
        if (!this._elements.favoriteBtn) return;
        
        if (isFavorite) {
            this._elements.favoriteBtn.classList.add('active');
            this._elements.favoriteBtn.style.color = '#ff3b30';
        } else {
            this._elements.favoriteBtn.classList.remove('active');
            this._elements.favoriteBtn.style.color = '';
        }
    },
    
    // =========================================
    // GESTION DES MODES DE RÉPÉTITION
    // =========================================
    
    cycleRepeat() {
        this.animateButton(this._elements.repeatBtn);
        
        const modes = ['off', 'all', 'one'];
        const messages = {
            'off': '▶️ Répétition désactivée',
            'all': '🔁 Répéter toute la playlist',
            'one': '🔂 Répéter ce morceau'
        };
        
        const currentIndex = modes.indexOf(this._state.repeatMode);
        const nextIndex = (currentIndex + 1) % modes.length;
        this._state.repeatMode = modes[nextIndex];
        
        this.updateRepeatButton();
        localStorage.setItem('repeatMode', this._state.repeatMode);
        this.showToast(messages[this._state.repeatMode]);
        
        this._state.eventBus.emit('repeat:changed', {
            mode: this._state.repeatMode
        });
    },
    
    updateRepeatButton() {
        const { repeatBtn } = this._elements;
        if (!repeatBtn) return;
        
        repeatBtn.classList.remove('active', 'one');
        
        if (this._state.repeatMode === 'all') {
            repeatBtn.classList.add('active');
        } else if (this._state.repeatMode === 'one') {
            repeatBtn.classList.add('active', 'one');
        }
    },
    
    // =========================================
    // GESTION DU MODE ALÉATOIRE
    // =========================================
    
    toggleShuffle() {
        this.animateButton(this._elements.shuffleBtn);
        this._state.shuffleMode = !this._state.shuffleMode;
        
        this.updateShuffleButton();
        localStorage.setItem('shuffleMode', this._state.shuffleMode);
        
        this.showToast(this._state.shuffleMode ? '🔀 Aléatoire activé' : '▶️ Aléatoire désactivé');
        
        this._state.eventBus.emit('shuffle:changed', {
            enabled: this._state.shuffleMode
        });
    },
    
    updateShuffleButton() {
        if (!this._elements.shuffleBtn) return;
        
        if (this._state.shuffleMode) {
            this._elements.shuffleBtn.classList.add('active');
        } else {
            this._elements.shuffleBtn.classList.remove('active');
        }
    },
    
    // =========================================
    // GESTION DE LA VITESSE
    // =========================================
    
    cycleSpeed() {
        const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
        let speedIndex = speeds.indexOf(this._state.speed);
        if (speedIndex === -1) speedIndex = 2;
        
        speedIndex = (speedIndex + 1) % speeds.length;
        this._state.speed = speeds[speedIndex];
        
        if (this._state.audioInstance) {
            this._state.audioInstance.rate(this._state.speed);
        }
        
        this.animateButton(this._elements.speedBtn);
        this.showToast(`⚡ Vitesse: ${this._state.speed}x`);
        localStorage.setItem('speed', this._state.speed);
        
        this._state.eventBus.emit('speed:changed', {
            speed: this._state.speed
        });
    },
    
    // =========================================
    // PLEIN ÉCRAN
    // =========================================
    
    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    },
    
    // =========================================
    // MISE À JOUR DES INFORMATIONS
    // =========================================
    
    updateTrackInfo(data) {
        if (data.title && this._elements.miniTitle) {
            this._elements.miniTitle.textContent = data.title;
        }
        
        if (data.artist && this._elements.miniArtist) {
            this._elements.miniArtist.textContent = data.artist;
        }
        
        if (data.cover && this._elements.miniImg) {
            this._elements.miniImg.src = data.cover;
        }
        
        if (data.duration && this._elements.totalTime) {
            this._elements.totalTime.textContent = this.formatTime(data.duration);
            this._state.currentTrackDuration = data.duration;
        }
        
        // Mettre à jour le bouton favori
        const currentTrack = data.title || this._elements.miniTitle?.textContent || '';
        this.updateFavoriteButton(this._state.favorites.has(currentTrack));
    },
    
    // =========================================
    // RESTAURATION DE L'ÉTAT
    // =========================================
    
    restoreState() {
        // Volume
        const savedVolume = localStorage.getItem('volume');
        if (savedVolume) {
            this._state.currentVolume = parseInt(savedVolume);
            this._state.previousVolume = this._state.currentVolume;
            this.updateVolumeDisplay();
        }
        
        // Mode répétition
        const savedRepeat = localStorage.getItem('repeatMode');
        if (savedRepeat) {
            this._state.repeatMode = savedRepeat;
            this.updateRepeatButton();
        }
        
        // Mode aléatoire
        const savedShuffle = localStorage.getItem('shuffleMode');
        if (savedShuffle) {
            this._state.shuffleMode = savedShuffle === 'true';
            this.updateShuffleButton();
        }
        
        // Vitesse
        const savedSpeed = localStorage.getItem('speed');
        if (savedSpeed) {
            this._state.speed = parseFloat(savedSpeed);
        }
        
        // Mettre à jour le bouton favori pour le morceau actuel
        const currentTrack = this._elements.miniTitle?.textContent || '';
        this.updateFavoriteButton(this._state.favorites.has(currentTrack));
    },
    
    // =========================================
    // UTILITAIRES
    // =========================================
    
    animateButton(btn) {
        if (btn && window.gsap) {
            window.gsap.to(btn, {
                scale: 0.8,
                duration: 0.1,
                yoyo: true,
                repeat: 1
            });
        }
    },
    
    showToast(message) {
        const { contextToast, toastMessage } = this._elements;
        if (contextToast && toastMessage) {
            toastMessage.textContent = message;
            contextToast.style.display = 'block';
            setTimeout(() => {
                contextToast.style.display = 'none';
            }, 2000);
        }
        
        // Émettre un événement pour les notifications système
        this._state.eventBus.emit('notification:show', {
            message: message,
            source: 'playerControls'
        });
    },
    
    formatTime(seconds) {
        if (isNaN(seconds) || seconds === Infinity) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    },
    
    updatePlayButton() {
        const { playBtn, stopBtn } = this._elements;
        if (!playBtn) return;
        
        if (this._state.isPlaying) {
            playBtn.classList.remove('bi-play-circle');
            playBtn.classList.add('bi-pause-circle');
            if (stopBtn) stopBtn.style.display = 'inline-block';
        } else {
            playBtn.classList.remove('bi-pause-circle');
            playBtn.classList.add('bi-play-circle');
            
            if (stopBtn) {
                stopBtn.style.display = this._state.activeSource ? 'inline-block' : 'none';
            }
        }
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    
    destroy() {
        console.log('🎮 PlayerControls: Nettoyage...');
        
        if (this._state.progressInterval) {
            clearInterval(this._state.progressInterval);
        }
        
        if (this._state.audioInstance) {
            this._state.audioInstance.stop();
            this._state.audioInstance = null;
        }
        
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.playerControls = PlayerControls;

console.log('🎮 PlayerControls: Module enregistré');