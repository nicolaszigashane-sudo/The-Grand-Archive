/**
 * THE GRAND ARCHIVE - Gallery Engine 3D Module
 * Version 3.1.0 - Architecture Sandbox avec contrôle de visibilité
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gérer la galerie 3D, swipe infini, chargement réel des albums
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const GalleryEngine = {
    // Identité du module
    name: 'gallery',
    dependencies: ['sound', 'offline', 'itunes', 'lastfm', 'ui'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        // Albums chargés
        albums: [],
        currentIndex: 0,
        totalAlbums: 0,
        isAnimating: false,
        isLoading: false,
        
        // Configuration 3D
        radius: 350,
        arcAngle: 120, // degrés
        itemWidth: 220,
        
        // Swipe
        touchStartX: 0,
        touchEndX: 0,
        minSwipeDistance: 50,
        isDragging: false,
        
        // Pagination
        currentPage: 1,
        hasMore: true,
        isLoadingMore: false,
        
        // Cache
        loadedCovers: new Set(),
        
        // Statistiques
        stats: {
            totalLoaded: 0,
            totalSwipes: 0,
            lastUpdate: null
        },
        
        // Gestion des promesses
        pendingRequests: new Map(),
        nextRequestId: 0,
        
        // Sons
        lastSoundTime: 0,
        soundInterval: 80,
        
        // Visibilité
        isActive: true,
    },
    
    // Éléments DOM (cachés)
    _elements: {
        container: null,
        swipeZone: null,
        titleEl: null,
        artistEl: null,
    },
    
    // Référence aux modules utilitaires
    _ui: null,
    
    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('🎨 GalleryEngine: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Référence au module UI pour ses helpers
        this._ui = window.modules?.ui;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Configurer les événements de swipe
        this.setupSwipeEvents();
        
        // Charger les premiers albums
        await this.loadAlbums('pop', 20);
        
        // Configurer l'intersection observer pour l'infini
        this.setupInfiniteScroll();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ GalleryEngine prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            container: document.getElementById('album-container'),
            swipeZone: document.getElementById('swipe-zone'),
            titleEl: document.getElementById('current-title'),
            artistEl: document.getElementById('current-artist'),
        };
    },
    
    subscribeToEvents() {
        // Écouter les réponses des modules externes
        this._state.eventBus.on('itunes:search-result', (detail) => this._handleItunesResponse(detail));
        this._state.eventBus.on('lastfm:artist-info-result', (detail) => this._handleLastfmResponse(detail));
        this._state.eventBus.on('lastfm:similar-tracks-result', (detail) => this._handleLastfmResponse(detail));
        this._state.eventBus.on('offline:image-cached', (detail) => {});
        
        // Navigation via événements
        this._state.eventBus.on('gallery:next', () => this.nextAlbum());
        this._state.eventBus.on('gallery:previous', () => this.previousAlbum());
        this._state.eventBus.on('gallery:select', (detail) => this.selectAlbum(detail.index));
        this._state.eventBus.on('gallery:search', async (detail) => {
            const results = await this.searchAlbums(detail.query);
            this._state.eventBus.emit('gallery:search-result', { query: detail.query, results });
        });
        
        // *** NOUVEAU : Contrôle de la galerie par la navigation ***
        this._state.eventBus.on('gallery:activate', () => {
            this.activate();
        });
        
        this._state.eventBus.on('gallery:deactivate', () => {
            this.deactivate();
        });
        
        // *** NOUVEAU : Définir le morceau courant depuis browse ***
        this._state.eventBus.on('gallery:set-current-track', (detail) => {
            this.setCurrentTrack(detail.track);
        });
    },
    
    // =========================================
    // NOUVELLES MÉTHODES POUR LA VISIBILITÉ
    // =========================================
    
    /**
     * Active la galerie (quand on revient sur listen)
     */
    activate() {
        console.log('🎨 GalleryEngine: Activation');
        this._state.isActive = true;
        
        // Réafficher le conteneur si nécessaire
        const stageCenter = document.querySelector('.stage-center');
        if (stageCenter) {
            stageCenter.style.display = 'block';
        }
        
        // Mettre à jour les positions
        this.updatePositions();
    },
    
    /**
     * Désactive la galerie (quand on quitte listen)
     */
    deactivate() {
        console.log('🎨 GalleryEngine: Désactivation');
        this._state.isActive = false;
        
        // Optionnel : on peut cacher le conteneur, mais c'est déjà géré par navigation
        // On garde juste l'état interne
    },
    
    /**
     * Définit le morceau courant (utilisé quand on clique sur un morceau depuis browse)
     */
    setCurrentTrack(track) {
        console.log('🎨 GalleryEngine: Définition du morceau courant', track);
        
        // Mettre à jour les titres
        if (this._elements.titleEl) {
            this._elements.titleEl.textContent = track.name || track.title || 'Titre inconnu';
        }
        if (this._elements.artistEl) {
            this._elements.artistEl.textContent = track.artist || 'Artiste inconnu';
        }
        
        // Optionnel : ajouter le morceau à la galerie si ce n'est pas déjà fait
        // Pour l'instant, on ne modifie pas la galerie, on se contente de mettre à jour les titres
        
        // Émettre un événement pour informer les autres modules
        this._state.eventBus.emit('track:changed', { track });
    },
    
    // =========================================
    // CHARGEMENT DES ALBUMS (via événements)
    // =========================================
    async loadAlbums(genre = 'pop', limit = 20, page = 1) {
        if (this._state.isLoadingMore) return;
        
        this._state.isLoadingMore = true;
        
        try {
            console.log(`📀 Chargement des albums: ${genre} (page ${page})`);
            
            let albums = [];
            
            // Essayer d'abord iTunes
            const itunesResult = await this._requestItunesSearch(genre, limit);
            if (itunesResult?.results) {
                albums = itunesResult.results.map(track => ({
                    id: track.id || `itunes_${Date.now()}_${Math.random()}`,
                    title: track.name || 'Titre inconnu',
                    artist: track.artist || 'Artiste inconnu',
                    cover: track.cover || track.coverSmall || 'backgrounds/default-cover.jpg',
                    source: 'itunes'
                }));
            }
            
            // Si pas de résultats, essayer Last.fm
            if (albums.length === 0) {
                const lastfmResult = await this._requestLastfmTracksByTag(genre, limit, page);
                if (lastfmResult?.tracks) {
                    albums = lastfmResult.tracks.map(track => ({
                        id: track.url || `lastfm_${Date.now()}_${Math.random()}`,
                        title: track.name || 'Titre inconnu',
                        artist: track.artist || 'Artiste inconnu',
                        cover: track.image || 'backgrounds/default-cover.jpg',
                        source: 'lastfm'
                    }));
                }
            }
            
            // Fallback local
            if (albums.length === 0) {
                albums = this._getLocalAlbums(genre, limit);
            }
            
            // Ajouter les albums à la collection
            const startIndex = this._state.albums.length;
            this._state.albums.push(...albums);
            this._state.totalAlbums = this._state.albums.length;
            
            // Mettre à jour la galerie seulement si elle est active
            if (this._state.isActive) {
                if (page === 1) {
                    this.renderGallery();
                } else {
                    this.appendToGallery(albums, startIndex);
                }
            }
            
            // Précharger les covers
            this.prefetchCovers(albums);
            
            this._state.stats.totalLoaded += albums.length;
            this._state.stats.lastUpdate = new Date().toISOString();
            
            return albums;
        } catch (error) {
            console.error('❌ Erreur chargement albums:', error);
            return [];
        } finally {
            this._state.isLoadingMore = false;
        }
    },
    
    _requestItunesSearch(term, limit) {
        return new Promise((resolve) => {
            const callbackId = `gallery_itunes_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('itunes:search', {
                term,
                limit,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 5000);
        });
    },
    
    _requestLastfmTracksByTag(tag, limit, page) {
        return new Promise((resolve) => {
            const callbackId = `gallery_lastfm_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('lastfm:get-tracks-by-tag', {
                tag,
                limit,
                page,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 5000);
        });
    },
    
    _handleItunesResponse(detail) {
        const { callbackId, results } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ results });
        }
    },
    
    _handleLastfmResponse(detail) {
        const { callbackId, tracks } = detail;
        const resolve = this._state.pendingRequests.get(callbackId);
        if (resolve) {
            this._state.pendingRequests.delete(callbackId);
            resolve({ tracks });
        }
    },
    
    _getLocalAlbums(genre, limit) {
        const localAlbums = {
            pop: [
                { id: 1, title: 'Midnight Vibes', artist: 'Luna Ray', cover: 'backgrounds/default-cover.jpg' },
                { id: 2, title: 'Electric Dreams', artist: 'Neon Pulse', cover: 'backgrounds/default-cover.jpg' },
                { id: 3, title: 'Acoustic Sessions', artist: 'The Wanderers', cover: 'backgrounds/default-cover.jpg' },
                { id: 4, title: 'Urban Flow', artist: 'Metro', cover: 'backgrounds/default-cover.jpg' },
                { id: 5, title: 'Crystal Waters', artist: 'Deep Blue', cover: 'backgrounds/default-cover.jpg' }
            ],
            rock: [
                { id: 6, title: 'Thunder Road', artist: 'The Rebels', cover: 'backgrounds/default-cover.jpg' },
                { id: 7, title: 'Electric Guitar', artist: 'Jimmy Page', cover: 'backgrounds/default-cover.jpg' }
            ],
            jazz: [
                { id: 8, title: 'Smooth Jazz', artist: 'Miles Davis', cover: 'backgrounds/default-cover.jpg' }
            ]
        };
        return (localAlbums[genre] || localAlbums.pop).slice(0, limit);
    },
    
    // =========================================
    // RENDU DE LA GALERIE
    // =========================================
    renderGallery() {
        const container = this._elements.container;
        if (!container) return;
        
        container.innerHTML = '';
        
        this._state.albums.forEach((album, index) => {
            const item = this.createAlbumElement(album, index);
            container.appendChild(item);
        });
        
        this.updatePositions();
        this.setActiveAlbum(this._state.currentIndex);
    },
    
    appendToGallery(albums, startIndex) {
        const container = this._elements.container;
        if (!container) return;
        
        albums.forEach((album, offset) => {
            const index = startIndex + offset;
            const item = this.createAlbumElement(album, index);
            container.appendChild(item);
        });
        
        this.updatePositions();
    },
    
    createAlbumElement(album, index) {
        const div = document.createElement('div');
        div.className = 'album-item';
        div.dataset.index = index;
        div.dataset.id = album.id;
        
        const img = document.createElement('img');
        img.src = album.cover || 'backgrounds/default-cover.jpg';
        img.alt = album.title;
        img.loading = 'lazy';
        
        img.onerror = () => {
            img.src = 'backgrounds/default-cover.jpg';
        };
        
        div.appendChild(img);
        div.title = `${album.title} - ${album.artist}`;
        
        div.addEventListener('click', () => {
            this._playSound();
            this.selectAlbum(index);
        });
        
        return div;
    },
    
    // =========================================
    // POSITIONNEMENT 3D
    // =========================================
    updatePositions() {
        // Ne pas mettre à jour si la galerie n'est pas active
        if (!this._state.isActive) return;
        
        const items = document.querySelectorAll('.album-item');
        const count = items.length;
        
        if (count === 0) return;
        
        items.forEach((item, index) => {
            const relativeIndex = index - this._state.currentIndex;
            const angle = (relativeIndex * 15) * (Math.PI / 180); // 15° entre chaque album
            
            const x = Math.sin(angle) * this._state.radius;
            const z = Math.cos(angle) * this._state.radius - this._state.radius;
            
            const distance = Math.abs(relativeIndex);
            const opacity = Math.max(0.3, 1 - distance * 0.15);
            const scale = Math.max(0.6, 1 - distance * 0.1);
            const rotateY = -angle * (180 / Math.PI) * 0.5;
            
            item.style.transform = `
                translateX(${x}px)
                translateZ(${z}px)
                rotateY(${rotateY}deg)
                scale(${scale})
            `;
            item.style.opacity = opacity;
            item.style.zIndex = 100 - distance;
        });
    },
    
    setActiveAlbum(index) {
        document.querySelectorAll('.album-item').forEach((item, i) => {
            if (i === index) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    },
    
    // =========================================
    // NAVIGATION
    // =========================================
    nextAlbum() {
        if (this._state.isAnimating || !this._state.isActive) return;
        
        this._playSound();
        this._state.stats.totalSwipes++;
        
        let nextIndex = this._state.currentIndex + 1;
        
        if (nextIndex >= this._state.albums.length - 3) {
            this.loadMoreAlbums();
        }
        
        if (nextIndex >= this._state.albums.length) {
            nextIndex = 0;
        }
        
        this.selectAlbum(nextIndex);
    },
    
    previousAlbum() {
        if (this._state.isAnimating || !this._state.isActive) return;
        
        this._playSound();
        this._state.stats.totalSwipes++;
        
        let prevIndex = this._state.currentIndex - 1;
        
        if (prevIndex < 0) {
            prevIndex = this._state.albums.length - 1;
        }
        
        this.selectAlbum(prevIndex);
    },
    
    selectAlbum(index) {
        if (this._state.isAnimating || !this._state.isActive) return;
        
        this._state.isAnimating = true;
        this._state.currentIndex = index;
        
        this.setActiveAlbum(index);
        this.updatePositions();
        
        // Charger les détails de l'album
        this.loadAlbumDetails(this._state.albums[index]);
        
        // Émettre un événement pour que le player joue ce morceau
        const album = this._state.albums[index];
        if (album) {
            this._state.eventBus.emit('player:play-track', { track: album });
        }
        
        setTimeout(() => {
            this._state.isAnimating = false;
        }, 500);
    },
    
    // =========================================
    // SWIPE (TOUCH)
    // =========================================
    setupSwipeEvents() {
        const zone = this._elements.swipeZone;
        if (!zone) return;
        
        zone.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: true });
        zone.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: true });
        zone.addEventListener('touchend', this.handleTouchEnd.bind(this));
        
        zone.addEventListener('mousedown', this.handleMouseDown.bind(this));
        zone.addEventListener('mousemove', this.handleMouseMove.bind(this));
        zone.addEventListener('mouseup', this.handleMouseUp.bind(this));
        zone.addEventListener('mouseleave', this.handleMouseUp.bind(this));
    },
    
    handleTouchStart(e) {
        if (!this._state.isActive) return;
        this._state.touchStartX = e.touches[0].clientX;
        this._state.isDragging = true;
    },
    
    handleTouchMove(e) {
        if (!this._state.isDragging || !this._state.isActive) return;
        this._state.touchEndX = e.touches[0].clientX;
        
        const now = Date.now();
        if (now - this._state.lastSoundTime > 50) {
            this._playSound();
            this._state.lastSoundTime = now;
        }
    },
    
    handleTouchEnd() {
        if (this._state.isDragging) {
            this.handleSwipe();
            this._state.isDragging = false;
        }
    },
    
    handleMouseDown(e) {
        if (!this._state.isActive) return;
        this._state.touchStartX = e.clientX;
        this._state.isDragging = true;
    },
    
    handleMouseMove(e) {
        if (!this._state.isDragging || !this._state.isActive) return;
        this._state.touchEndX = e.clientX;
        
        const now = Date.now();
        if (now - this._state.lastSoundTime > 50) {
            this._playSound();
            this._state.lastSoundTime = now;
        }
    },
    
    handleMouseUp() {
        if (this._state.isDragging) {
            this.handleSwipe();
            this._state.isDragging = false;
        }
    },
    
    handleSwipe() {
        const distance = this._state.touchEndX - this._state.touchStartX;
        
        if (Math.abs(distance) < this._state.minSwipeDistance) return;
        
        this._playSound();
        
        if (distance > 0) {
            this.previousAlbum();
        } else {
            this.nextAlbum();
        }
        
        this._state.touchStartX = 0;
        this._state.touchEndX = 0;
    },
    
    // =========================================
    // CHARGEMENT INFINI
    // =========================================
    setupInfiniteScroll() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && this._state.hasMore && !this._state.isLoadingMore && this._state.isActive) {
                    this.loadMoreAlbums();
                }
            });
        }, {
            root: null,
            rootMargin: '200px',
            threshold: 0.1
        });
        
        const lastItem = document.querySelector('.album-item:last-child');
        if (lastItem) {
            observer.observe(lastItem);
        }
    },
    
    async loadMoreAlbums() {
        if (this._state.isLoadingMore || !this._state.hasMore) return;
        
        this._state.currentPage++;
        
        const genres = ['pop', 'rock', 'jazz', 'electronic', 'hip-hop'];
        const genre = genres[this._state.currentPage % genres.length];
        
        const newAlbums = await this.loadAlbums(genre, 10, this._state.currentPage);
        
        if (newAlbums.length === 0) {
            this._state.hasMore = false;
        }
        
        setTimeout(() => this.setupInfiniteScroll(), 500);
    },
    
    // =========================================
    // CHARGEMENT DES DÉTAILS
    // =========================================
    async loadAlbumDetails(album) {
        if (!album) return;
        
        try {
            console.log(`📖 Chargement détails: ${album.title}`);
            
            if (this._elements.titleEl) this._elements.titleEl.textContent = album.title;
            if (this._elements.artistEl) this._elements.artistEl.textContent = album.artist;
            
            // Chercher plus d'infos avec Last.fm
            if (album.artist) {
                const artistInfo = await this._requestLastfmArtistInfo(album.artist);
                if (artistInfo && artistInfo.summary) {
                    this._state.eventBus.emit('notification:show', {
                        message: artistInfo.summary.substring(0, 100) + '...',
                        type: 'info'
                    });
                }
                
                const similar = await this._requestLastfmSimilarTracks(album.title, album.artist, 5);
                if (similar.length > 0) {
                    console.log('🎵 Morceaux similaires:', similar);
                }
            }
            
            // Mettre en cache l'image
            if (album.cover && album.id) {
                this._state.eventBus.emit('offline:cache-image', {
                    url: album.cover,
                    id: `album_${album.id}`
                });
            }
            
        } catch (error) {
            console.warn('⚠️ Erreur chargement détails:', error);
        }
    },
    
    _requestLastfmArtistInfo(artistName) {
        return new Promise((resolve) => {
            const callbackId = `gallery_artist_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('lastfm:get-artist-info', {
                artistName,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 5000);
        });
    },
    
    _requestLastfmSimilarTracks(track, artist, limit) {
        return new Promise((resolve) => {
            const callbackId = `gallery_similar_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, resolve);
            
            this._state.eventBus.emit('lastfm:get-similar-tracks', {
                track,
                artist,
                limit,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve([]);
                }
            }, 5000);
        });
    },
    
    // =========================================
    // PRÉCHARGEMENT DES COVERS
    // =========================================
    async prefetchCovers(albums) {
        const coverUrls = {};
        
        albums.forEach(album => {
            if (album.cover && !this._state.loadedCovers.has(album.id)) {
                coverUrls[`album_${album.id}`] = album.cover;
                this._state.loadedCovers.add(album.id);
            }
        });
        
        if (Object.keys(coverUrls).length > 0) {
            this._state.eventBus.emit('offline:prefetch-images', { urls: coverUrls });
        }
    },
    
    // =========================================
    // RECHERCHE
    // =========================================
    async searchAlbums(query) {
        if (!query || query.length < 2) return [];
        
        this._state.isLoading = true;
        
        try {
            let results = [];
            
            const itunesResult = await this._requestItunesSearch(query, 30);
            if (itunesResult?.results) {
                results = itunesResult.results.map(track => ({
                    id: track.id || `search_${Date.now()}_${Math.random()}`,
                    title: track.name || track.title || 'Titre inconnu',
                    artist: track.artist || 'Artiste inconnu',
                    cover: track.cover || track.coverSmall || 'backgrounds/default-cover.jpg',
                    source: 'itunes'
                }));
            }
            
            if (results.length === 0) {
                const lastfmResult = await this._requestLastfmTracksByTag(query, 20, 1);
                if (lastfmResult?.tracks) {
                    results = lastfmResult.tracks.map(track => ({
                        id: track.url || `lastfm_${Date.now()}_${Math.random()}`,
                        title: track.name || 'Titre inconnu',
                        artist: track.artist || 'Artiste inconnu',
                        cover: track.image || 'backgrounds/default-cover.jpg',
                        source: 'lastfm'
                    }));
                }
            }
            
            if (results.length > 0) {
                this._state.albums = results;
                this._state.currentIndex = 0;
                this._state.currentPage = 1;
                this._state.hasMore = true;
                
                this.renderGallery();
                this.prefetchCovers(results);
            }
            
            return results;
        } catch (error) {
            console.error('❌ Erreur recherche:', error);
            return [];
        } finally {
            this._state.isLoading = false;
        }
    },
    
    // =========================================
    // UTILITAIRES
    // =========================================
    _playSound() {
        this._state.eventBus.emit('sound:play', { sound: 'click' });
    },
    
    // =========================================
    // API PUBLIQUE (appelable par l'orchestrateur)
    // =========================================
    getCurrentAlbum() {
        return this._state.albums[this._state.currentIndex];
    },
    
    getAlbums() {
        return [...this._state.albums];
    },
    
    getCurrentIndex() {
        return this._state.currentIndex;
    },
    
    getStats() {
        return { ...this._state.stats };
    },
    
    refresh() {
        this._state.albums = [];
        this._state.currentPage = 1;
        this._state.hasMore = true;
        this.loadAlbums('pop', 20);
    },
    
    enableSound() {
        // Le son est géré par le module sound, pas besoin ici
    },
    
    disableSound() {
        // Idem
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🎨 GalleryEngine: Nettoyage...');
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.gallery = GalleryEngine;

console.log('🎨 GalleryEngine: Module enregistré');