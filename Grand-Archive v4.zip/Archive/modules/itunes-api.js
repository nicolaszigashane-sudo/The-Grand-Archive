/**
 * THE GRAND ARCHIVE - iTunes API Module
 * Version 4.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Interface avec l'API iTunes pour les tops, recherches et métadonnées
 * COMPORTEMENT : Pure sandbox - communique par événements pour le cache
 */


const iTunesAPI = {
    // Identité du module
    name: 'itunes',
    dependencies: ['offline'], // Utilise le cache offline via événements
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        // Configuration
        baseURL: 'https://itunes.apple.com',
        rssURL: 'https://rss.applemarketingtools.com/api/v2',
        
        cacheTTL: {
            search: 24 * 60 * 60 * 1000,
            lookup: 24 * 60 * 60 * 1000,
            charts: 30 * 60 * 1000,
            topAlbums: 30 * 60 * 1000,
            topSongs: 30 * 60 * 1000,
            images: 7 * 24 * 60 * 60 * 1000
        },
        
        maxResults: 50,
        concurrentRequests: 4,
        imageBatchSize: 10,
        
        isReady: false,
        requestQueue: [],
        activeRequests: 0,
        imageCache: new Map(), // cache mémoire
        
        stats: {
            totalRequests: 0,
            cachedResponses: 0,
            apiCalls: 0,
            errors: 0,
            imagesLoaded: 0,
            imagesCached: 0
        },
        
        genres: {
            all: 'all',
            pop: 'pop',
            rock: 'rock',
            hiphop: 'hip-hop-rap',
            electronic: 'electronic',
            jazz: 'jazz',
            classical: 'classical'
        },
        
        // Pour les requêtes avec cache via eventBus
        pendingCacheRequests: new Map(),
        nextRequestId: 0
    },
    
    // Éléments DOM (aucun)
    _elements: {},
    
    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('🎵 iTunesAPI: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        // Test de connexion
        const ok = await this.testConnection();
        this._state.isReady = ok;
        
        console.log(`✅ iTunesAPI prêt (${ok ? 'en ligne' : 'hors ligne'})`);
        return this;
    },
    
    subscribeToEvents() {
        // Réponses du cache offline
        this._state.eventBus.on('offline:api-retrieved', (detail) => {
            const { callbackId, data } = detail;
            const pending = this._state.pendingCacheRequests.get(callbackId);
            if (pending) {
                this._state.pendingCacheRequests.delete(callbackId);
                pending.resolve(data);
            }
        });
        
        // Écouter les demandes de préchargement (optionnel)
        this._state.eventBus.on('preload:request', () => {
            // Peut précharger des données si nécessaire
        });
    },
    
    // =========================================
    // TEST DE CONNEXION
    // =========================================
    async testConnection() {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3000);
        
        try {
            const response = await fetch(`${this._state.rssURL}/fr/music/top-songs/all/1/explicit.json`, {
                signal: controller.signal
            });
            clearTimeout(timeout);
            return response.ok;
        } catch {
            clearTimeout(timeout);
            return false;
        }
    },
    
    // =========================================
    // GESTION DU CACHE VIA ÉVÉNEMENTS
    // =========================================
    async _getCached(key) {
        return new Promise((resolve, reject) => {
            const callbackId = `itunes_${this._state.nextRequestId++}`;
            this._state.pendingCacheRequests.set(callbackId, { resolve, reject });
            
            this._state.eventBus.emit('offline:get-api', {
                endpoint: key,
                ignoreTTL: true,
                callbackId
            });
            
            // Timeout
            setTimeout(() => {
                if (this._state.pendingCacheRequests.has(callbackId)) {
                    this._state.pendingCacheRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    async _cacheResponse(key, data) {
        this._state.eventBus.emit('offline:cache-api', {
            endpoint: key,
            data: data,
            ttl: this._state.cacheTTL.charts // Par défaut
        });
    },
    
    // =========================================
    // GESTIONNAIRE DE REQUÊTES
    // =========================================
    _requestManager: {
        queue: [],
        active: 0,
        
        add: async function(url, options = {}, moduleState) {
            const cacheKey = `itunes_${url}`;
            
            // Vérifier le cache via événements
            const cached = await moduleState._getCached(cacheKey);
            if (cached) {
                moduleState._state.stats.cachedResponses++;
                return cached;
            }
            
            // Mettre en file d'attente
            return new Promise((resolve, reject) => {
                this.queue.push({ url, options, resolve, reject, moduleState });
                this.process(moduleState);
            });
        },
        
        process: async function(moduleState) {
            if (this.active >= moduleState._state.concurrentRequests || this.queue.length === 0) return;
            
            this.active++;
            const { url, options, resolve, reject, moduleState: ms } = this.queue.shift();
            
            try {
                const result = await this.executeRequest(url, options, ms);
                resolve(result);
            } catch (error) {
                reject(error);
            } finally {
                this.active--;
                this.process(ms);
            }
        },
        
        executeRequest: async function(url, options, moduleState) {
            moduleState._state.stats.totalRequests++;
            moduleState._state.stats.apiCalls++;
            
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 5000);
            
            try {
                const response = await fetch(url, {
                    ...options,
                    signal: controller.signal,
                    headers: {
                        'Accept-Encoding': 'gzip, deflate',
                        'Connection': 'keep-alive'
                    }
                });
                
                clearTimeout(timeout);
                
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                
                const data = await response.json();
                
                // Mettre en cache
                await moduleState._cacheResponse(`itunes_${url}`, data);
                
                return data;
            } catch (error) {
                clearTimeout(timeout);
                moduleState._state.stats.errors++;
                throw error;
            }
        }
    },
    
    // =========================================
    // GESTIONNAIRE D'IMAGES
    // =========================================
    _imageLoader: {
        loading: new Map(),
        queue: [],
        active: 0,
        maxConcurrent: 3,
        
        load: async function(url, id, priority, moduleState) {
            // Cache mémoire
            if (moduleState._state.imageCache.has(url)) {
                moduleState._state.stats.imagesCached++;
                return moduleState._state.imageCache.get(url);
            }
            
            // Cache disque via événements
            const cacheKey = `cover_${id}`;
            const cached = await moduleState._getCachedImage(cacheKey);
            if (cached) {
                moduleState._state.imageCache.set(url, cached);
                moduleState._state.stats.imagesCached++;
                return cached;
            }
            
            // Mise en file d'attente
            return new Promise((resolve, reject) => {
                const loadItem = { url, id, resolve, reject, priority, moduleState };
                
                if (priority === 'high') {
                    this.queue.unshift(loadItem);
                } else {
                    this.queue.push(loadItem);
                }
                
                this.process(moduleState);
            });
        },
        
        process: async function(moduleState) {
            if (this.active >= this.maxConcurrent || this.queue.length === 0) return;
            
            this.active++;
            const { url, id, resolve, reject, moduleState: ms } = this.queue.shift();
            
            try {
                const result = await this.loadImage(url, id, ms);
                resolve(result);
            } catch (error) {
                reject(error);
            } finally {
                this.active--;
                this.process(ms);
            }
        },
        
        loadImage: async function(url, id, moduleState) {
            return new Promise((resolve, reject) => {
                const img = new Image();
                
                img.onload = async () => {
                    try {
                        const canvas = document.createElement('canvas');
                        canvas.width = img.width;
                        canvas.height = img.height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0);
                        
                        const base64 = canvas.toDataURL('image/jpeg', 0.8);
                        
                        moduleState._state.imageCache.set(url, base64);
                        moduleState._state.stats.imagesLoaded++;
                        
                        // Mettre en cache disque via événement
                        moduleState._state.eventBus.emit('offline:cache-image', {
                            url: url,
                            id: `cover_${id}`
                        });
                        
                        resolve(base64);
                    } catch (e) {
                        console.warn('⚠️ Erreur conversion image:', e);
                        resolve(url); // Fallback à l'URL
                    }
                };
                
                img.onerror = () => {
                    console.warn(`⚠️ Échec chargement image: ${url}`);
                    resolve(null);
                };
                
                img.crossOrigin = 'anonymous';
                img.src = url;
            });
        },
        
        // Helper pour récupérer une image depuis le cache offline
        _getCachedImage: async function(cacheId, moduleState) {
            return new Promise((resolve) => {
                const callbackId = `img_${moduleState._state.nextRequestId++}`;
                moduleState._state.pendingCacheRequests.set(callbackId, { resolve, reject: resolve });
                
                moduleState._state.eventBus.emit('offline:get-image', {
                    id: cacheId,
                    callbackId
                });
                
                setTimeout(() => {
                    if (moduleState._state.pendingCacheRequests.has(callbackId)) {
                        moduleState._state.pendingCacheRequests.delete(callbackId);
                        resolve(null);
                    }
                }, 2000);
            });
        }
    },
    
    // =========================================
    // MÉTHODES PRINCIPALES
    // =========================================
    async getTopSongs(country = 'fr', genre = 'all', limit = 20) {
        const genreCode = this._state.genres[genre] || 'all';
        const url = `${this._state.rssURL}/${country}/music/top-songs/${genreCode}/${Math.min(limit, 50)}/explicit.json`;
        
        console.log('🎵 [iTunes] Chargement top songs:', url);
        
        try {
            const data = await this._requestManager.add(url, {}, this);
            
            if (!data.feed?.results) {
                return { songs: [] };
            }
            
            const songs = data.feed.results.map(item => this._formatRSSResult(item));
            const validSongs = songs.filter(song => song.previewUrl);
            
            // Chargement intelligent des covers
            if (validSongs.length > 0) {
                this._loadCoversIntelligently(validSongs);
            }
            
            return { songs: validSongs, total: validSongs.length };
        } catch (error) {
            console.error('❌ [iTunes] Erreur tops:', error);
            return { songs: [] };
        }
    },
    
    async search(params) {
        const { term, country = 'fr', limit = 15 } = params;
        
        if (!term?.trim()) return { results: [] };
        
        const url = `${this._state.baseURL}/search?term=${encodeURIComponent(term)}&country=${country}&media=music&limit=${Math.min(limit, 30)}`;
        
        try {
            const data = await this._requestManager.add(url, {}, this);
            
            if (!data.results) return { results: [] };
            
            const results = data.results.map(item => this._formatTrackResult(item));
            const validResults = results.filter(r => r.previewUrl);
            
            if (validResults.length > 0) {
                this._loadCoversIntelligently(validResults);
            }
            
            return { results: validResults, total: validResults.length };
        } catch (error) {
            console.error('❌ [iTunes] Erreur recherche:', error);
            return { results: [] };
        }
    },
    
    async getQuickTop() {
        // Utiliser le cache via _getCached
        const cacheKey = 'itunes_quick_top';
        const cached = await this._getCached(cacheKey);
        if (cached) return cached;
        
        const result = await this.getTopSongs('fr', 'all', 10);
        this._cacheResponse(cacheKey, result);
        return result;
    },
    
    // Chargement d'image
    async loadCover(url, id) {
        return this._imageLoader.load(url, id, 'normal', this);
    },
    
    // Préchargement intelligent
    _loadCoversIntelligently(songs) {
        if (!songs || songs.length === 0) return;
        
        const visible = songs.slice(0, 6);
        visible.forEach(song => {
            if (song.cover) {
                this._imageLoader.load(song.cover, song.id, 'high', this).catch(() => {});
            }
        });
        
        setTimeout(() => {
            songs.slice(6).forEach(song => {
                if (song.cover) {
                    this._imageLoader.load(song.cover, song.id, 'low', this).catch(() => {});
                }
            });
        }, 500);
    },
    
    // Formatage
    _formatRSSResult(item) {
        let coverUrl = item.artworkUrl100;
        if (coverUrl) {
            coverUrl = coverUrl.replace('100x100', '300x300');
        }
        return {
            id: item.id,
            name: item.name,
            artist: item.artistName,
            cover: coverUrl || 'backgrounds/default-cover.jpg',
            coverSmall: item.artworkUrl100 || 'backgrounds/default-cover.jpg',
            previewUrl: item.previewUrl,
            duration: item.durationMillis
        };
    },
    
    _formatTrackResult(item) {
        let coverUrl = item.artworkUrl100;
        if (coverUrl) {
            coverUrl = coverUrl.replace('100x100', '300x300');
        }
        return {
            id: item.trackId || item.collectionId,
            name: item.trackName || item.collectionName,
            artist: item.artistName,
            album: item.collectionName,
            cover: coverUrl || 'backgrounds/default-cover.jpg',
            coverSmall: item.artworkUrl100 || 'backgrounds/default-cover.jpg',
            previewUrl: item.previewUrl,
            duration: item.trackTimeMillis
        };
    },
    
    // =========================================
    // API PUBLIQUE (pour compatibilité)
    // =========================================
    isReady() {
        return this._state.isReady;
    },
    
    getStats() {
        return { ...this._state.stats };
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🎵 iTunesAPI: Nettoyage...');
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.itunes = iTunesAPI;

console.log('🎵 iTunesAPI: Module enregistré');