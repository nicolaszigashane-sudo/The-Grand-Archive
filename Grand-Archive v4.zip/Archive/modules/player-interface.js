/**
 * THE GRAND ARCHIVE - Player Interface Module
 * Version 4.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Interface principale du player
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const PlayerInterface = {
    // Identité du module
    name: 'playerInterface',
    dependencies: ['ui'], // Peut avoir besoin de l'UI core
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        isImmersionActive: false,
        currentTheme: 'default',
        transparency: 85, // pourcentage
    },
    
    // Éléments DOM (cachés)
    _elements: {
        immersionBtn: null,
        immersionContainer: null,
        exitBtn: null,
        video: null,
        transparencySlider: null,
        transparencyValue: null,
        themeSelect: null,
        iceElements: null,
        playBtn: null,
        trackFill: null,
        swipeFill: null,
        // Éléments des paramètres à styliser
        soundSelect: null,
        soundVolume: null,
        testSoundBtn: null,
        importVideoBtn: null,
        clearVideosBtn: null,
        clearCacheBtn: null,
        showAboutBtn: null,
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🎛️ PlayerInterface: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Initialiser les composants
        this.initImmersionMode();
        this.initTransparencyControl();
        this.initThemeSelector();
        this.initNetworkManager();
        
        // Restaurer l'état sauvegardé
        this.restoreState();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ PlayerInterface prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            immersionBtn: document.getElementById('immersion-btn'),
            immersionContainer: document.getElementById('immersion-container'),
            exitBtn: document.getElementById('immersion-exit'),
            video: document.getElementById('immersion-video'),
            transparencySlider: document.getElementById('transparency-slider'),
            transparencyValue: document.getElementById('transparency-value'),
            themeSelect: document.getElementById('theme-select'),
            playBtn: document.getElementById('play-btn'),
            trackFill: document.getElementById('track-progress'),
            swipeFill: document.getElementById('swipe-progress-fill'),
            // Éléments des paramètres
            soundSelect: document.getElementById('sound-select'),
            soundVolume: document.getElementById('sound-volume'),
            testSoundBtn: document.getElementById('test-sound-btn'),
            importVideoBtn: document.getElementById('import-video-btn'),
            clearVideosBtn: document.getElementById('clear-videos-btn'),
            clearCacheBtn: document.getElementById('clear-cache-btn'),
            showAboutBtn: document.getElementById('show-about-btn'),
            // Éléments à rendre transparents
            iceElements: document.querySelectorAll('.nav-island, .player-bar, .info-panel, .speed-badge, .sleep-timer')
        };
    },
    
    subscribeToEvents() {
        // Écouter les changements de thème (si un autre module les modifie)
        this._state.eventBus.on('theme:changed', (detail) => {
            if (detail.theme && detail.theme !== this._state.currentTheme) {
                this.applyTheme(detail.theme);
            }
        });
        
        // Écouter les changements de transparence
        this._state.eventBus.on('transparency:changed', (detail) => {
            if (detail.value !== undefined) {
                this.setTransparency(detail.value);
            }
        });
        
        // Écouter les demandes d'activation/désactivation du mode immersion
        this._state.eventBus.on('immersion:activate', () => this.activateImmersion());
        this._state.eventBus.on('immersion:deactivate', () => this.deactivateImmersion());
        this._state.eventBus.on('immersion:toggle', () => this.toggleImmersion());
        
        // Écouter les changements de réseau (gérés en interne)
    },
    
    // =========================================
    // MODE IMMERSION
    // =========================================
    initImmersionMode() {
        const { immersionBtn, immersionContainer, exitBtn, video } = this._elements;
        if (!immersionBtn || !immersionContainer) return;
        
        immersionBtn.addEventListener('click', () => {
            this._state.eventBus.emit('sound:play', { sound: 'click' });
            this.activateImmersion();
        });
        
        if (exitBtn) {
            exitBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                this.deactivateImmersion();
            });
        }
        
        // Touche Echap pour quitter
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this._state.isImmersionActive && exitBtn) {
                this.deactivateImmersion();
            }
        });
    },
    
    activateImmersion() {
        const { immersionContainer, video } = this._elements;
        if (!immersionContainer) return;
        
        document.body.classList.add('immersion-mode');
        immersionContainer.style.display = 'flex';
        this._state.isImmersionActive = true;
        
        // Animation
        if (window.gsap) {
            window.gsap.from(immersionContainer, { opacity: 0, duration: 0.5 });
        }
        
        // Démarrer la vidéo d'immersion (si le module immersion n'est pas chargé)
        this._state.eventBus.emit('immersion:activated', {});
        
        // Utiliser le module immersion s'il existe, sinon fallback vidéo aléatoire
        if (window.modules && window.modules.immersion) {
            // Le module immersion s'occupe de la vidéo
            this._state.eventBus.emit('immersion:start');
        } else if (video) {
            const videos = ['ambient-1.mp4','ambient-2.mp4','ambient-3.mp4','ambient-4.mp4','ambient-5.mp4'];
            video.src = `backgrounds/${videos[Math.floor(Math.random() * videos.length)]}`;
            video.play().catch(() => {});
        }
        
        this._state.eventBus.emit('notification:show', { message: '🌌 Mode immersion activé' });
    },
    
    deactivateImmersion() {
        const { immersionContainer, video } = this._elements;
        if (!immersionContainer) return;
        
        document.body.classList.remove('immersion-mode');
        immersionContainer.style.display = 'none';
        if (video) video.pause();
        this._state.isImmersionActive = false;
        
        this._state.eventBus.emit('immersion:deactivated', {});
        this._state.eventBus.emit('notification:show', { message: '🌌 Mode immersion désactivé' });
    },
    
    toggleImmersion() {
        if (this._state.isImmersionActive) {
            this.deactivateImmersion();
        } else {
            this.activateImmersion();
        }
    },
    
    // =========================================
    // CONTRÔLE DE TRANSPARENCE
    // =========================================
    initTransparencyControl() {
        const slider = this._elements.transparencySlider;
        if (!slider) return;
        
        // Styliser le slider si nécessaire
        slider.style.cssText = `position:relative; width:150px; height:4px; background:rgba(255,255,255,0.2); border-radius:2px; cursor:pointer; touch-action:none;`;
        
        // Créer la barre de remplissage et le curseur
        const fill = document.createElement('div');
        fill.style.cssText = `position:absolute; height:100%; width:${this._state.transparency}%; background:${this.getThemeColor()}; border-radius:2px; pointer-events:none; transition:background 0.3s ease;`;
        
        const handle = document.createElement('div');
        handle.style.cssText = `position:absolute; right:-6px; top:-4px; width:12px; height:12px; background:white; border-radius:50%; box-shadow:0 2px 5px rgba(0,0,0,0.3); pointer-events:none;`;
        
        fill.appendChild(handle);
        slider.appendChild(fill);
        
        // Gestion du drag
        let isDragging = false;
        
        const update = (val) => {
            const percent = Math.min(100, Math.max(0, val));
            this._state.transparency = percent;
            if (this._elements.transparencyValue) {
                this._elements.transparencyValue.textContent = Math.round(percent) + '%';
            }
            fill.style.width = percent + '%';
            
            // Appliquer l'opacité aux éléments
            const opacity = 0.05 + (percent / 100) * 0.25;
            this._elements.iceElements.forEach(el => {
                if (el) el.style.backgroundColor = `rgba(255, 255, 255, ${opacity})`;
            });
            
            // Émettre l'événement
            this._state.eventBus.emit('transparency:changed', { value: percent });
        };
        
        const updateFromEvent = (e) => {
            e.preventDefault();
            const rect = slider.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const x = clientX - rect.left;
            update((x / rect.width) * 100);
        };
        
        slider.addEventListener('mousedown', (e) => { isDragging = true; updateFromEvent(e); });
        window.addEventListener('mousemove', (e) => { if (isDragging) updateFromEvent(e); });
        window.addEventListener('mouseup', () => isDragging = false);
        slider.addEventListener('touchstart', (e) => { isDragging = true; updateFromEvent(e); e.preventDefault(); });
        window.addEventListener('touchmove', (e) => { if (isDragging) { updateFromEvent(e); e.preventDefault(); } });
        window.addEventListener('touchend', () => isDragging = false);
        
        // Initialiser l'affichage
        update(this._state.transparency);
    },
    
    setTransparency(percent) {
        // Mettre à jour le slider si nécessaire (pas besoin car le drag émet déjà)
        // Cette méthode peut être appelée par un événement externe
        const slider = this._elements.transparencySlider;
        if (!slider) return;
        
        const fill = slider.querySelector('div'); // le premier div est la fill
        if (fill) fill.style.width = percent + '%';
        
        const opacity = 0.05 + (percent / 100) * 0.25;
        this._elements.iceElements.forEach(el => {
            if (el) el.style.backgroundColor = `rgba(255, 255, 255, ${opacity})`;
        });
        
        if (this._elements.transparencyValue) {
            this._elements.transparencyValue.textContent = Math.round(percent) + '%';
        }
        
        this._state.transparency = percent;
    },
    
    // =========================================
    // SÉLECTEUR DE THÈME
    // =========================================
    initThemeSelector() {
        const themeSelect = this._elements.themeSelect;
        if (!themeSelect) return;
        
        themeSelect.addEventListener('change', (e) => {
            const theme = e.target.value;
            this.applyTheme(theme);
            this._state.eventBus.emit('sound:play', { sound: 'click' });
        });
        
        // Restaurer le thème sauvegardé plus tard
    },
    
    applyTheme(theme) {
        document.body.setAttribute('data-theme', theme);
        localStorage.setItem('grand-archive-theme', theme);
        this._state.currentTheme = theme;
        
        const color = this.getThemeColor(theme);
        
        // 1. Mettre à jour les éléments d'interface principaux
        if (this._elements.playBtn) this._elements.playBtn.style.color = color;
        
        // 2. Mettre à jour le remplissage du slider de transparence
        const sliderFill = this._elements.transparencySlider?.querySelector('div');
        if (sliderFill) sliderFill.style.background = color;
        
        if (this._elements.trackFill) this._elements.trackFill.style.background = color;
        if (this._elements.swipeFill) this._elements.swipeFill.style.background = color;
        
        // 3. *** NOUVEAU : Styliser le sélecteur de thème lui-même ***
        if (this._elements.themeSelect) {
            this._elements.themeSelect.style.borderColor = color;
            this._elements.themeSelect.style.backgroundColor = color + '20'; // 20 = 12% de transparence
        }
        
        // 4. *** NOUVEAU : Styliser le sélecteur de son ***
        if (this._elements.soundSelect) {
            this._elements.soundSelect.style.borderColor = color;
            this._elements.soundSelect.style.backgroundColor = color + '20';
        }
        
        // 5. *** NOUVEAU : Styliser le curseur de volume (accent-color) ***
        if (this._elements.soundVolume) {
            this._elements.soundVolume.style.accentColor = color;
        }
        
        // 6. *** NOUVEAU : Styliser les boutons ***
        const buttons = [
            this._elements.testSoundBtn,
            this._elements.importVideoBtn,
            this._elements.clearVideosBtn,
            this._elements.clearCacheBtn,
            this._elements.showAboutBtn
        ];
        
        buttons.forEach(btn => {
            if (btn) {
                btn.style.backgroundColor = color;
                btn.style.border = 'none';
                btn.style.color = '#ffffff';
                btn.style.transition = 'background-color 0.3s ease';
            }
        });
        
        // 7. *** NOUVEAU : Styliser l'icône du thème dans le select ***
        const themeIcon = document.querySelector('.setting-item i.bi-moon');
        if (themeIcon) themeIcon.style.color = color;
        
        const soundIcon = document.querySelector('.setting-item i.bi-music-note');
        if (soundIcon) soundIcon.style.color = color;
        
        // Émettre un événement
        this._state.eventBus.emit('theme:changed', { theme, color });
    },
    
    getThemeColor(theme) {
        const colors = {
            'deep-space': '#00aaff', 
            'midnight': '#aa88ff',
            'aurora': '#6effb0', 
            'sunset': '#ff884d', 
            'forest': '#66cc66',
            'default': '#ff0055'
        };
        return colors[theme] || colors.default;
    },
    
    // =========================================
    // GESTION RÉSEAU
    // =========================================
    initNetworkManager() {
        const updateOnlineStatus = () => {
            const isOnline = navigator.onLine;
            document.body.classList.toggle('offline', !isOnline);
            this._state.eventBus.emit('network:changed', { online: isOnline });
        };
        
        window.addEventListener('online', updateOnlineStatus);
        window.addEventListener('offline', updateOnlineStatus);
        updateOnlineStatus();
    },
    
    // =========================================
    // PRÉCHARGEMENT
    // =========================================
    async preloadContents() {
        console.log('🔄 PlayerInterface: Préchargement...');
        
        // Demander aux autres modules de précharger via événements
        this._state.eventBus.emit('preload:request', {});
        
        // Si le module iTunesAPI est disponible, on peut lancer un préchargement
        // Mais on ne l'appelle pas directement, on émet un événement
        this._state.eventBus.emit('itunes:prefetch-top-songs', { country: 'fr', limit: 20 });
    },
    
    // =========================================
    // RESTAURATION DE L'ÉTAT
    // =========================================
    restoreState() {
        // Thème
        const savedTheme = localStorage.getItem('grand-archive-theme');
        if (savedTheme && this._elements.themeSelect) {
            this._elements.themeSelect.value = savedTheme;
            this.applyTheme(savedTheme);
        }
        
        // Transparence déjà gérée dans initTransparencyControl
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🎛️ PlayerInterface: Nettoyage...');
        // Retirer les écouteurs globaux si nécessaire
        window.removeEventListener('online', this._onlineHandler);
        window.removeEventListener('offline', this._offlineHandler);
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.playerInterface = PlayerInterface;

console.log('🎛️ PlayerInterface: Module enregistré');