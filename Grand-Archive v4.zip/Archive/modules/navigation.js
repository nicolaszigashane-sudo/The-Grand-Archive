/**
 * THE GRAND ARCHIVE - Navigation Module
 * Version 3.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion de la navigation principale
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const Navigation = {
    // Identité du module
    name: 'navigation',
    dependencies: ['ui', 'sound', 'content'], // ui pour closeAllPanels, content pour charger les vues
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        currentView: 'listen', // vue active
    },
    
    // Éléments DOM (cachés)
    _elements: {
        navItems: null,
        infoPanel: null,
        immersionBtn: null,
        albumContainer: null,
        stageCenter: null,
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🧭 Navigation: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Attacher les écouteurs d'événements DOM
        this.attachEventListeners();
        
        // S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ Navigation prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            navItems: document.querySelectorAll('.nav-item:not(.immersion-btn)'),
            infoPanel: document.getElementById('info-panel'),
            immersionBtn: document.getElementById('immersion-btn'),
            albumContainer: document.getElementById('album-container'),
            stageCenter: document.querySelector('.stage-center'),
        };
    },
    
    attachEventListeners() {
        const { navItems, immersionBtn } = this._elements;
        
        if (navItems) {
            navItems.forEach(item => {
                item.addEventListener('click', (e) => {
                    e.preventDefault();
                    const view = item.dataset.view;
                    if (!view) return;
                    
                    // Demander le son
                    this._state.eventBus.emit('sound:play', { sound: 'click' });
                    
                    // Naviguer vers la vue
                    this.navigateTo(view);
                });
            });
        }
        
        // Bouton immersion (le comportement est géré par player-interface)
        if (immersionBtn) {
            immersionBtn.addEventListener('click', () => {
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                // Pas besoin de faire plus, le module playerInterface écoute déjà le clic sur ce bouton
            });
        }
    },
    
    subscribeToEvents() {
        // Écouter les demandes de navigation
        this._state.eventBus.on('navigation:go-to', (detail) => {
            const { view } = detail;
            this.navigateTo(view);
        });
        
        // Écouter les changements de vue déclenchés par d'autres modules (ex: retour à listen après fermeture de panneau)
        this._state.eventBus.on('navigation:set-view', (detail) => {
            const { view } = detail;
            this.setActiveView(view);
        });
        
        // Écouter la fermeture de tous les panneaux (pour revenir à listen)
        this._state.eventBus.on('panels:closed', () => {
            // Si on ferme tous les panneaux, on retourne à listen
            if (this._state.currentView !== 'listen') {
                this.navigateTo('listen');
            }
        });
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES (appelables via événements ou directement)
    // =========================================
    
    /**
     * Navigue vers une vue spécifique
     */
    navigateTo(view) {
        if (!view) return;
        
        const { navItems, infoPanel, stageCenter } = this._elements;
        
        // Mettre à jour les classes actives
        navItems.forEach(item => {
            item.classList.toggle('active', item.dataset.view === view);
        });
        
        // Demander la fermeture de tous les panneaux via l'UI
        this._state.eventBus.emit('ui:close-all-panels');
        
        if (view === 'listen') {
            // Vue listen : afficher la galerie, cacher le panneau d'info
            if (stageCenter) stageCenter.style.display = 'block';
            if (infoPanel) infoPanel.style.display = 'none';
            
            // Activer la galerie
            this._state.eventBus.emit('gallery:activate');
        } else {
            // Autres vues : masquer la galerie, afficher le panneau d'info
            if (stageCenter) stageCenter.style.display = 'none';
            if (infoPanel) infoPanel.style.display = 'block';
            
            // Ouvrir le panneau correspondant
            this._state.eventBus.emit('ui:open-panel', { panelId: view + '-view' });
            
            // Charger le contenu de la vue
            this._state.eventBus.emit('content:load-view', { view });
        }
        
        // Mettre à jour l'état interne
        this._state.currentView = view;
        
        // Émettre un événement pour informer les autres modules
        this._state.eventBus.emit('navigation:changed', { view });
    },
    
    /**
     * Définit la vue active sans déclencher de chargement (pour synchronisation)
     */
    setActiveView(view) {
        const { navItems } = this._elements;
        navItems.forEach(item => {
            item.classList.toggle('active', item.dataset.view === view);
        });
        this._state.currentView = view;
    },
    
    /**
     * Retourne la vue courante
     */
    getCurrentView() {
        return this._state.currentView;
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🧭 Navigation: Nettoyage...');
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.navigation = Navigation;
    console.log('🧭 Navigation: Module enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement navigation:', e);
}