/**
 * THE GRAND ARCHIVE - Lyrics Sync Module
 * Version 2.1.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Synchronisation et affichage des paroles
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const LyricsSync = {
    // Identité du module
    name: 'lyrics',
    dependencies: ['metadata', 'player', 'offline', 'ui'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
        
        // 🔑 Clés API (à fournir par config)
        apiKeys: {
            genius: '',
            audd: '',
            lrclib: null
        },
        
        // Endpoints
        endpoints: {
            genius: {
                search: 'https://api.genius.com/search',
                songs: 'https://api.genius.com/songs'
            },
            audd: {
                recognize: 'https://api.audd.io/recognize',
                lyrics: 'https://api.audd.io/findLyrics'
            },
            lrclib: {
                get: 'https://lrclib.net/api/get',
                search: 'https://lrclib.net/api/search'
            }
        },
        
        // Cache des paroles (en mémoire + persistant via offline)
        cache: new Map(),
        cacheLoaded: false,
        
        // État actuel
        currentTrack: null,
        currentLyrics: null,
        currentLine: 0,
        syncInterval: null,
        
        // Configuration
        config: {
            autoFetch: true,
            highlightCurrent: true,
            fontSize: '1.8rem',
            textAlign: 'center',
            preferredSource: 'local',
            offlineMode: false
        },
        
        // Statistiques
        stats: {
            fetched: 0,
            cached: 0,
            local: 0,
            failed: 0,
            synced: 0,
            sources: {
                local: 0,
                genius: 0,
                audd: 0,
                lrclib: 0
            }
        },
        
        // Gestion des requêtes asynchrones
        pendingRequests: new Map(),
        nextRequestId: 0,
    },
    
    // Éléments DOM (cachés)
    _elements: {
        lyricsModal: null,
        lyricsTitle: null,
        lyricsText: null,
        settingsContent: null,
    },
    
    // Référence au module UI
    _ui: null,
    
    // =========================================
    // INITIALISATION
    // =========================================
    async init(config) {
        console.log('🎤 LyricsSync: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Récupérer les clés API depuis la config
        if (config.apiKeys) {
            Object.assign(this._state.apiKeys, config.apiKeys);
        }
        
        this._ui = window.modules?.ui;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Charger le cache depuis le module offline
        await this._loadCache();
        
        // Ajouter les styles et les paramètres UI
        this._addLyricsStyles();
        this._addLyricsSettings();
        this._addToggleStyles();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ LyricsSync prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            lyricsModal: document.getElementById('lyrics-modal'),
            lyricsTitle: document.getElementById('lyrics-title'),
            lyricsText: document.getElementById('lyrics-text'),
            settingsContent: document.querySelector('.settings-content'),
        };
    },
    
    subscribeToEvents() {
        // Demande de paroles pour la piste courante
        this._state.eventBus.on('lyrics:load-current', async () => {
            const result = await this.loadForCurrentTrack();
            if (result) {
                this._state.eventBus.emit('lyrics:loaded', { lyrics: result });
            }
        });
        
        // Demande de recherche de paroles
        this._state.eventBus.on('lyrics:fetch', async (detail) => {
            const { trackName, artistName, albumName, duration, trackId, callbackId } = detail;
            const lyrics = await this._fetchLyrics(trackName, artistName, albumName, duration, trackId);
            if (callbackId) {
                this._state.eventBus.emit('lyrics:fetch-result', { lyrics, callbackId });
            }
        });
        
        // Réponse du module player pour la piste courante
        this._state.eventBus.on('player:current-track', (detail) => {
            const { track, callbackId } = detail;
            const pending = this._state.pendingRequests.get(callbackId);
            if (pending) {
                this._state.pendingRequests.delete(callbackId);
                pending.resolve(track);
            }
        });
        
        // Réponses du module metadata
        this._state.eventBus.on('metadata:track-by-id-result', (detail) => this._handleMetadataResponse(detail));
        this._state.eventBus.on('metadata:search-result', (detail) => this._handleMetadataResponse(detail));
        this._state.eventBus.on('metadata:all-tracks-result', (detail) => this._handleMetadataResponse(detail));
        
        // Réponses du cache offline
        this._state.eventBus.on('offline:api-retrieved', (detail) => this._handleOfflineResponse(detail));
        this._state.eventBus.on('offline:api-cached', (detail) => {});
    },
    
    // =========================================
    // GESTION DU CACHE (via offline)
    // =========================================
    async _loadCache() {
        return new Promise((resolve) => {
            const callbackId = `lyrics_cache_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve: (data) => {
                if (data) {
                    try {
                        const parsed = JSON.parse(data);
                        this._state.cache = new Map(Object.entries(parsed));
                        this._state.cacheLoaded = true;
                    } catch (e) {}
                }
                resolve();
            }});
            
            this._state.eventBus.emit('offline:get-api', {
                endpoint: 'lyrics_cache',
                ignoreTTL: true,
                callbackId
            });
            
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve();
                }
            }, 2000);
        });
    },
    
    async _saveCache() {
        const cacheObj = Object.fromEntries(this._state.cache);
        this._state.eventBus.emit('offline:cache-api', {
            endpoint: 'lyrics_cache',
            data: JSON.stringify(cacheObj),
            ttl: 30 * 24 * 60 * 60 * 1000 // 30 jours
        });
    },
    
    _handleOfflineResponse(detail) {
        const { callbackId, data } = detail;
        const pending = this._state.pendingRequests.get(callbackId);
        if (pending) {
            this._state.pendingRequests.delete(callbackId);
            pending.resolve(data);
        }
    },
    
    // =========================================
    // RECHERCHE LOCALE DANS LES MÉTADONNÉES
    // =========================================
    async _findLocalLyrics(trackName, artistName, trackId = null) {
        console.log(`🔍 Recherche locale: ${artistName} - ${trackName}`);
        
        let lyrics = null;
        
        // 1. Chercher par trackId
        if (trackId) {
            lyrics = await this._requestMetadataTrackById(trackId);
        }
        
        // 2. Chercher par nom/artiste
        if (!lyrics) {
            lyrics = await this._requestMetadataSearch(trackName, artistName);
        }
        
        // 3. Chercher dans tous les tracks (recherche plus large)
        if (!lyrics) {
            lyrics = await this._requestMetadataAllTracks(trackName, artistName);
        }
        
        // 4. Chercher dans le cache mémoire
        if (!lyrics) {
            const cacheKey = `${artistName}|${trackName}`;
            if (this._state.cache.has(cacheKey)) {
                lyrics = this._state.cache.get(cacheKey);
                console.log('✅ Paroles trouvées en cache');
            }
        }
        
        if (lyrics) {
            this._state.stats.local++;
            this._state.stats.sources.local++;
        }
        
        return lyrics;
    },
    
    _requestMetadataTrackById(trackId) {
        return new Promise((resolve) => {
            const callbackId = `lyrics_meta_id_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('metadata:get-track', { trackId, callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 3000);
        });
    },
    
    _requestMetadataSearch(trackName, artistName) {
        return new Promise((resolve) => {
            const callbackId = `lyrics_meta_search_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('metadata:search', { query: `${artistName} ${trackName}`, callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 3000);
        });
    },
    
    _requestMetadataAllTracks(trackName, artistName) {
        return new Promise((resolve) => {
            const callbackId = `lyrics_meta_all_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('metadata:get-all-tracks', { callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 3000);
        });
    },
    
    _handleMetadataResponse(detail) {
        const { callbackId, track, tracks } = detail;
        const pending = this._state.pendingRequests.get(callbackId);
        if (!pending) return;
        
        this._state.pendingRequests.delete(callbackId);
        
        // Si on a un track spécifique
        if (track && track.metadata) {
            const lyrics = this._extractLyricsFromTrack(track);
            pending.resolve(lyrics);
            return;
        }
        
        // Si on a une liste de tracks, chercher le bon
        if (tracks && Array.isArray(tracks)) {
            const found = tracks.find(t => 
                t.title?.toLowerCase() === trackName?.toLowerCase() &&
                t.artist?.toLowerCase() === artistName?.toLowerCase()
            );
            if (found) {
                const lyrics = this._extractLyricsFromTrack(found);
                pending.resolve(lyrics);
                return;
            }
        }
        
        pending.resolve(null);
    },
    
    _extractLyricsFromTrack(track) {
        if (track.metadata?.lyrics) {
            return {
                type: 'plain',
                text: track.metadata.lyrics,
                source: 'local_metadata',
                trackName: track.title,
                artistName: track.artist
            };
        }
        if (track.metadata?.syncedLyrics) {
            return {
                type: 'synced',
                lines: this._parseSyncedLyrics(track.metadata.syncedLyrics),
                source: 'local_metadata_synced',
                trackName: track.title,
                artistName: track.artist
            };
        }
        return null;
    },
    
    // =========================================
    // FONCTION PRINCIPALE DE RECHERCHE
    // =========================================
    async _fetchLyrics(trackName, artistName, albumName = null, duration = null, trackId = null) {
        if (!trackName || !artistName) return null;
        
        const cacheKey = `${artistName}|${trackName}|${albumName || ''}`;
        
        // Vérifier le cache d'abord
        if (this._state.cache.has(cacheKey)) {
            console.log('📦 Paroles trouvées en cache');
            this._state.stats.cached++;
            return this._state.cache.get(cacheKey);
        }
        
        console.log(`🌐 Recherche paroles: ${artistName} - ${trackName}`);
        
        let lyrics = null;
        
        // 1. D'abord chercher LOCALEMENT (hors-ligne)
        if (!navigator.onLine || this._state.config.preferredSource === 'local') {
            lyrics = await this._findLocalLyrics(trackName, artistName, trackId);
        }
        
        // 2. Si pas trouvé et qu'on est en ligne, chercher sur Internet
        if (!lyrics && navigator.onLine) {
            // Essayer LrcLib d'abord (paroles synchronisées)
            lyrics = await this._fetchFromLrcLib(trackName, artistName, albumName, duration);
            if (lyrics) lyrics.source = 'lrclib';
            
            // Puis Genius
            if (!lyrics && this._state.apiKeys.genius) {
                lyrics = await this._fetchFromGenius(trackName, artistName);
                if (lyrics) lyrics.source = 'genius';
            }
            
            // Enfin Audd.io
            if (!lyrics && this._state.apiKeys.audd) {
                lyrics = await this._fetchFromAudd(trackName, artistName);
                if (lyrics) lyrics.source = 'audd';
            }
        }
        
        // 3. Sauvegarder dans le cache
        if (lyrics) {
            this._state.cache.set(cacheKey, lyrics);
            this._state.stats.fetched++;
            if (lyrics.source) this._state.stats.sources[lyrics.source] = (this._state.stats.sources[lyrics.source] || 0) + 1;
            this._saveCache();
            return lyrics;
        }
        
        console.log('❌ Aucune parole trouvée');
        this._state.stats.failed++;
        return null;
    },
    
    // =========================================
    // SOUS-FONCTIONS INTERNET (simplifiées)
    // =========================================
    async _fetchFromLrcLib(trackName, artistName, albumName, duration) {
        // Implémentation réelle à faire avec fetch via eventBus ? On peut garder fetch direct car c'est une API externe.
        // Mais pour rester cohérent, on pourrait utiliser un événement http:request. Par simplicité, on garde fetch direct.
        try {
            const url = `${this._state.endpoints.lrclib.get}?track_name=${encodeURIComponent(trackName)}&artist_name=${encodeURIComponent(artistName)}${albumName ? '&album_name='+encodeURIComponent(albumName) : ''}${duration ? '&duration='+Math.round(duration) : ''}`;
            const response = await fetch(url);
            if (!response.ok) return null;
            const data = await response.json();
            if (data && (data.lyrics || data.syncedLyrics)) {
                return {
                    type: data.syncedLyrics ? 'synced' : 'plain',
                    lines: data.syncedLyrics ? this._parseSyncedLyrics(data.syncedLyrics) : null,
                    text: data.lyrics,
                    trackName: data.trackName,
                    artistName: data.artistName
                };
            }
        } catch (e) {
            console.warn('⚠️ Erreur LrcLib:', e);
        }
        return null;
    },
    
    async _fetchFromGenius(trackName, artistName) {
        // Similaire, utiliser fetch
        return null;
    },
    
    async _fetchFromAudd(trackName, artistName) {
        return null;
    },
    
    _parseSyncedLyrics(text) {
        // Simple parseur de format [mm:ss.xx] paroles
        const lines = [];
        const regex = /\[(\d+):(\d+\.\d+)\](.*)/g;
        let match;
        while ((match = regex.exec(text)) !== null) {
            const minutes = parseInt(match[1], 10);
            const seconds = parseFloat(match[2]);
            const time = minutes * 60 + seconds;
            lines.push({ time, text: match[3].trim() });
        }
        return lines.sort((a,b) => a.time - b.time);
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES (exposées)
    // =========================================
    
    /**
     * Charge les paroles pour la piste courante
     */
    async loadForCurrentTrack() {
        // Demander la piste courante au module player
        const track = await this._requestCurrentTrack();
        if (!track) return null;
        
        this._state.currentTrack = track;
        this._state.currentLine = 0;
        
        const lyrics = await this._fetchLyrics(
            track.title || track.name,
            track.artist,
            track.album,
            track.duration,
            track.id
        );
        
        this._state.currentLyrics = lyrics;
        this._displayLyrics(lyrics);
        
        return lyrics;
    },
    
    _requestCurrentTrack() {
        return new Promise((resolve) => {
            const callbackId = `lyrics_current_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('player:get-current-track', { callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 2000);
        });
    },
    
    /**
     * Import manuel de fichiers .lrc
     */
    importLrcFile() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.lrc,.txt';
        input.multiple = true;
        
        input.onchange = async (e) => {
            const files = Array.from(e.target.files);
            let imported = 0;
            
            for (const file of files) {
                const lyrics = await this._extractLyricsFromFile(file);
                if (lyrics) {
                    // Essayer d'extraire le nom de la chanson du fichier
                    let trackName = file.name.replace(/\.lrc$/i, '').replace(/\.txt$/i, '');
                    
                    // Si format "Artiste - Titre.lrc"
                    let artist = 'Inconnu';
                    if (trackName.includes(' - ')) {
                        const parts = trackName.split(' - ');
                        artist = parts[0].trim();
                        trackName = parts[1].trim();
                    }
                    
                    const cacheKey = `${artist}|${trackName}`;
                    this._state.cache.set(cacheKey, lyrics);
                    imported++;
                }
            }
            
            this._saveCache();
            this._state.eventBus.emit('notification:show', { message: `✅ ${imported} fichiers de paroles importés` });
        };
        
        input.click();
    },
    
    /**
     * Extraction depuis la bibliothèque locale
     */
    async extractFromLibrary() {
        // Demander tous les tracks au module metadata
        const tracks = await this._requestAllMetadataTracks();
        if (!tracks) return;
        
        let extracted = 0;
        
        for (const track of tracks) {
            if (track.metadata?.lyrics || track.metadata?.syncedLyrics) {
                const cacheKey = `${track.artist}|${track.title}`;
                this._state.cache.set(cacheKey, {
                    type: track.metadata.syncedLyrics ? 'synced' : 'plain',
                    lines: track.metadata.syncedLyrics ? this._parseSyncedLyrics(track.metadata.syncedLyrics) : null,
                    text: track.metadata.lyrics,
                    source: 'local_metadata'
                });
                extracted++;
            }
        }
        
        this._saveCache();
        this._state.eventBus.emit('notification:show', { message: `✅ ${extracted} paroles extraites de la bibliothèque` });
    },
    
    _requestAllMetadataTracks() {
        return new Promise((resolve) => {
            const callbackId = `lyrics_all_tracks_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('metadata:get-all-tracks', { callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve([]);
                }
            }, 3000);
        });
    },
    
    /**
     * Extrait les paroles d'un fichier (utilitaire)
     */
    _extractLyricsFromFile(file) {
        return new Promise((resolve) => {
            // Si c'est un fichier .lrc
            if (file.name.endsWith('.lrc')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const content = e.target.result;
                    
                    if (content.includes('[') && content.includes(']')) {
                        // C'est probablement du LRC synchronisé
                        const lines = this._parseSyncedLyrics(content);
                        resolve({
                            type: 'synced',
                            lines,
                            plain: this._convertLrcToPlain(content),
                            source: 'lrc_file'
                        });
                    } else {
                        resolve({
                            type: 'plain',
                            text: content,
                            source: 'lrc_file'
                        });
                    }
                };
                reader.readAsText(file);
            }
            // Si c'est un fichier audio avec tags ID3
            else if (file.type.startsWith('audio/') && window.jsmediatags) {
                window.jsmediatags.read(file, {
                    onSuccess: (tag) => {
                        if (tag.tags.USLT || tag.tags.lyrics) {
                            resolve({
                                type: 'plain',
                                text: tag.tags.USLT || tag.tags.lyrics,
                                source: 'id3_uslt'
                            });
                        } else if (tag.tags.SYLT) {
                            resolve({
                                type: 'synced',
                                lines: this._parseID3SyncedLyrics(tag.tags.SYLT),
                                source: 'id3_sylt'
                            });
                        } else {
                            resolve(null);
                        }
                    },
                    onError: () => resolve(null)
                });
            } else {
                resolve(null);
            }
        });
    },
    
    _convertLrcToPlain(lrcText) {
        return lrcText.replace(/\[\d+:\d+\.\d+\]/g, '').replace(/\n+/g, '\n').trim();
    },
    
    _parseID3SyncedLyrics(syltData) {
        // Format spécifique à ID3, à adapter selon la bibliothèque
        const lines = [];
        if (Array.isArray(syltData)) {
            syltData.forEach(item => {
                lines.push({
                    time: item.timestamp / 1000,
                    text: item.text
                });
            });
        }
        return lines.sort((a, b) => a.time - b.time);
    },
    
    /**
     * Affiche les paroles dans le modal
     */
    _displayLyrics(lyrics) {
        const { lyricsText, lyricsTitle, lyricsModal } = this._elements;
        if (!lyricsText) return;
        
        if (!lyrics) {
            lyricsText.innerHTML = '<p style="text-align:center; opacity:0.5;">Aucune parole trouvée</p>';
            return;
        }
        
        if (lyricsTitle && this._state.currentTrack) {
            lyricsTitle.innerHTML = `<h3>${this._state.currentTrack.title} - ${this._state.currentTrack.artist}</h3>`;
        }
        
        if (lyrics.type === 'synced' && lyrics.lines) {
            // Affichage synchronisé
            lyricsText.innerHTML = lyrics.lines.map(line => 
                `<p class="lyric-line" data-time="${line.time}">${line.text}</p>`
            ).join('');
            this._startSync(lyrics.lines);
        } else {
            // Texte brut
            lyricsText.innerHTML = `<pre style="white-space: pre-wrap; font-family: inherit;">${lyrics.text || lyrics.plain || ''}</pre>`;
        }
        
        // Ouvrir le modal si nécessaire
        if (lyricsModal && lyricsModal.style.display !== 'block') {
            this._state.eventBus.emit('ui:open-panel', { panelId: 'lyrics-modal' });
        }
    },
    
    _startSync(lines) {
        if (this._state.syncInterval) clearInterval(this._state.syncInterval);
        
        this._state.syncInterval = setInterval(() => {
            if (!this._state.currentTrack || !this._state.currentLyrics) return;
            
            // Obtenir la position actuelle via le module player
            this._requestCurrentPosition().then(position => {
                if (position === null) return;
                
                // Trouver la ligne correspondante
                let activeLine = 0;
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i].time <= position) {
                        activeLine = i;
                    } else {
                        break;
                    }
                }
                
                if (activeLine !== this._state.currentLine) {
                    this._state.currentLine = activeLine;
                    this._highlightLine(activeLine);
                }
            });
        }, 200);
    },
    
    _requestCurrentPosition() {
        return new Promise((resolve) => {
            const callbackId = `lyrics_position_${this._state.nextRequestId++}`;
            this._state.pendingRequests.set(callbackId, { resolve });
            this._state.eventBus.emit('player:get-current-position', { callbackId });
            setTimeout(() => {
                if (this._state.pendingRequests.has(callbackId)) {
                    this._state.pendingRequests.delete(callbackId);
                    resolve(null);
                }
            }, 500);
        });
    },
    
    _highlightLine(index) {
        const lines = document.querySelectorAll('.lyric-line');
        lines.forEach((line, i) => {
            if (i === index) {
                line.classList.add('active');
                line.style.color = 'var(--neon-accent)';
                line.style.fontWeight = 'bold';
            } else {
                line.classList.remove('active');
                line.style.color = '';
                line.style.fontWeight = '';
            }
        });
    },
    
    /**
     * Mode hors-ligne
     */
    setOfflineMode(enabled) {
        this._state.config.offlineMode = enabled;
        if (enabled) {
            this._state.config.preferredSource = 'local';
        }
    },
    
    /**
     * Vider le cache
     */
    clearCache() {
        this._state.cache.clear();
        this._saveCache();
        this._updateCacheSizeDisplay();
    },
    
    /**
     * Mettre à jour l'affichage de la taille du cache
     */
    _updateCacheSizeDisplay() {
        const cacheSizeEl = document.getElementById('lyrics-cache-size');
        if (cacheSizeEl) {
            cacheSizeEl.textContent = `${this._state.cache.size} entrées`;
        }
    },
    
    // =========================================
    // UI : AJOUT DES PARAMÈTRES ET STYLES
    // =========================================
    _addLyricsSettings() {
        const settingsContent = this._elements.settingsContent;
        if (!settingsContent) return;
        
        if (document.getElementById('lyrics-settings-section')) return;
        
        const section = document.createElement('div');
        section.id = 'lyrics-settings-section';
        section.className = 'settings-group';
        section.innerHTML = `
            <h3><i class="bi bi-quote"></i> Paroles hors-ligne</h3>
            
            <div class="setting-item">
                <span class="setting-label"><i class="bi bi-file-text"></i> Importer fichiers .lrc</span>
                <button onclick="window.modules?.lyrics?.importLrcFile()" class="preset-btn">
                    <i class="bi bi-upload"></i> Importer
                </button>
            </div>
            
            <div class="setting-item">
                <span class="setting-label"><i class="bi bi-collection"></i> Extraire de la bibliothèque</span>
                <button onclick="window.modules?.lyrics?.extractFromLibrary()" class="preset-btn">
                    <i class="bi bi-magic"></i> Extraire
                </button>
            </div>
            
            <div class="setting-item">
                <span class="setting-label"><i class="bi bi-wifi-off"></i> Mode hors-ligne</span>
                <label class="toggle-switch">
                    <input type="checkbox" id="offline-lyrics-mode" onchange="window.modules?.lyrics?.setOfflineMode(this.checked)">
                    <span class="toggle-slider"></span>
                </label>
            </div>
            
            <div class="setting-item">
                <span class="setting-label"><i class="bi bi-database"></i> Cache paroles</span>
                <span id="lyrics-cache-size">${this._state.cache.size} entrées</span>
                <button onclick="window.modules?.lyrics?.clearCache()" class="preset-btn" style="margin-left: auto;">
                    <i class="bi bi-trash"></i> Vider
                </button>
            </div>
        `;
        
        settingsContent.appendChild(section);
    },
    
    _addLyricsStyles() {
        if (document.getElementById('lyrics-styles')) return;
        const style = document.createElement('style');
        style.id = 'lyrics-styles';
        style.textContent = `
            .lyrics-modal .lyric-line {
                transition: all 0.2s;
                padding: 4px 0;
                margin: 0;
                line-height: 1.6;
            }
            .lyrics-modal .lyric-line.active {
                color: var(--neon-accent);
                font-weight: bold;
                transform: scale(1.02);
            }
        `;
        document.head.appendChild(style);
    },
    
    _addToggleStyles() {
        if (document.getElementById('toggle-styles')) return;
        const style = document.createElement('style');
        style.id = 'toggle-styles';
        style.textContent = `
            .toggle-switch {
                position: relative;
                display: inline-block;
                width: 50px;
                height: 24px;
            }
            .toggle-switch input {
                opacity: 0;
                width: 0;
                height: 0;
            }
            .toggle-slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                transition: .4s;
                border-radius: 24px;
            }
            .toggle-slider:before {
                position: absolute;
                content: "";
                height: 20px;
                width: 20px;
                left: 2px;
                bottom: 2px;
                background-color: white;
                transition: .4s;
                border-radius: 50%;
            }
            input:checked + .toggle-slider {
                background-color: var(--neon-accent);
            }
            input:checked + .toggle-slider:before {
                transform: translateX(26px);
            }
        `;
        document.head.appendChild(style);
    },
    
    
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🎤 LyricsSync: Nettoyage...');
        if (this._state.syncInterval) clearInterval(this._state.syncInterval);
        this._state.pendingRequests.clear();
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
try {
    window.modules = window.modules || {};
    window.modules.lyrics = LyricsSync;
    console.log('📦 Module lyrics enregistré');
} catch (e) {
    console.error('❌ Erreur enregistrement lyrics:', e);
}