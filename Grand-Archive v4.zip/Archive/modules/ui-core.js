/**
 * THE GRAND ARCHIVE - UI Core Module
 * Version 2.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gérer les éléments d'interface de base (panels, utilitaires)
 * COMPORTEMENT : Pure sandbox - ne communique que par événements
 */


const UICore = {
    // Identité du module
    name: 'ui',
    dependencies: [], // Indépendant, mais peut utiliser les événements
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null
    },
    
    // Éléments DOM (cachés)
    _elements: {
        infoPanel: null,
        closeButtons: []
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🖼️ UICore: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Initialiser les composants (sans diaporama)
        this.movePanelsToInfoContainer();
        this.initCloseButtons();
        
        // S'abonner aux événements
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ UICore prêt');
        
        return this;
    },
    
    // =========================================
    // CACHE DES ÉLÉMENTS DOM
    // =========================================
    cacheElements() {
        this._elements = {
            infoPanel: document.getElementById('info-panel')
        };
        
        // Collecter tous les boutons de fermeture
        this._elements.closeButtons = Array.from(document.querySelectorAll('[id^="close-"]'));
    },
    
    // =========================================
    // ABONNEMENT AUX ÉVÉNEMENTS
    // =========================================
    subscribeToEvents() {
        // Écouter les demandes de fermeture de tous les panneaux
        this._state.eventBus.on('panels:close-all', () => {
            this.closeAllPanels();
        });
        
        // Écouter les demandes de fermeture d'un panneau spécifique
        this._state.eventBus.on('panel:close', (detail) => {
            const panelId = detail.panelId;
            if (panelId) {
                const panel = document.getElementById(panelId);
                if (panel) panel.style.display = 'none';
            }
            this.closeAllPanels(); // Au cas où on veut tout fermer
        });
        
        // Écouter les changements de thème (pour mettre à jour les couleurs)
        this._state.eventBus.on('theme:changed', (detail) => {
            // Mettre à jour les variables CSS si nécessaire
            if (detail.theme) {
                document.documentElement.setAttribute('data-theme', detail.theme);
            }
        });
        
        // Écouter les changements de transparence
        this._state.eventBus.on('transparency:changed', (detail) => {
            if (detail.value !== undefined) {
                document.documentElement.style.setProperty('--panel-opacity', detail.value / 100);
            }
        });

        // *** AJOUT INDISPENSABLE POUR OUVRIR LES PANNEAUX ***
        this._state.eventBus.on('ui:open-panel', (detail) => {
            this.openPanel(detail.panelId);
        });

        this._state.eventBus.on('ui:close-all-panels', () => {
            this.closeAllPanels();
        });
    },

    // =========================================
    // GESTION DES PANELS
    // =========================================
    movePanelsToInfoContainer() {
        const infoPanel = this._elements.infoPanel;
        if (!infoPanel) {
            console.error('❌ UICore: info-panel non trouvé');
            return;
        }
        
        const panelIds = [
            'browse-view', 'library-view', 'radio-view', 'playlists-view',
            'history-view', 'settings-panel', 'equalizer-panel', 'lyrics-modal',
            'search-modal', 'sleep-timer-modal', 'keyboard-help-modal',
            'playlist-detail-modal', 'about-view', 'artist-view'
        ];
        
        let deplaces = 0;
        
        panelIds.forEach(id => {
            const panel = document.getElementById(id);
            if (!panel) return;
            
            if (panel.parentElement !== infoPanel) {
                infoPanel.appendChild(panel);
                panel.style.display = 'none';
                deplaces++;
            }
        });
        
        console.log(`📊 ${deplaces} panels déplacés`);
    },
    
    closeAllPanels() {
        const infoPanel = this._elements.infoPanel;
        if (!infoPanel) return;
        
        const panels = infoPanel.querySelectorAll('[id$="-view"], [id$="-panel"], [id$="-modal"]');
        panels.forEach(panel => panel.style.display = 'none');
        
        // Masquer le conteneur info-panel
        infoPanel.style.display = 'none';
        
        // Réinitialiser la navigation
        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        const listenNav = document.querySelector('.nav-item[data-view="listen"]');
        if (listenNav) listenNav.classList.add('active');
        
        // Émettre un événement
        this._state.eventBus.emit('panels:closed', {
            timestamp: Date.now()
        });
    },
    
    initCloseButtons() {
        this._elements.closeButtons.forEach(btn => {
            // Éviter les doublons d'écouteurs
            if (btn.dataset.uiListener) return;
            btn.dataset.uiListener = 'true';
            
            btn.addEventListener('click', (e) => {
                // Demander le son
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                
                // Trouver le panel parent
                const panel = e.target.closest('[id$="-view"], [id$="-panel"], [id$="-modal"]');
                if (panel) {
                    panel.style.display = 'none';
                    
                    // Si c'est le dernier panel, cacher info-panel
                    const visiblePanels = this._elements.infoPanel?.querySelectorAll('[style*="display: block"]') || [];
                    if (visiblePanels.length === 0) {
                        this.closeAllPanels();
                    } else {
                        // Sinon, juste fermer ce panel
                        this._state.eventBus.emit('panel:closed', {
                            panelId: panel.id,
                            timestamp: Date.now()
                        });
                    }
                }
            });
        });
        
        // Gestion spéciale pour le bouton close-artist (déjà inclus)
    },
    
    // =========================================
    // MÉTHODES PUBLIQUES (utilitaires)
    // =========================================
    
    /**
     * Génère le HTML d'un loader
     */
    getLoaderHTML(message = 'Chargement...') {
        return `<div style="grid-column:1/-1; text-align:center; padding:50px;">
            <i class="bi bi-arrow-repeat spin" style="font-size:40px; color:var(--neon-accent);"></i>
            <p>${message}</p>
        </div>`;
    },
    
    /**
     * Génère le HTML d'une erreur
     */
    getErrorHTML(message = 'Erreur de chargement') {
        return `<div style="grid-column:1/-1; text-align:center; padding:50px; color:var(--text-secondary);">
            <i class="bi bi-exclamation-circle" style="font-size:40px;"></i>
            <p>${message}</p>
        </div>`;
    },
    
    /**
     * Convertit une couleur hexadécimale en RGB
     */
    hexToRgb(hex) {
        if (!hex || !hex.startsWith('#')) return '255, 0, 85';
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `${r}, ${g}, ${b}`;
    },
    
    /**
     * Retourne une liste de chansons locales par défaut
     */
    getLocalTopSongs() {
        return [
            { id: 1, name: 'Midnight Vibes', artist: 'Luna Ray', cover: 'backgrounds/default-cover.jpg' },
            { id: 2, name: 'Electric Dreams', artist: 'Neon Pulse', cover: 'backgrounds/default-cover.jpg' },
            { id: 3, name: 'Acoustic Sessions', artist: 'The Wanderers', cover: 'backgrounds/default-cover.jpg' },
            { id: 4, name: 'Deep Space', artist: 'Orbit', cover: 'backgrounds/default-cover.jpg' },
            { id: 5, name: 'Urban Flow', artist: 'Metro', cover: 'backgrounds/default-cover.jpg' }
        ];
    },
    
    /**
     * Ouvre un panel spécifique (utilisé par d'autres modules via événements)
     */
    openPanel(panelId) {
        const panel = document.getElementById(panelId);
        if (!panel || !this._elements.infoPanel) return;
        
        // Fermer les autres panels
        this.closeAllPanels();
        
        this._elements.infoPanel.style.display = 'block';
        panel.style.display = 'block';
        
        // Émettre un événement
        this._state.eventBus.emit('panel:opened', {
            panelId: panelId,
            timestamp: Date.now()
        });
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🖼️ UICore: Nettoyage...');
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.ui = UICore;

console.log('🖼️ UICore: Module enregistré');