 /**
 * THE GRAND ARCHIVE - Panel Buttons Module
 * Version 2.0.0 - Architecture Sandbox
 * 
 * Copyright (C) 2026 davidb
 * Licence: GNU General Public License v3.0
 * 
 * RÔLE : Gestion des boutons d'ouverture des panneaux
 * COMPORTEMENT : Pure sandbox - communique uniquement par événements
 */


const PanelButtons = {
    // Identité du module
    name: 'panelButtons',
    dependencies: ['ui', 'sound', 'lastfm', 'itunes', 'lyrics', 'content'],
    
    // État interne (privé)
    _state: {
        initialized: false,
        config: null,
        eventBus: null,
    },
    
    // Éléments DOM (cachés)
    _elements: {
        settingsBtn: null,
        equalizerBtn: null,
        lyricsBtn: null,
        historyBtn: null,
        artistBtn: null,
        searchNavBtn: null,
        artistView: null,
        artistLoader: null,
        artistContent: null,
        artistError: null,
        artistName: null,
        artistListeners: null,
        artistPlays: null,
        artistBio: null,
        artistTags: null,
        artistTopTracks: null,
        artistTopAlbums: null,
        artistSimilar: null,
    },
    
    // =========================================
    // INITIALISATION
    // =========================================
    init(config) {
        console.log('🔘 PanelButtons: Initialisation...');
        
        this._state.config = config;
        this._state.eventBus = config.eventBus;
        
        // Cacher les éléments DOM
        this.cacheElements();
        
        // Attacher les écouteurs d'événements DOM
        this.attachEventListeners();
        
        // S'abonner aux événements de l'application
        this.subscribeToEvents();
        
        this._state.initialized = true;
        console.log('✅ PanelButtons prêt');
        
        return this;
    },
    
    cacheElements() {
        this._elements = {
            settingsBtn: document.getElementById('settings-btn'),
            equalizerBtn: document.getElementById('equalizer-btn'),
            lyricsBtn: document.getElementById('lyrics-btn'),
            historyBtn: document.getElementById('history-btn'),
            artistBtn: document.getElementById('artist-btn'),
            searchNavBtn: document.getElementById('search-nav-btn'),
            
            artistView: document.getElementById('artist-view'),
            artistLoader: document.getElementById('artist-loader'),
            artistContent: document.getElementById('artist-content'),
            artistError: document.getElementById('artist-error'),
            artistName: document.getElementById('artist-name'),
            artistListeners: document.getElementById('artist-listeners'),
            artistPlays: document.getElementById('artist-plays'),
            artistBio: document.getElementById('artist-bio'),
            artistTags: document.getElementById('artist-tags'),
            artistTopTracks: document.getElementById('artist-top-tracks'),
            artistTopAlbums: document.getElementById('artist-top-albums'),
            artistSimilar: document.getElementById('artist-similar'),
            
            // Éléments pour récupérer l'artiste courant
            currentArtist: document.getElementById('current-artist'),
            miniArtist: document.getElementById('mini-artist'),
        };
    },
    
    attachEventListeners() {
        // Configuration des boutons de panneau
        const panelConfigs = [
            { id: 'settingsBtn', panelId: 'settings-panel', action: null },
            { id: 'equalizerBtn', panelId: 'equalizer-panel', action: null },
            { 
                id: 'lyricsBtn', 
                panelId: 'lyrics-modal', 
                action: () => {
                    this._state.eventBus.emit('lyrics:load-current');
                }
            },
            { 
                id: 'historyBtn', 
                panelId: 'history-view', 
                action: () => {
                    this._state.eventBus.emit('content:load-history');
                }
            },
            { 
                id: 'artistBtn', 
                panelId: 'artist-view', 
                action: () => {
                    this.loadArtistForCurrentTrack();
                }
            }
        ];
        
        panelConfigs.forEach(({ id, panelId, action }) => {
            const btn = this._elements[id];
            if (!btn) return;
            
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this._state.eventBus.emit('sound:play', { sound: 'click' });
                
                // Ouvrir le panneau via l'UI
                this._state.eventBus.emit('ui:open-panel', { panelId });
                
                // Exécuter l'action spécifique si fournie
                if (action) action();
                
                // Animation (sera gérée par l'UI)
                this._state.eventBus.emit('panel:opening', { panelId });
            });
        });
        
        // Bouton de recherche spécial
        this.attachSearchButton();
    },
    
    attachSearchButton() {
        const btn = this._elements.searchNavBtn;
        if (!btn) return;
        
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            this._state.eventBus.emit('sound:play', { sound: 'click' });
            
            // Ouvrir le panneau de recherche
            this._state.eventBus.emit('ui:open-panel', { panelId: 'search-modal' });
            
            // Demander le chargement du contenu de recherche
            this._state.eventBus.emit('content:load-search');
            
            this._state.eventBus.emit('panel:opening', { panelId: 'search-modal' });
        });
    },
    
    subscribeToEvents() {
        // Écouter les demandes de chargement d'artiste
        this._state.eventBus.on('artist:load', (detail) => {
            if (detail.artistName) {
                this.loadArtistInfo(detail.artistName);
            } else {
                this.loadArtistForCurrentTrack();
            }
        });
        
        // Écouter les résultats de recherche d'artiste (venant de lastfm)
        this._state.eventBus.on('lastfm:artist-info', (detail) => {
            this.displayArtistInfo(detail);
        });
        
        this._state.eventBus.on('lastfm:artist-toptracks', (detail) => {
            this.displayArtistTopTracks(detail.tracks);
        });
        
        this._state.eventBus.on('lastfm:artist-topalbums', (detail) => {
            this.displayArtistTopAlbums(detail.albums);
        });
        
        this._state.eventBus.on('lastfm:artist-similar', (detail) => {
            this.displayArtistSimilar(detail.artists);
        });
        
        this._state.eventBus.on('lastfm:artist-error', (detail) => {
            this.showArtistError(detail.error);
        });
    },
    
    // =========================================
    // GESTION DE L'ARTISTE
    // =========================================
    loadArtistForCurrentTrack() {
        const artistName = this._elements.currentArtist?.textContent || 
                           this._elements.miniArtist?.textContent;
        
        if (artistName && artistName !== 'Artiste inconnu' && artistName !== 'Sélectionnez un album') {
            // Ouvrir le panneau artiste
            this._state.eventBus.emit('ui:open-panel', { panelId: 'artist-view' });
            
            // Charger les infos
            this.loadArtistInfo(artistName);
        } else {
            this._state.eventBus.emit('notification:show', { 
                message: '❌ Aucun artiste sélectionné',
                type: 'error'
            });
        }
    },
    
    async loadArtistInfo(artistName) {
        const { artistLoader, artistContent, artistError } = this._elements;
        if (!artistLoader || !artistContent || !artistError) return;
        
        // Afficher le loader
        artistLoader.style.display = 'block';
        artistContent.style.display = 'none';
        artistError.style.display = 'none';
        
        // Demander les infos à LastFM via événement
        this._state.eventBus.emit('lastfm:get-artist-info', { artistName });
        this._state.eventBus.emit('lastfm:get-artist-toptracks', { artistName, limit: 10 });
        this._state.eventBus.emit('lastfm:get-artist-topalbums', { artistName, limit: 8 });
        this._state.eventBus.emit('lastfm:get-artist-similar', { artistName, limit: 6 });
    },
    
    displayArtistInfo(data) {
        const { artistLoader, artistContent, artistName, artistListeners, artistPlays, artistBio, artistTags } = this._elements;
        if (!artistContent) return;
        
        if (artistName) artistName.textContent = data.name || '';
        if (artistListeners) artistListeners.textContent = data.listeners?.toLocaleString() || '0';
        if (artistPlays) artistPlays.textContent = data.playcount?.toLocaleString() || '0';
        if (artistBio) artistBio.innerHTML = data.summary || 'Aucune biographie disponible.';
        
        if (artistTags && data.tags) {
            artistTags.innerHTML = data.tags.map(tag => `
                <span class="tag" style="background: rgba(255,255,255,0.1); padding: 5px 12px; border-radius: 20px; font-size: 12px; cursor: pointer;" onclick="window.modules?.panelButtons?.searchTag('${tag.name}')">
                    <i class="bi bi-tag"></i> ${tag.name}
                </span>
            `).join('');
        }
        
        // Cacher le loader seulement quand tout est chargé ?
        // On peut le faire après réception de tous les événements, mais ici on cache après le premier.
        // Une approche plus robuste serait d'attendre que toutes les données soient arrivées.
        // Pour simplifier, on peut laisser le loader jusqu'à ce que tous les appels soient terminés,
        // mais on n'a pas de mécanisme simple ici. On va plutôt laisser l'affichage se faire progressivement.
        // On peut ajouter un compteur.
        if (!this._dataCounter) this._dataCounter = 0;
        this._dataCounter++;
        if (this._dataCounter === 4) { // info + tracks + albums + similar
            artistLoader.style.display = 'none';
            artistContent.style.display = 'block';
            this._dataCounter = 0;
        }
    },
    
    displayArtistTopTracks(tracks) {
        const container = this._elements.artistTopTracks;
        if (!container) return;
        
        if (tracks && tracks.length > 0) {
            container.innerHTML = tracks.map(track => {
                // Échapper les apostrophes pour l'attribut onclick
                const safeTrackName = track.name.replace(/'/g, "\\'");
                const safeArtistName = (this._elements.artistName?.textContent || '').replace(/'/g, "\\'");
                return `
                <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); padding: 12px 15px; border-radius: 10px;">
                    <div>
                        <strong>${track.name}</strong>
                        <div style="font-size: 11px; opacity: 0.5;">${track.listeners?.toLocaleString() || 0} auditeurs</div>
                    </div>
                    <i class="bi bi-play-circle" style="color: var(--neon-accent); font-size: 20px; cursor: pointer;" onclick="window.modules?.panelButtons?.playTrack('${safeTrackName}', '${safeArtistName}')"></i>
                </div>
            `}).join('');
        } else {
            container.innerHTML = '<p style="opacity:0.5;">Aucun morceau trouvé</p>';
        }
        
        // Mettre à jour le compteur
        if (this._dataCounter !== undefined) {
            this._dataCounter++;
            if (this._dataCounter === 4) {
                this._elements.artistLoader.style.display = 'none';
                this._elements.artistContent.style.display = 'block';
                this._dataCounter = 0;
            }
        }
    },
    
    displayArtistTopAlbums(albums) {
        const container = this._elements.artistTopAlbums;
        if (!container) return;
        
        if (albums && albums.length > 0) {
            container.innerHTML = albums.map(album => `
                <div style="cursor: pointer;" onclick="window.modules?.panelButtons?.showAlbum('${album.name.replace(/'/g, "\\'")}')">
                    <img src="${album.image || 'backgrounds/default-cover.jpg'}" style="width: 100%; aspect-ratio: 1; border-radius: 10px; object-fit: cover;">
                    <p style="margin: 5px 0 0; font-size: 12px;">${album.name}</p>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<p style="opacity:0.5;">Aucun album trouvé</p>';
        }
        
        if (this._dataCounter !== undefined) {
            this._dataCounter++;
            if (this._dataCounter === 4) {
                this._elements.artistLoader.style.display = 'none';
                this._elements.artistContent.style.display = 'block';
                this._dataCounter = 0;
            }
        }
    },
    
    displayArtistSimilar(artists) {
        const container = this._elements.artistSimilar;
        if (!container) return;
        
        if (artists && artists.length > 0) {
            container.innerHTML = artists.map(artist => `
                <div style="min-width: 120px; cursor: pointer; text-align: center;" onclick="window.modules?.panelButtons?.loadArtistInfo('${artist.name.replace(/'/g, "\\'")}')">
                    <img src="${artist.image || 'backgrounds/default-artist.jpg'}" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 2px solid var(--neon-accent);">
                    <p style="margin: 5px 0; font-size: 12px;">${artist.name}</p>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<p style="opacity:0.5;">Aucun artiste similaire</p>';
        }
        
        if (this._dataCounter !== undefined) {
            this._dataCounter++;
            if (this._dataCounter === 4) {
                this._elements.artistLoader.style.display = 'none';
                this._elements.artistContent.style.display = 'block';
                this._dataCounter = 0;
            }
        }
    },
    
    showArtistError(error) {
        const { artistLoader, artistError } = this._elements;
        artistLoader.style.display = 'none';
        artistError.style.display = 'block';
        console.error('❌ Erreur chargement artiste:', error);
    },
    
    // =========================================
    // ACTIONS PUBLIQUES (exposées pour le HTML)
    // =========================================
    
    /**
     * Charge les informations d'un artiste (appelé depuis les clics sur les tags/similaires)
     */
    loadArtistInfo(artistName) {
        this.loadArtistInfo(artistName);
    },
    
    /**
     * Joue un morceau par son nom et artiste
     */
    playTrack(trackName, artistName) {
        this._state.eventBus.emit('itunes:search-and-play', { query: `${artistName} ${trackName}` });
    },
    
    /**
     * Affiche un album (pour l'instant notification)
     */
    showAlbum(albumName) {
        this._state.eventBus.emit('notification:show', { message: `Album: ${albumName}`, type: 'info' });
    },
    
    /**
     * Recherche par tag
     */
    searchTag(tagName) {
        this._state.eventBus.emit('lastfm:search-by-tag', { tag: tagName });
    },
    
    // =========================================
    // NETTOYAGE
    // =========================================
    destroy() {
        console.log('🔘 PanelButtons: Nettoyage...');
        this._state.initialized = false;
    }
};

// =========================================
// ENREGISTREMENT DU MODULE
// =========================================
window.modules = window.modules || {};
window.modules.panelButtons = PanelButtons;

console.log('🔘 PanelButtons: Module enregistré');